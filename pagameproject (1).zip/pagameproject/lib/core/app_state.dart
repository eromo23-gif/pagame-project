import 'package:flutter/material.dart';
import '../presentation/career_assessment_screen/career_assessment_screen.dart';

/// Mock app state for demo purposes — no backend required.
/// Tracks user progress through the career journey and dark mode preference.
class AppState extends ChangeNotifier {
  static final AppState _instance = AppState._internal();
  factory AppState() => _instance;
  AppState._internal();

  // ── Progress State ──────────────────────────────────────────────────────────
  int _progressStep = 0;
  int get progressStep => _progressStep;

  void markPayCalculatorUsed() {
    if (_progressStep < 1) {
      _progressStep = 1;
      notifyListeners();
    }
  }

  void markCareerJourneyStarted() {
    if (_progressStep < 2) {
      _progressStep = 2;
      notifyListeners();
    }
  }

  // ── Assessment Result ───────────────────────────────────────────────────────
  AssessmentResult? _assessmentResult;
  AssessmentResult? get assessmentResult => _assessmentResult;

  void setAssessmentResult(AssessmentResult result) {
    _assessmentResult = result;
    notifyListeners();
  }

  // ── Dark Mode ───────────────────────────────────────────────────────────────
  bool _isDarkMode = false;
  bool get isDarkMode => _isDarkMode;

  void toggleDarkMode(bool value) {
    _isDarkMode = value;
    notifyListeners();
  }

  // ── Pay Gap Calculator Context ──────────────────────────────────────────────
  Map<String, dynamic>? _payGapContext;
  Map<String, dynamic>? get payGapContext => _payGapContext;

  void setPayGapContext(Map<String, dynamic> context) {
    _payGapContext = context;
    notifyListeners();
  }

  void clearPayGapContext() {
    _payGapContext = null;
    notifyListeners();
  }

  static AppState get instance => _instance;
}
