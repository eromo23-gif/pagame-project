import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';
import '../../routes/app_routes.dart';

class SplashWelcomeScreen extends StatefulWidget {
  const SplashWelcomeScreen({super.key});

  @override
  State<SplashWelcomeScreen> createState() => _SplashWelcomeScreenState();
}

class _SplashWelcomeScreenState extends State<SplashWelcomeScreen>
    with TickerProviderStateMixin {
  // TODO: Replace with [Riverpod/Bloc] for production

  late AnimationController _blobController;
  late AnimationController _contentController;

  late Animation<double> _blob1Scale;
  late Animation<double> _blob2Scale;
  late Animation<double> _blob1Rotation;
  late Animation<double> _blob2Rotation;
  late Animation<Offset> _blob1Position;
  late Animation<Offset> _blob2Position;

  late Animation<double> _logoScale;
  late Animation<double> _logoOpacity;
  late Animation<double> _textOpacity;
  late Animation<Offset> _textSlide;
  late Animation<double> _buttonOpacity;
  late Animation<Offset> _buttonSlide;

  @override
  void initState() {
    super.initState();

    // Morphing blob animation — LOCKED core technique
    _blobController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 3200),
    )..repeat(reverse: true);

    _blob1Scale = Tween<double>(begin: 0.85, end: 1.15).animate(
      CurvedAnimation(parent: _blobController, curve: Curves.easeInOutSine),
    );
    _blob2Scale = Tween<double>(begin: 1.1, end: 0.8).animate(
      CurvedAnimation(parent: _blobController, curve: Curves.easeInOutSine),
    );
    _blob1Rotation = Tween<double>(begin: 0, end: math.pi * 0.15).animate(
      CurvedAnimation(parent: _blobController, curve: Curves.easeInOutSine),
    );
    _blob2Rotation = Tween<double>(begin: math.pi * 0.1, end: -math.pi * 0.1)
        .animate(
          CurvedAnimation(parent: _blobController, curve: Curves.easeInOutSine),
        );
    _blob1Position =
        Tween<Offset>(
          begin: const Offset(-0.15, -0.1),
          end: const Offset(0.1, 0.15),
        ).animate(
          CurvedAnimation(parent: _blobController, curve: Curves.easeInOutSine),
        );
    _blob2Position =
        Tween<Offset>(
          begin: const Offset(0.1, 0.2),
          end: const Offset(-0.05, -0.1),
        ).animate(
          CurvedAnimation(parent: _blobController, curve: Curves.easeInOutSine),
        );

    // Content entrance animation
    _contentController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );

    _logoScale = Tween<double>(begin: 0.6, end: 1.0).animate(
      CurvedAnimation(
        parent: _contentController,
        curve: const Interval(0.0, 0.6, curve: Curves.easeOutBack),
      ),
    );
    _logoOpacity = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _contentController,
        curve: const Interval(0.0, 0.5, curve: Curves.easeOut),
      ),
    );
    _textOpacity = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _contentController,
        curve: const Interval(0.4, 0.75, curve: Curves.easeOut),
      ),
    );
    _textSlide = Tween<Offset>(begin: const Offset(0, 0.3), end: Offset.zero)
        .animate(
          CurvedAnimation(
            parent: _contentController,
            curve: const Interval(0.4, 0.75, curve: Curves.easeOutCubic),
          ),
        );
    _buttonOpacity = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _contentController,
        curve: const Interval(0.65, 1.0, curve: Curves.easeOut),
      ),
    );
    _buttonSlide = Tween<Offset>(begin: const Offset(0, 0.4), end: Offset.zero)
        .animate(
          CurvedAnimation(
            parent: _contentController,
            curve: const Interval(0.65, 1.0, curve: Curves.easeOutCubic),
          ),
        );

    Future.delayed(const Duration(milliseconds: 200), () {
      if (mounted) _contentController.forward();
    });
  }

  @override
  void dispose() {
    _blobController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFA),
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Morphing blob background — LOCKED
          AnimatedBuilder(
            animation: _blobController,
            builder: (context, child) {
              return Stack(
                children: [
                  // Blob 1 — hot pink
                  Positioned(
                    left: size.width * (0.3 + _blob1Position.value.dx),
                    top: size.height * (0.05 + _blob1Position.value.dy),
                    child: Transform.rotate(
                      angle: _blob1Rotation.value,
                      child: Transform.scale(
                        scale: _blob1Scale.value,
                        child: _BlobShape(
                          size: size.width * 0.72,
                          color: const Color(0xFFE91E8F).withAlpha(31),
                        ),
                      ),
                    ),
                  ),
                  // Blob 2 — evergreen
                  Positioned(
                    left: size.width * (-0.15 + _blob2Position.value.dx),
                    top: size.height * (0.55 + _blob2Position.value.dy),
                    child: Transform.rotate(
                      angle: _blob2Rotation.value,
                      child: Transform.scale(
                        scale: _blob2Scale.value,
                        child: _BlobShape(
                          size: size.width * 0.85,
                          color: const Color(0xFF123C33).withAlpha(20),
                        ),
                      ),
                    ),
                  ),
                  // Blob 3 — accent pink bottom
                  Positioned(
                    right: size.width * (-0.2 + _blob1Position.value.dy),
                    bottom: size.height * (0.1 + _blob2Position.value.dx),
                    child: Transform.rotate(
                      angle: -_blob1Rotation.value,
                      child: Transform.scale(
                        scale: _blob2Scale.value * 0.9,
                        child: _BlobShape(
                          size: size.width * 0.6,
                          color: const Color(0xFFE91E8F).withAlpha(18),
                        ),
                      ),
                    ),
                  ),
                ],
              );
            },
          ),

          // Main content
          SafeArea(
            child: Column(
              children: [
                const Spacer(flex: 2),

                // Logo
                AnimatedBuilder(
                  animation: _contentController,
                  builder: (context, child) {
                    return FadeTransition(
                      opacity: _logoOpacity,
                      child: ScaleTransition(scale: _logoScale, child: child),
                    );
                  },
                  child: Container(
                    width: 200,
                    height: 200,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(28),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFE91E8F).withAlpha(38),
                          blurRadius: 40,
                          offset: const Offset(0, 12),
                          spreadRadius: 0,
                        ),
                        BoxShadow(
                          color: Colors.black.withAlpha(15),
                          blurRadius: 16,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    padding: const EdgeInsets.all(16),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: Image.asset(
                        'assets/images/PagameProjectLogo-1782228044535.jpg',
                        fit: BoxFit.contain,
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 36),

                // Mission text
                AnimatedBuilder(
                  animation: _contentController,
                  builder: (context, child) {
                    return FadeTransition(
                      opacity: _textOpacity,
                      child: SlideTransition(
                        position: _textSlide,
                        child: child,
                      ),
                    );
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 32),
                    child: Column(
                      children: [
                        Text(
                          'Págame Project',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 28,
                            fontWeight: FontWeight.w800,
                            color: const Color(0xFF123C33),
                            letterSpacing: -0.5,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 12),
                        Text(
                          'Empowering women\'s career growth through AI, community, and career support.',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 15,
                            fontWeight: FontWeight.w400,
                            color: const Color(0xFF757575),
                            height: 1.6,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                ),

                const Spacer(flex: 2),

                // CTA Buttons
                AnimatedBuilder(
                  animation: _contentController,
                  builder: (context, child) {
                    return FadeTransition(
                      opacity: _buttonOpacity,
                      child: SlideTransition(
                        position: _buttonSlide,
                        child: child,
                      ),
                    );
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 28),
                    child: Column(
                      children: [
                        // Get Started button
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: () => context.go(AppRoutes.signInScreen),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFFE91E8F),
                              foregroundColor: Colors.white,
                              elevation: 0,
                              shadowColor: Colors.transparent,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(14),
                              ),
                              padding: const EdgeInsets.symmetric(vertical: 18),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  'Get Started',
                                  style: GoogleFonts.plusJakartaSans(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 0.3,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                const Icon(
                                  Icons.arrow_forward_rounded,
                                  size: 18,
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 14),
                        // Sign In text button
                        TextButton(
                          onPressed: () => context.go(AppRoutes.signInScreen),
                          style: TextButton.styleFrom(
                            foregroundColor: const Color(0xFF123C33),
                            padding: const EdgeInsets.symmetric(vertical: 12),
                          ),
                          child: Text(
                            'Already have an account? Sign In',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                              color: const Color(0xFF123C33),
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// Organic blob shape painter
class _BlobShape extends StatelessWidget {
  final double size;
  final Color color;

  const _BlobShape({required this.size, required this.color});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: Size(size, size),
      painter: _BlobPainter(color: color),
    );
  }
}

class _BlobPainter extends CustomPainter {
  final Color color;
  _BlobPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;

    final w = size.width;
    final h = size.height;
    final path = Path();

    // Organic blob shape using cubic bezier curves
    path.moveTo(w * 0.5, h * 0.0);
    path.cubicTo(w * 0.85, h * 0.0, w * 1.05, h * 0.2, w * 1.0, h * 0.5);
    path.cubicTo(w * 0.95, h * 0.8, w * 0.75, h * 1.05, w * 0.5, h * 1.0);
    path.cubicTo(w * 0.25, h * 0.95, w * -0.05, h * 0.78, w * 0.0, h * 0.5);
    path.cubicTo(w * 0.05, h * 0.22, w * 0.15, h * 0.0, w * 0.5, h * 0.0);
    path.close();

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(_BlobPainter oldDelegate) => oldDelegate.color != color;
}
