import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class HerPromotionClubScreen extends StatefulWidget {
  const HerPromotionClubScreen({super.key});

  @override
  State<HerPromotionClubScreen> createState() => _HerPromotionClubScreenState();
}

class _HerPromotionClubScreenState extends State<HerPromotionClubScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _entranceController;
  bool _joining = false;
  bool _joined = false;

  @override
  void initState() {
    super.initState();
    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _entranceController.forward();
    });
  }

  @override
  void dispose() {
    _entranceController.dispose();
    super.dispose();
  }

  Widget _buildEntrance({required int index, required Widget child}) {
    final delay = (index * 0.08).clamp(0.0, 0.7);
    final end = (delay + 0.35).clamp(0.0, 1.0);
    final fade = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _entranceController,
        curve: Interval(delay, end, curve: Curves.easeOut),
      ),
    );
    final slide = Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero)
        .animate(
          CurvedAnimation(
            parent: _entranceController,
            curve: Interval(delay, end, curve: Curves.easeOutCubic),
          ),
        );
    return FadeTransition(
      opacity: fade,
      child: SlideTransition(position: slide, child: child),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bottomPadding = MediaQuery.of(context).padding.bottom;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF1A1A1A) : const Color(0xFFFAFAFA);
    final titleColor = isDark
        ? const Color(0xFFE6E6E6)
        : const Color(0xFF123C33);

    return Scaffold(
      backgroundColor: bgColor,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          SliverAppBar(
            expandedHeight: 200,
            pinned: true,
            elevation: 0,
            scrolledUnderElevation: 0,
            automaticallyImplyLeading: false,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFFE91E8F), Color(0xFFB5157A)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white.withAlpha(51),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            '✦ Community',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              color: Colors.white,
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          'Her Promotion\nCareer Club',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 26,
                            fontWeight: FontWeight.w800,
                            color: Colors.white,
                            height: 1.2,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Where women rise together.',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 14,
                            color: Colors.white.withAlpha(230),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            backgroundColor: const Color(0xFFE91E8F),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.fromLTRB(20, 24, 20, bottomPadding + 90),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Mission statement
                  _buildEntrance(
                    index: 0,
                    child: Text(
                      'Empowering women through growth, connection, coaching, and shared career support.',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                        color: titleColor,
                        height: 1.6,
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  // Stats row
                  _buildEntrance(
                    index: 1,
                    child: Row(
                      children: [
                        _StatBox(
                          value: '150+',
                          label: 'Members',
                          isDark: isDark,
                        ),
                        const SizedBox(width: 12),
                        _StatBox(
                          value: '20+',
                          label: 'Workshops',
                          isDark: isDark,
                        ),
                        const SizedBox(width: 12),
                        _StatBox(
                          value: '10+',
                          label: 'Coaches',
                          isDark: isDark,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 28),
                  _buildEntrance(
                    index: 2,
                    child: Text(
                      'What You\'ll Get',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: titleColor,
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  ...[
                    (
                      Icons.groups_rounded,
                      'Community of Ambitious Women',
                      'Connect with a powerful network of women who are committed to career growth, equity, and mutual support.',
                      const Color(0xFFE91E8F),
                      3,
                    ),
                    (
                      Icons.psychology_outlined,
                      'Expert Coaching & Guidance',
                      'Access certified career coaches and executive mentors who understand the unique challenges women face.',
                      const Color(0xFF123C33),
                      4,
                    ),
                    (
                      Icons.event_outlined,
                      'Workshops & Facilitated Conversations',
                      'Join live workshops, panel discussions, and intimate conversations designed to spark growth and action.',
                      const Color(0xFFE91E8F),
                      5,
                    ),
                    (
                      Icons.handshake_outlined,
                      'Networking & Memorable Experiences',
                      'Build meaningful professional relationships through curated events and community experiences.',
                      const Color(0xFF123C33),
                      6,
                    ),
                    (
                      Icons.trending_up_rounded,
                      'Career Advancement & Pay Growth',
                      'Get the tools, strategies, and support to advance your career and close your personal pay gap.',
                      const Color(0xFFE91E8F),
                      7,
                    ),
                  ].map(
                    (item) => Padding(
                      padding: const EdgeInsets.only(bottom: 14),
                      child: _buildEntrance(
                        index: item.$5,
                        child: _FeatureCard(
                          icon: item.$1,
                          title: item.$2,
                          description: item.$3,
                          accentColor: item.$4,
                          isDark: isDark,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  // CTA
                  _buildEntrance(
                    index: 8,
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFF123C33), Color(0xFF1A5C48)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFF123C33).withAlpha(60),
                            blurRadius: 20,
                            offset: const Offset(0, 8),
                          ),
                        ],
                      ),
                      child: Column(
                        children: [
                          Text(
                            'Ready to Rise?',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 20,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Join a community of women who are done waiting and ready to advance.',
                            textAlign: TextAlign.center,
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 13,
                              color: Colors.white.withAlpha(204),
                              height: 1.5,
                            ),
                          ),
                          const SizedBox(height: 20),
                          _JoinButton(
                            isJoining: _joining,
                            isJoined: _joined,
                            onTap: () async {
                              if (_joined) return;
                              setState(() => _joining = true);
                              await Future.delayed(
                                const Duration(milliseconds: 1500),
                              );
                              if (mounted) {
                                setState(() {
                                  _joining = false;
                                  _joined = true;
                                });
                              }
                            },
                          ),
                          const SizedBox(height: 12),
                          Text(
                            'Membership details coming soon',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 12,
                              color: Colors.white.withAlpha(128),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _StatBox extends StatelessWidget {
  final String value;
  final String label;
  final bool isDark;

  const _StatBox({
    required this.value,
    required this.label,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: isDark ? const Color(0xFF2D2D2D) : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isDark ? const Color(0xFF4A4A4A) : const Color(0xFFE8D5DF),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withAlpha(isDark ? 20 : 8),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          children: [
            Text(
              value,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 20,
                fontWeight: FontWeight.w800,
                color: const Color(0xFFE91E8F),
              ),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 11,
                color: isDark
                    ? const Color(0xFFAAAAAA)
                    : const Color(0xFF9E9E9E),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FeatureCard extends StatefulWidget {
  final IconData icon;
  final String title;
  final String description;
  final Color accentColor;
  final bool isDark;

  const _FeatureCard({
    required this.icon,
    required this.title,
    required this.description,
    required this.accentColor,
    required this.isDark,
  });

  @override
  State<_FeatureCard> createState() => _FeatureCardState();
}

class _FeatureCardState extends State<_FeatureCard> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final cardColor = widget.isDark ? const Color(0xFF2D2D2D) : Colors.white;
    final borderColor = widget.isDark
        ? const Color(0xFF4A4A4A)
        : const Color(0xFFE8D5DF);
    final titleColor = widget.isDark
        ? const Color(0xFFE6E6E6)
        : const Color(0xFF1A1A1A);
    final descColor = widget.isDark
        ? const Color(0xFFAAAAAA)
        : const Color(0xFF757575);

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.98 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: borderColor),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withAlpha(widget.isDark ? 20 : 8),
                blurRadius: 10,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: widget.accentColor.withAlpha(26),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(widget.icon, color: widget.accentColor, size: 22),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.title,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: titleColor,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      widget.description,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 12,
                        color: descColor,
                        height: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _JoinButton extends StatefulWidget {
  final bool isJoining;
  final bool isJoined;
  final VoidCallback onTap;

  const _JoinButton({
    required this.isJoining,
    required this.isJoined,
    required this.onTap,
  });

  @override
  State<_JoinButton> createState() => _JoinButtonState();
}

class _JoinButtonState extends State<_JoinButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: SizedBox(
          width: double.infinity,
          height: 52,
          child: ElevatedButton(
            onPressed: widget.isJoined ? null : widget.onTap,
            style: ElevatedButton.styleFrom(
              backgroundColor: widget.isJoined
                  ? const Color(0xFF4CAF82)
                  : const Color(0xFFE91E8F),
              foregroundColor: Colors.white,
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
            child: widget.isJoining
                ? const SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      color: Colors.white,
                    ),
                  )
                : Text(
                    widget.isJoined ? '✓ Joined the Club!' : 'Join the Club',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
          ),
        ),
      ),
    );
  }
}
