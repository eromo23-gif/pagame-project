import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import './widgets/sign_in_form_widget.dart';
import './widgets/sign_in_header_widget.dart';

class SignInScreen extends StatelessWidget {
  const SignInScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final isTablet = MediaQuery.of(context).size.width >= 600;

    return Scaffold(
      backgroundColor: const Color(0xFFFFF0F7),
      body: SafeArea(
        child: isTablet
            ? Center(child: SizedBox(width: 480, child: _SignInContent()))
            : _SignInContent(),
      ),
    );
  }
}

class _SignInContent extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 48),
            const SignInHeaderWidget(),
            const SizedBox(height: 36),
            const SignInFormWidget(),
            const SizedBox(height: 32),
            _DividerRow(),
            const SizedBox(height: 24),
            _SocialSection(),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }
}

class _DividerRow extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: Container(height: 1, color: const Color(0xFFE8D5DF))),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Text(
            'or continue with',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 13,
              color: const Color(0xFF9E9E9E),
              fontWeight: FontWeight.w400,
            ),
          ),
        ),
        Expanded(child: Container(height: 1, color: const Color(0xFFE8D5DF))),
      ],
    );
  }
}

class _SocialSection extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // LinkedIn Social Button
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: () {
              // TODO: Replace with [Riverpod/Bloc] for production — LinkedIn OAuth
            },
            icon: const Icon(Icons.link_rounded, size: 20),
            label: Text(
              'Continue with LinkedIn',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
            style: OutlinedButton.styleFrom(
              foregroundColor: const Color(0xFF123C33),
              side: const BorderSide(color: Color(0xFFE8D5DF), width: 1.5),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              padding: const EdgeInsets.symmetric(vertical: 14),
              backgroundColor: Colors.white,
            ),
          ),
        ),
        const SizedBox(height: 24),
        // Demo credentials info box
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFF123C33).withAlpha(15),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: const Color(0xFF123C33).withAlpha(38),
              width: 1,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(
                    Icons.info_outline_rounded,
                    size: 16,
                    color: Color(0xFF123C33),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    'Demo Credentials',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: const Color(0xFF123C33),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              _CredentialRow(label: 'Email', value: 'demo@pagameproject.com'),
              const SizedBox(height: 4),
              _CredentialRow(label: 'Password', value: 'Empower2026!'),
            ],
          ),
        ),
      ],
    );
  }
}

class _CredentialRow extends StatelessWidget {
  final String label;
  final String value;

  const _CredentialRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(
          '$label: ',
          style: GoogleFonts.plusJakartaSans(
            fontSize: 12,
            fontWeight: FontWeight.w500,
            color: const Color(0xFF757575),
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 12,
              fontWeight: FontWeight.w400,
              color: const Color(0xFF1A1A1A),
            ),
          ),
        ),
        GestureDetector(
          onTap: () {
            // TODO: clipboard copy
          },
          child: const Icon(
            Icons.copy_rounded,
            size: 14,
            color: Color(0xFF9E9E9E),
          ),
        ),
      ],
    );
  }
}
