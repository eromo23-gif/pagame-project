import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:dio/dio.dart';
import 'package:go_router/go_router.dart';

import '../../core/app_state.dart';
import '../../routes/app_routes.dart';

// ─── BLS Data ────────────────────────────────────────────────────────────────

class _BlsOccupationData {
  final String seriesId;
  final String occupationLabel;
  final int typicalMedian;
  final int womenMedian;

  const _BlsOccupationData({
    required this.seriesId,
    required this.occupationLabel,
    required this.typicalMedian,
    required this.womenMedian,
  });
}

const Map<String, _BlsOccupationData> _industryBLSMap = {
  'Technology & Software': _BlsOccupationData(
    seriesId: 'OEUM000000015000003',
    occupationLabel: 'Computer & Mathematical Occupations',
    typicalMedian: 100530,
    womenMedian: 89200,
  ),
  'Healthcare': _BlsOccupationData(
    seriesId: 'OEUM000000029000003',
    occupationLabel: 'Healthcare Practitioners & Technical Occupations',
    typicalMedian: 75040,
    womenMedian: 68500,
  ),
  'Business & Finance': _BlsOccupationData(
    seriesId: 'OEUM000000013000003',
    occupationLabel: 'Business & Financial Operations Occupations',
    typicalMedian: 79050,
    womenMedian: 68900,
  ),
  'Education': _BlsOccupationData(
    seriesId: 'OEUM000000025000003',
    occupationLabel: 'Educational Instruction & Library Occupations',
    typicalMedian: 61690,
    womenMedian: 58200,
  ),
  'Engineering': _BlsOccupationData(
    seriesId: 'OEUM000000017000003',
    occupationLabel: 'Architecture & Engineering Occupations',
    typicalMedian: 87620,
    womenMedian: 78900,
  ),
  'Marketing & Sales': _BlsOccupationData(
    seriesId: 'OEUM000000011000003',
    occupationLabel: 'Management & Sales Occupations',
    typicalMedian: 72000,
    womenMedian: 62000,
  ),
  'Legal': _BlsOccupationData(
    seriesId: 'OEUM000000023000003',
    occupationLabel: 'Legal Occupations',
    typicalMedian: 94930,
    womenMedian: 79600,
  ),
  'Government & Public Service': _BlsOccupationData(
    seriesId: 'OEUM000000021000003',
    occupationLabel: 'Community & Social Service Occupations',
    typicalMedian: 58000,
    womenMedian: 53000,
  ),
  'Arts, Media & Design': _BlsOccupationData(
    seriesId: 'OEUM000000027000003',
    occupationLabel: 'Arts, Design, Entertainment & Media Occupations',
    typicalMedian: 55000,
    womenMedian: 49000,
  ),
  'Operations & Supply Chain': _BlsOccupationData(
    seriesId: 'OEUM000000013000003',
    occupationLabel: 'Business & Financial Operations Occupations',
    typicalMedian: 68000,
    womenMedian: 60000,
  ),
  'Retail & Hospitality': _BlsOccupationData(
    seriesId: 'OEUM000000035000003',
    occupationLabel: 'Food Preparation & Serving Occupations',
    typicalMedian: 35000,
    womenMedian: 31000,
  ),
  'Manufacturing & Skilled Trades': _BlsOccupationData(
    seriesId: 'OEUM000000049000003',
    occupationLabel: 'Installation, Maintenance & Repair Occupations',
    typicalMedian: 55000,
    womenMedian: 47000,
  ),
  'Science & Research': _BlsOccupationData(
    seriesId: 'OEUM000000019000003',
    occupationLabel: 'Life, Physical & Social Science Occupations',
    typicalMedian: 78000,
    womenMedian: 69000,
  ),
  'Nonprofit & Social Services': _BlsOccupationData(
    seriesId: 'OEUM000000021000003',
    occupationLabel: 'Community & Social Service Occupations',
    typicalMedian: 52000,
    womenMedian: 48000,
  ),
  'Other': _BlsOccupationData(
    seriesId: 'OEUM000000000000003',
    occupationLabel: 'All Occupations',
    typicalMedian: 48060,
    womenMedian: 42500,
  ),
};

// ─── Industry → Job Titles Map ───────────────────────────────────────────────

const Map<String, List<String>> _industryJobTitles = {
  'Technology & Software': [
    'Software Engineer',
    'Data Analyst',
    'Data Scientist',
    'Product Manager',
    'UX/UI Designer',
    'Cybersecurity Analyst',
    'IT Support Specialist',
    'Web Developer',
    'AI/ML Engineer',
    'QA Tester',
    'Other / Not Listed',
  ],
  'Healthcare': [
    'Registered Nurse',
    'Medical Assistant',
    'Physician Assistant',
    'Pharmacist',
    'Physical Therapist',
    'Healthcare Administrator',
    'Clinical Research Coordinator',
    'Mental Health Counselor',
    'Radiologic Technologist',
    'Other / Not Listed',
  ],
  'Business & Finance': [
    'Financial Analyst',
    'Accountant',
    'Business Analyst',
    'Operations Manager',
    'HR Specialist',
    'Project Manager',
    'Management Consultant',
    'Payroll Specialist',
    'Investment Analyst',
    'Other / Not Listed',
  ],
  'Education': [
    'Teacher',
    'Professor',
    'Academic Advisor',
    'School Counselor',
    'Teaching Assistant',
    'Education Coordinator',
    'Instructional Designer',
    'Tutor',
    'Other / Not Listed',
  ],
  'Engineering': [
    'Mechanical Engineer',
    'Civil Engineer',
    'Electrical Engineer',
    'Industrial Engineer',
    'Chemical Engineer',
    'Environmental Engineer',
    'Aerospace Engineer',
    'Engineering Technician',
    'Other / Not Listed',
  ],
  'Marketing & Sales': [
    'Marketing Coordinator',
    'Digital Marketing Specialist',
    'Social Media Manager',
    'Sales Representative',
    'Account Executive',
    'Brand Manager',
    'Market Research Analyst',
    'Public Relations Specialist',
    'Other / Not Listed',
  ],
  'Legal': [
    'Lawyer',
    'Paralegal',
    'Legal Assistant',
    'Compliance Analyst',
    'Contract Specialist',
    'Court Reporter',
    'Other / Not Listed',
  ],
  'Government & Public Service': [
    'Policy Analyst',
    'Program Coordinator',
    'Public Administrator',
    'Social Worker',
    'Urban Planner',
    'Public Safety Officer',
    'Government Analyst',
    'Other / Not Listed',
  ],
  'Arts, Media & Design': [
    'Graphic Designer',
    'Video Editor',
    'Photographer',
    'Content Creator',
    'Journalist',
    'Copywriter',
    'Animator',
    'Creative Director',
    'Other / Not Listed',
  ],
  'Operations & Supply Chain': [
    'Supply Chain Analyst',
    'Logistics Coordinator',
    'Operations Coordinator',
    'Warehouse Manager',
    'Procurement Specialist',
    'Inventory Analyst',
    'Transportation Manager',
    'Other / Not Listed',
  ],
  'Retail & Hospitality': [
    'Retail Sales Associate',
    'Store Manager',
    'Restaurant Manager',
    'Hotel Front Desk Agent',
    'Customer Service Representative',
    'Barista',
    'Server',
    'Event Coordinator',
    'Other / Not Listed',
  ],
  'Manufacturing & Skilled Trades': [
    'Electrician',
    'Welder',
    'Machinist',
    'HVAC Technician',
    'Automotive Technician',
    'Construction Worker',
    'Production Supervisor',
    'Maintenance Technician',
    'Other / Not Listed',
  ],
  'Science & Research': [
    'Research Assistant',
    'Lab Technician',
    'Biologist',
    'Chemist',
    'Environmental Scientist',
    'Research Scientist',
    'Clinical Research Associate',
    'Other / Not Listed',
  ],
  'Nonprofit & Social Services': [
    'Case Manager',
    'Program Manager',
    'Community Outreach Coordinator',
    'Fundraising Coordinator',
    'Social Services Assistant',
    'Volunteer Coordinator',
    'Grant Writer',
    'Other / Not Listed',
  ],
  'Other': ['Other / Not Listed'],
};

const List<String> _industries = [
  'Technology & Software',
  'Healthcare',
  'Business & Finance',
  'Education',
  'Engineering',
  'Marketing & Sales',
  'Legal',
  'Government & Public Service',
  'Arts, Media & Design',
  'Operations & Supply Chain',
  'Retail & Hospitality',
  'Manufacturing & Skilled Trades',
  'Science & Research',
  'Nonprofit & Social Services',
  'Other',
];

const List<String> _experienceOptions = [
  '0–1 years',
  '2–4 years',
  '5–7 years',
  '8–10 years',
  '11–15 years',
  '16+ years',
];

const List<String> _educationOptions = [
  'High school diploma',
  'Some college',
  'Associate degree',
  'Bachelor\'s degree',
  'Master\'s degree',
  'Doctorate / Professional degree',
  'Trade school / Certificate',
];

const List<String> _usStates = [
  'Alabama',
  'Alaska',
  'Arizona',
  'Arkansas',
  'California',
  'Colorado',
  'Connecticut',
  'Delaware',
  'Florida',
  'Georgia',
  'Hawaii',
  'Idaho',
  'Illinois',
  'Indiana',
  'Iowa',
  'Kansas',
  'Kentucky',
  'Louisiana',
  'Maine',
  'Maryland',
  'Massachusetts',
  'Michigan',
  'Minnesota',
  'Mississippi',
  'Missouri',
  'Montana',
  'Nebraska',
  'Nevada',
  'New Hampshire',
  'New Jersey',
  'New Mexico',
  'New York',
  'North Carolina',
  'North Dakota',
  'Ohio',
  'Oklahoma',
  'Oregon',
  'Pennsylvania',
  'Rhode Island',
  'South Carolina',
  'South Dakota',
  'Tennessee',
  'Texas',
  'Utah',
  'Vermont',
  'Virginia',
  'Washington',
  'West Virginia',
  'Wisconsin',
  'Wyoming',
  'Washington D.C.',
];

// ─── BLS API Service ─────────────────────────────────────────────────────────

class BLSWageResult {
  final int industryMedian;
  final int womenMedian;
  final String occupationLabel;
  final String dataSource;
  final bool isLiveData;

  const BLSWageResult({
    required this.industryMedian,
    required this.womenMedian,
    required this.occupationLabel,
    required this.dataSource,
    required this.isLiveData,
  });
}

class BLSApiService {
  static const String _baseUrl =
      'https://api.bls.gov/publicAPI/v1/timeseries/data/';

  final Dio _dio = Dio(
    BaseOptions(
      connectTimeout: const Duration(seconds: 8),
      receiveTimeout: const Duration(seconds: 10),
      headers: {'Content-Type': 'application/json'},
    ),
  );

  Future<BLSWageResult> fetchWageData(String industry) async {
    final occupationData =
        _industryBLSMap[industry] ?? _industryBLSMap['Other']!;
    try {
      final payload = jsonEncode({
        'seriesid': [occupationData.seriesId],
      });
      final response = await _dio.post(_baseUrl, data: payload);
      if (response.statusCode == 200) {
        final data = response.data is String
            ? jsonDecode(response.data)
            : response.data;
        if (data['status'] == 'REQUEST_SUCCEEDED') {
          final series = data['Results']?['series'];
          if (series != null && series.isNotEmpty) {
            final seriesData = series[0]['data'];
            if (seriesData != null && seriesData.isNotEmpty) {
              final latestPoint = seriesData.firstWhere(
                (d) => d['period'] == 'A01' || d['period'] == 'M13',
                orElse: () => seriesData[0],
              );
              final rawValue = double.tryParse(latestPoint['value'] ?? '0');
              if (rawValue != null && rawValue > 0) {
                final annualWage = rawValue.toInt();
                final womenWage = (annualWage * 0.82).toInt();
                return BLSWageResult(
                  industryMedian: annualWage,
                  womenMedian: womenWage,
                  occupationLabel: occupationData.occupationLabel,
                  dataSource: 'BLS OES ${latestPoint['year']} (Live)',
                  isLiveData: true,
                );
              }
            }
          }
        }
      }
    } catch (_) {}
    return BLSWageResult(
      industryMedian: occupationData.typicalMedian,
      womenMedian: occupationData.womenMedian,
      occupationLabel: occupationData.occupationLabel,
      dataSource: 'BLS OES Reference Data',
      isLiveData: false,
    );
  }
}

// ─── Currency Input Formatter ─────────────────────────────────────────────────

class _CurrencyInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final digits = newValue.text.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.isEmpty) return newValue.copyWith(text: '');
    final number = int.tryParse(digits) ?? 0;
    final formatted = _formatNumber(number);
    return newValue.copyWith(
      text: formatted,
      selection: TextSelection.collapsed(offset: formatted.length),
    );
  }

  String _formatNumber(int n) {
    final s = n.toString();
    final buffer = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buffer.write(',');
      buffer.write(s[i]);
    }
    return buffer.toString();
  }
}

// ─── Main Screen ─────────────────────────────────────────────────────────────

class GenderPayCalculatorScreen extends StatefulWidget {
  const GenderPayCalculatorScreen({super.key});

  @override
  State<GenderPayCalculatorScreen> createState() =>
      _GenderPayCalculatorScreenState();
}

class _GenderPayCalculatorScreenState extends State<GenderPayCalculatorScreen>
    with TickerProviderStateMixin {
  // Form state
  String? _selectedIndustry;
  String? _selectedJobTitle;
  String? _customJobTitle;
  String? _selectedExperience;
  String? _selectedEducation;
  String? _selectedState;
  final _salaryController = TextEditingController();
  final _customJobTitleController = TextEditingController();
  final _salaryFocusNode = FocusNode();

  // Validation errors
  String? _industryError;
  String? _jobTitleError;
  String? _experienceError;
  String? _educationError;
  String? _stateError;
  String? _salaryError;

  // UI state
  bool _showResults = false;
  bool _isLoading = false;
  bool _jobTitleAnimated = false;

  // Results
  BLSWageResult? _blsResult;
  int? _estimatedMarketSalary;
  int? _currentSalary;
  int? _payGap;

  final BLSApiService _blsService = BLSApiService();

  late AnimationController _resultsAnimController;
  late Animation<double> _resultsFade;
  late AnimationController _jobTitleAnimController;
  late Animation<double> _jobTitleFade;

  @override
  void initState() {
    super.initState();
    _resultsAnimController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );
    _resultsFade = CurvedAnimation(
      parent: _resultsAnimController,
      curve: Curves.easeOut,
    );
    _jobTitleAnimController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _jobTitleFade = CurvedAnimation(
      parent: _jobTitleAnimController,
      curve: Curves.easeOut,
    );
  }

  @override
  void dispose() {
    _salaryController.dispose();
    _customJobTitleController.dispose();
    _salaryFocusNode.dispose();
    _resultsAnimController.dispose();
    _jobTitleAnimController.dispose();
    super.dispose();
  }

  // ── Helpers ──────────────────────────────────────────────────────────────

  List<String> get _currentJobTitles => _selectedIndustry != null
      ? (_industryJobTitles[_selectedIndustry] ?? [])
      : [];

  bool get _showCustomJobTitle => _selectedJobTitle == 'Other / Not Listed';

  String get _effectiveJobTitle => _showCustomJobTitle
      ? (_customJobTitleController.text.trim().isNotEmpty
            ? _customJobTitleController.text.trim()
            : 'Other / Not Listed')
      : (_selectedJobTitle ?? '');

  int _parseSalary() {
    final raw = _salaryController.text.replaceAll(',', '');
    return int.tryParse(raw) ?? 0;
  }

  bool get _allFieldsComplete {
    return _selectedIndustry != null &&
        _selectedJobTitle != null &&
        _selectedExperience != null &&
        _selectedEducation != null &&
        _selectedState != null &&
        _parseSalary() >= 10000;
  }

  double _experienceMultiplier() {
    switch (_selectedExperience) {
      case '0–1 years':
        return 0.88;
      case '2–4 years':
        return 0.94;
      case '5–7 years':
        return 1.00;
      case '8–10 years':
        return 1.06;
      case '11–15 years':
        return 1.12;
      case '16+ years':
        return 1.18;
      default:
        return 1.00;
    }
  }

  double _educationMultiplier() {
    switch (_selectedEducation) {
      case 'High school diploma':
        return 0.82;
      case 'Some college':
        return 0.88;
      case 'Associate degree':
        return 0.92;
      case 'Bachelor\'s degree':
        return 1.00;
      case 'Master\'s degree':
        return 1.12;
      case 'Doctorate / Professional degree':
        return 1.22;
      case 'Trade school / Certificate':
        return 0.90;
      default:
        return 1.00;
    }
  }

  String _negotiationInsight(int gap) {
    if (gap <= 0) {
      return 'Great news — your current salary meets or exceeds the estimated market rate for your profile. You\'re in a strong position. Consider negotiating for additional benefits or a performance-based raise.';
    } else if (gap < 5000) {
      return 'You\'re close to market rate. A targeted conversation with your manager about a modest adjustment could close this gap. Document your recent wins and come prepared with data.';
    } else if (gap < 15000) {
      return 'There\'s a meaningful gap between your current salary and the market estimate. This is a common situation — and it\'s negotiable. Research comparable roles in your area and prepare a clear case for your value.';
    } else {
      return 'Your salary appears significantly below market rate for your experience and education level. This is worth addressing urgently. Consider a formal salary review, exploring new opportunities, or working with a career coach to build your negotiation strategy.';
    }
  }

  String _recommendedNextStep(int gap) {
    if (gap <= 0) {
      return 'Review your resume and prepare for your next promotion';
    }
    if (gap < 5000) return 'Prepare a salary negotiation script';
    if (gap < 15000) return 'Compare similar roles in your area';
    return 'Talk to Agent Rita — Salary Strategist';
  }

  // ── Validation ────────────────────────────────────────────────────────────

  bool _validate() {
    bool valid = true;
    setState(() {
      _industryError = _selectedIndustry == null
          ? 'Please select your industry.'
          : null;
      _jobTitleError = _selectedJobTitle == null
          ? 'Please select your job title.'
          : null;
      _experienceError = _selectedExperience == null
          ? 'Please select your years of experience.'
          : null;
      _educationError = _selectedEducation == null
          ? 'Please select your education level.'
          : null;
      _stateError = _selectedState == null ? 'Please select your state.' : null;
      final salary = _parseSalary();
      if (salary == 0) {
        _salaryError = 'Please enter your current annual salary.';
      } else if (salary < 10000 || salary > 1000000) {
        _salaryError = 'Please enter a realistic annual salary.';
      } else {
        _salaryError = null;
      }
    });
    if (_industryError != null ||
        _jobTitleError != null ||
        _experienceError != null ||
        _educationError != null ||
        _stateError != null ||
        _salaryError != null) {
      valid = false;
    }
    return valid;
  }

  // ── Calculate ─────────────────────────────────────────────────────────────

  Future<void> _calculate() async {
    if (!_validate()) return;
    setState(() => _isLoading = true);
    final result = await _blsService.fetchWageData(_selectedIndustry!);
    final expMult = _experienceMultiplier();
    final eduMult = _educationMultiplier();
    final estimated = (result.industryMedian * expMult * eduMult).toInt();
    final current = _parseSalary();
    final gap = estimated - current;
    setState(() {
      _blsResult = result;
      _estimatedMarketSalary = estimated;
      _currentSalary = current;
      _payGap = gap;
      _isLoading = false;
      _showResults = true;
    });
    _resultsAnimController.forward(from: 0);
  }

  void _resetForm() {
    setState(() {
      _selectedIndustry = null;
      _selectedJobTitle = null;
      _customJobTitle = null;
      _selectedExperience = null;
      _selectedEducation = null;
      _selectedState = null;
      _salaryController.clear();
      _customJobTitleController.clear();
      _showResults = false;
      _blsResult = null;
      _estimatedMarketSalary = null;
      _currentSalary = null;
      _payGap = null;
      _industryError = null;
      _jobTitleError = null;
      _experienceError = null;
      _educationError = null;
      _stateError = null;
      _salaryError = null;
      _jobTitleAnimated = false;
    });
    _resultsAnimController.reset();
    _jobTitleAnimController.reset();
  }

  void _goToAgentRita() {
    final context2 = context;
    final Map<String, dynamic> ritaContext = {
      'industry': _selectedIndustry ?? '',
      'jobTitle': _effectiveJobTitle,
      'experience': _selectedExperience ?? '',
      'education': _selectedEducation ?? '',
      'state': _selectedState ?? '',
      'currentSalary': _currentSalary ?? 0,
      'estimatedMarketSalary': _estimatedMarketSalary ?? 0,
      'payGap': _payGap ?? 0,
    };
    AppState.instance.setPayGapContext(ritaContext);
    context2.go(AppRoutes.ritaAiScreen);
  }

  // ── Custom Dropdown ───────────────────────────────────────────────────────

  Future<String?> _showSearchableDropdown({
    required BuildContext context,
    required String title,
    required List<String> options,
    required String? currentValue,
    bool searchable = true,
  }) async {
    return showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _SearchableDropdownSheet(
        title: title,
        options: options,
        currentValue: currentValue,
        searchable: searchable,
      ),
    );
  }

  // ── Field Builders ────────────────────────────────────────────────────────

  Widget _buildStepIndicator() {
    return Container(
      margin: const EdgeInsets.only(bottom: 24),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF0F7),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFFFB3D9), width: 1),
      ),
      child: Row(
        children: [
          Container(
            width: 28,
            height: 28,
            decoration: BoxDecoration(
              color: const Color(0xFFE91E8F),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Center(
              child: Text(
                _showResults ? '2' : '1',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _showResults
                      ? 'Step 2 of 2: Review your pay gap estimate'
                      : 'Step 1 of 2: Enter your information',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: const Color(0xFFE91E8F),
                  ),
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: _showResults ? 1.0 : _formProgress,
                    backgroundColor: const Color(0xFFFFD6EC),
                    valueColor: const AlwaysStoppedAnimation<Color>(
                      Color(0xFFE91E8F),
                    ),
                    minHeight: 4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  double get _formProgress {
    int completed = 0;
    if (_selectedIndustry != null) completed++;
    if (_selectedJobTitle != null) completed++;
    if (_selectedExperience != null) completed++;
    if (_selectedEducation != null) completed++;
    if (_selectedState != null) completed++;
    if (_parseSalary() >= 10000) completed++;
    return completed / 6.0;
  }

  Widget _buildDropdownField({
    required String label,
    required String placeholder,
    required String? value,
    required String? errorText,
    required IconData icon,
    required VoidCallback onTap,
    bool enabled = true,
    bool completed = false,
  }) {
    final hasError = errorText != null;
    final borderColor = hasError
        ? const Color(0xFFB91C1C)
        : (value != null ? const Color(0xFFE91E8F) : const Color(0xFFE8D5DF));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              label,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: const Color(0xFF1A1A1A),
              ),
            ),
            if (completed) ...[
              const SizedBox(width: 6),
              const Icon(
                Icons.check_circle_rounded,
                size: 15,
                color: Color(0xFF2D7A4F),
              ),
            ],
          ],
        ),
        const SizedBox(height: 6),
        GestureDetector(
          onTap: enabled ? onTap : null,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            height: 52,
            decoration: BoxDecoration(
              color: enabled ? Colors.white : const Color(0xFFF5F5F5),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: borderColor, width: 1.5),
              boxShadow: value != null && !hasError
                  ? [
                      BoxShadow(
                        color: const Color(0xFFE91E8F).withAlpha(20),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ]
                  : null,
            ),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              child: Row(
                children: [
                  Icon(
                    icon,
                    size: 18,
                    color: value != null
                        ? const Color(0xFFE91E8F)
                        : (enabled
                              ? const Color(0xFF9E9E9E)
                              : const Color(0xFFBDBDBD)),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      value ?? placeholder,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 14,
                        fontWeight: value != null
                            ? FontWeight.w500
                            : FontWeight.w400,
                        color: value != null
                            ? const Color(0xFF1A1A1A)
                            : (enabled
                                  ? const Color(0xFFBDBDBD)
                                  : const Color(0xFFD0D0D0)),
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  Icon(
                    Icons.keyboard_arrow_down_rounded,
                    size: 20,
                    color: enabled
                        ? const Color(0xFF9E9E9E)
                        : const Color(0xFFD0D0D0),
                  ),
                ],
              ),
            ),
          ),
        ),
        if (hasError) ...[
          const SizedBox(height: 5),
          Row(
            children: [
              const Icon(
                Icons.error_outline_rounded,
                size: 13,
                color: Color(0xFFB91C1C),
              ),
              const SizedBox(width: 4),
              Text(
                errorText,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 12,
                  color: const Color(0xFFB91C1C),
                ),
              ),
            ],
          ),
        ],
      ],
    );
  }

  Widget _buildSalaryField() {
    final hasError = _salaryError != null;
    final hasValue = _parseSalary() >= 10000;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              'Current Salary',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: const Color(0xFF1A1A1A),
              ),
            ),
            if (hasValue) ...[
              const SizedBox(width: 6),
              const Icon(
                Icons.check_circle_rounded,
                size: 15,
                color: Color(0xFF2D7A4F),
              ),
            ],
          ],
        ),
        const SizedBox(height: 6),
        TextFormField(
          controller: _salaryController,
          focusNode: _salaryFocusNode,
          keyboardType: TextInputType.number,
          inputFormatters: [_CurrencyInputFormatter()],
          style: GoogleFonts.plusJakartaSans(
            fontSize: 14,
            fontWeight: FontWeight.w500,
            color: const Color(0xFF1A1A1A),
          ),
          decoration: InputDecoration(
            hintText: 'e.g. 75,000',
            hintStyle: GoogleFonts.plusJakartaSans(
              fontSize: 14,
              color: const Color(0xFFBDBDBD),
            ),
            prefixIcon: const Icon(
              Icons.attach_money_rounded,
              size: 18,
              color: Color(0xFF9E9E9E),
            ),
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 14,
              vertical: 14,
            ),
            filled: true,
            fillColor: Colors.white,
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(
                color: hasError
                    ? const Color(0xFFB91C1C)
                    : (hasValue
                          ? const Color(0xFFE91E8F)
                          : const Color(0xFFE8D5DF)),
                width: 1.5,
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color(0xFFE91E8F), width: 2),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(
                color: Color(0xFFB91C1C),
                width: 1.5,
              ),
            ),
            focusedErrorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color(0xFFB91C1C), width: 2),
            ),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
          ),
          onChanged: (_) => setState(() => _salaryError = null),
        ),
        const SizedBox(height: 5),
        if (hasError)
          Row(
            children: [
              const Icon(
                Icons.error_outline_rounded,
                size: 13,
                color: Color(0xFFB91C1C),
              ),
              const SizedBox(width: 4),
              Text(
                _salaryError!,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 12,
                  color: const Color(0xFFB91C1C),
                ),
              ),
            ],
          )
        else
          Text(
            'Enter your current annual salary before taxes.',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 12,
              color: const Color(0xFF9E9E9E),
            ),
          ),
      ],
    );
  }

  // ── Results Section ───────────────────────────────────────────────────────

  Widget _buildResultCard({
    required String title,
    required String value,
    required Color color,
    required IconData icon,
    String? subtitle,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withAlpha(40), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: color.withAlpha(15),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: color.withAlpha(20),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: color, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    color: const Color(0xFF757575),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFF1A1A1A),
                  ),
                ),
                if (subtitle != null) ...[
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 11,
                      color: const Color(0xFF9E9E9E),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInsightCard({
    required String title,
    required String body,
    required Color color,
    required IconData icon,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withAlpha(12),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withAlpha(40), width: 1.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 18),
              const SizedBox(width: 8),
              Text(
                title,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: color,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            body,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 13,
              fontWeight: FontWeight.w400,
              color: const Color(0xFF1A1A1A),
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildResultsSection() {
    final gap = _payGap ?? 0;
    final market = _estimatedMarketSalary ?? 0;
    final current = _currentSalary ?? 0;
    final gapColor = gap > 0
        ? const Color(0xFFB91C1C)
        : const Color(0xFF2D7A4F);
    final gapLabel = gap > 0
        ? '-\$${_formatCurrency(gap)}'
        : '+\$${_formatCurrency(gap.abs())}';

    return FadeTransition(
      opacity: _resultsFade,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFE91E8F), Color(0xFFB5006A)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                const Icon(
                  Icons.insights_rounded,
                  color: Colors.white,
                  size: 22,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Your Pay Gap Estimate',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                      Text(
                        '$_effectiveJobTitle · $_selectedState',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 12,
                          color: Colors.white.withAlpha(200),
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // Salary Cards
          _buildResultCard(
            title: 'Estimated Market Salary',
            value: '\$${_formatCurrency(market)}',
            color: const Color(0xFF2D7A4F),
            icon: Icons.trending_up_rounded,
            subtitle: _blsResult?.occupationLabel,
          ),
          const SizedBox(height: 10),
          _buildResultCard(
            title: 'Your Current Salary',
            value: '\$${_formatCurrency(current)}',
            color: const Color(0xFF123C33),
            icon: Icons.account_balance_wallet_rounded,
          ),
          const SizedBox(height: 10),
          _buildResultCard(
            title: 'Estimated Pay Gap',
            value: gapLabel,
            color: gapColor,
            icon: gap > 0
                ? Icons.arrow_downward_rounded
                : Icons.arrow_upward_rounded,
            subtitle: gap > 0
                ? 'Below estimated market rate'
                : 'At or above market rate',
          ),
          const SizedBox(height: 16),

          // Negotiation Insight
          _buildInsightCard(
            title: 'Negotiation Insight',
            body: _negotiationInsight(gap),
            color: const Color(0xFF7B2D8B),
            icon: Icons.lightbulb_outline_rounded,
          ),
          const SizedBox(height: 10),

          // Recommended Next Step
          _buildInsightCard(
            title: 'Recommended Next Step',
            body: _recommendedNextStep(gap),
            color: const Color(0xFFE91E8F),
            icon: Icons.flag_outlined,
          ),
          const SizedBox(height: 16),

          // Disclaimer
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFFF5F5F5),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(
                  Icons.info_outline_rounded,
                  size: 14,
                  color: Color(0xFF9E9E9E),
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    'Estimate based on sample salary data. Connect verified labor market data for production use.',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 11,
                      color: const Color(0xFF9E9E9E),
                      height: 1.4,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          // Agent Rita CTA
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF7B2D8B), Color(0xFF4A0A5E)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: Colors.white.withAlpha(30),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: const Icon(
                        Icons.smart_toy_rounded,
                        color: Colors.white,
                        size: 20,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Want help understanding your results?',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            'Agent Rita will give you personalized advice',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 12,
                              color: Colors.white.withAlpha(200),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _goToAgentRita,
                    icon: const Icon(Icons.trending_up_rounded, size: 18),
                    label: Text(
                      'Talk to Agent Rita',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: const Color(0xFF7B2D8B),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 0,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // Recalculate
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _resetForm,
              icon: const Icon(Icons.refresh_rounded, size: 18),
              label: Text(
                'Start Over',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
              style: OutlinedButton.styleFrom(
                foregroundColor: const Color(0xFF757575),
                side: const BorderSide(color: Color(0xFFE8D5DF), width: 1.5),
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  String _formatCurrency(int value) {
    final s = value.abs().toString();
    final buffer = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buffer.write(',');
      buffer.write(s[i]);
    }
    return buffer.toString();
  }

  // ── Build ─────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFA),
      appBar: AppBar(
        backgroundColor: const Color(0xFF123C33),
        foregroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18),
          onPressed: () => context.pop(),
        ),
        title: Text(
          'Pay Gap Calculator',
          style: GoogleFonts.plusJakartaSans(
            fontSize: 17,
            fontWeight: FontWeight.w700,
            color: Colors.white,
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 40),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Step indicator
            _buildStepIndicator(),

            if (!_showResults) ...[
              // Form header
              Text(
                'Discover Your Market Value',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                  color: const Color(0xFF1A1A1A),
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'Answer a few questions to get your personalized pay gap estimate.',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 13,
                  color: const Color(0xFF757575),
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 24),

              // 1. Industry
              _buildDropdownField(
                label: 'Industry',
                placeholder: 'Select your industry',
                value: _selectedIndustry,
                errorText: _industryError,
                icon: Icons.business_rounded,
                completed: _selectedIndustry != null,
                onTap: () async {
                  final result = await _showSearchableDropdown(
                    context: context,
                    title: 'Select Industry',
                    options: _industries,
                    currentValue: _selectedIndustry,
                  );
                  if (result != null && result != _selectedIndustry) {
                    setState(() {
                      _selectedIndustry = result;
                      _selectedJobTitle = null;
                      _customJobTitleController.clear();
                      _industryError = null;
                      _jobTitleError = null;
                      _jobTitleAnimated = false;
                    });
                    await Future.delayed(const Duration(milliseconds: 100));
                    _jobTitleAnimController.forward(from: 0);
                    setState(() => _jobTitleAnimated = true);
                  }
                },
              ),
              const SizedBox(height: 16),

              // 2. Job Title
              AnimatedOpacity(
                opacity: _selectedIndustry != null ? 1.0 : 0.5,
                duration: const Duration(milliseconds: 300),
                child: Column(
                  children: [
                    _buildDropdownField(
                      label: 'Job Title',
                      placeholder: _selectedIndustry == null
                          ? 'Select industry first'
                          : 'Select your job title',
                      value: _selectedJobTitle,
                      errorText: _jobTitleError,
                      icon: Icons.work_outline_rounded,
                      enabled: _selectedIndustry != null,
                      completed: _selectedJobTitle != null,
                      onTap: () async {
                        if (_selectedIndustry == null) return;
                        final result = await _showSearchableDropdown(
                          context: context,
                          title: 'Select Job Title',
                          options: _currentJobTitles,
                          currentValue: _selectedJobTitle,
                        );
                        if (result != null) {
                          setState(() {
                            _selectedJobTitle = result;
                            _jobTitleError = null;
                            if (result != 'Other / Not Listed') {
                              _customJobTitleController.clear();
                            }
                          });
                        }
                      },
                    ),
                    // Custom job title input
                    AnimatedSize(
                      duration: const Duration(milliseconds: 300),
                      curve: Curves.easeOut,
                      child: _showCustomJobTitle
                          ? Padding(
                              padding: const EdgeInsets.only(top: 10),
                              child: TextFormField(
                                controller: _customJobTitleController,
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 14,
                                  color: const Color(0xFF1A1A1A),
                                ),
                                decoration: InputDecoration(
                                  hintText: 'Enter your job title',
                                  hintStyle: GoogleFonts.plusJakartaSans(
                                    fontSize: 14,
                                    color: const Color(0xFFBDBDBD),
                                  ),
                                  prefixIcon: const Icon(
                                    Icons.edit_outlined,
                                    size: 18,
                                    color: Color(0xFF9E9E9E),
                                  ),
                                  contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 14,
                                    vertical: 14,
                                  ),
                                  filled: true,
                                  fillColor: Colors.white,
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(12),
                                    borderSide: const BorderSide(
                                      color: Color(0xFFE8D5DF),
                                      width: 1.5,
                                    ),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(12),
                                    borderSide: const BorderSide(
                                      color: Color(0xFFE91E8F),
                                      width: 2,
                                    ),
                                  ),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                ),
                              ),
                            )
                          : const SizedBox.shrink(),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // 3. Years of Experience
              _buildDropdownField(
                label: 'Years of Experience',
                placeholder: 'Select your experience level',
                value: _selectedExperience,
                errorText: _experienceError,
                icon: Icons.timeline_rounded,
                completed: _selectedExperience != null,
                onTap: () async {
                  final result = await _showSearchableDropdown(
                    context: context,
                    title: 'Years of Experience',
                    options: _experienceOptions,
                    currentValue: _selectedExperience,
                    searchable: false,
                  );
                  if (result != null) {
                    setState(() {
                      _selectedExperience = result;
                      _experienceError = null;
                    });
                  }
                },
              ),
              const SizedBox(height: 16),

              // 4. Education Level
              _buildDropdownField(
                label: 'Education Level',
                placeholder: 'Select your education level',
                value: _selectedEducation,
                errorText: _educationError,
                icon: Icons.school_outlined,
                completed: _selectedEducation != null,
                onTap: () async {
                  final result = await _showSearchableDropdown(
                    context: context,
                    title: 'Education Level',
                    options: _educationOptions,
                    currentValue: _selectedEducation,
                    searchable: false,
                  );
                  if (result != null) {
                    setState(() {
                      _selectedEducation = result;
                      _educationError = null;
                    });
                  }
                },
              ),
              const SizedBox(height: 16),

              // 5. State / Location
              _buildDropdownField(
                label: 'State / Location',
                placeholder: 'Select your state',
                value: _selectedState,
                errorText: _stateError,
                icon: Icons.location_on_outlined,
                completed: _selectedState != null,
                onTap: () async {
                  final result = await _showSearchableDropdown(
                    context: context,
                    title: 'Select State',
                    options: _usStates,
                    currentValue: _selectedState,
                  );
                  if (result != null) {
                    setState(() {
                      _selectedState = result;
                      _stateError = null;
                    });
                  }
                },
              ),
              const SizedBox(height: 16),

              // 6. Current Salary
              _buildSalaryField(),
              const SizedBox(height: 28),

              // Calculate Button
              SizedBox(
                width: double.infinity,
                child: AnimatedOpacity(
                  opacity: _allFieldsComplete ? 1.0 : 0.5,
                  duration: const Duration(milliseconds: 300),
                  child: ElevatedButton(
                    onPressed: _allFieldsComplete && !_isLoading
                        ? _calculate
                        : null,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFE91E8F),
                      foregroundColor: Colors.white,
                      disabledBackgroundColor: const Color(0xFFE91E8F),
                      disabledForegroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                      elevation: _allFieldsComplete ? 4 : 0,
                      shadowColor: const Color(0xFFE91E8F).withAlpha(80),
                    ),
                    child: _isLoading
                        ? const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(
                              strokeWidth: 2.5,
                              valueColor: AlwaysStoppedAnimation<Color>(
                                Colors.white,
                              ),
                            ),
                          )
                        : Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(Icons.calculate_rounded, size: 20),
                              const SizedBox(width: 8),
                              Text(
                                'Calculate My Pay Gap',
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                  ),
                ),
              ),
              const SizedBox(height: 24),
            ] else ...[
              _buildResultsSection(),
            ],
          ],
        ),
      ),
    );
  }
}

// ─── Searchable Dropdown Sheet ────────────────────────────────────────────────

class _SearchableDropdownSheet extends StatefulWidget {
  final String title;
  final List<String> options;
  final String? currentValue;
  final bool searchable;

  const _SearchableDropdownSheet({
    required this.title,
    required this.options,
    required this.currentValue,
    this.searchable = true,
  });

  @override
  State<_SearchableDropdownSheet> createState() =>
      _SearchableDropdownSheetState();
}

class _SearchableDropdownSheetState extends State<_SearchableDropdownSheet> {
  late List<String> _filtered;
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _filtered = widget.options;
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _onSearch(String query) {
    setState(() {
      _filtered = query.isEmpty
          ? widget.options
          : widget.options
                .where((o) => o.toLowerCase().contains(query.toLowerCase()))
                .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    final maxHeight = MediaQuery.of(context).size.height * 0.75;
    return Container(
      constraints: BoxConstraints(maxHeight: maxHeight),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Handle
          Container(
            margin: const EdgeInsets.only(top: 12),
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: const Color(0xFFE0E0E0),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          // Title
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    widget.title,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: const Color(0xFF1A1A1A),
                    ),
                  ),
                ),
                IconButton(
                  onPressed: () => Navigator.of(context).pop(),
                  icon: const Icon(
                    Icons.close_rounded,
                    size: 20,
                    color: Color(0xFF9E9E9E),
                  ),
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
              ],
            ),
          ),
          // Search
          if (widget.searchable) ...[
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
              child: TextField(
                controller: _searchController,
                onChanged: _onSearch,
                autofocus: true,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 14,
                  color: const Color(0xFF1A1A1A),
                ),
                decoration: InputDecoration(
                  hintText: 'Search...',
                  hintStyle: GoogleFonts.plusJakartaSans(
                    fontSize: 14,
                    color: const Color(0xFFBDBDBD),
                  ),
                  prefixIcon: const Icon(
                    Icons.search_rounded,
                    size: 18,
                    color: Color(0xFF9E9E9E),
                  ),
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 12,
                  ),
                  filled: true,
                  fillColor: const Color(0xFFF5F5F5),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide.none,
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(
                      color: Color(0xFFE91E8F),
                      width: 1.5,
                    ),
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
            ),
          ],
          const SizedBox(height: 8),
          const Divider(height: 1, color: Color(0xFFF0F0F0)),
          // Options list
          Flexible(
            child: ListView.builder(
              shrinkWrap: true,
              padding: const EdgeInsets.symmetric(vertical: 8),
              itemCount: _filtered.isEmpty ? 1 : _filtered.length,
              itemBuilder: (ctx, i) {
                if (_filtered.isEmpty) {
                  return Padding(
                    padding: const EdgeInsets.all(24),
                    child: Center(
                      child: Text(
                        'No results found',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 14,
                          color: const Color(0xFF9E9E9E),
                        ),
                      ),
                    ),
                  );
                }
                final option = _filtered[i];
                final isSelected = option == widget.currentValue;
                return InkWell(
                  onTap: () => Navigator.of(context).pop(option),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 14,
                    ),
                    color: isSelected
                        ? const Color(0xFFFFF0F7)
                        : Colors.transparent,
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            option,
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 14,
                              fontWeight: isSelected
                                  ? FontWeight.w600
                                  : FontWeight.w400,
                              color: isSelected
                                  ? const Color(0xFFE91E8F)
                                  : const Color(0xFF1A1A1A),
                            ),
                          ),
                        ),
                        if (isSelected)
                          const Icon(
                            Icons.check_rounded,
                            size: 18,
                            color: Color(0xFFE91E8F),
                          ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
