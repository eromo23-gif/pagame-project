import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class _ResourceItem {
  final String title;
  final String category;
  final String readTime;
  final Color categoryColor;
  final IconData icon;
  final String imageUrl;
  final String semanticLabel;

  const _ResourceItem({
    required this.title,
    required this.category,
    required this.readTime,
    required this.categoryColor,
    required this.icon,
    required this.imageUrl,
    required this.semanticLabel,
  });
}

class HomeResourcesWidget extends StatelessWidget {
  final AnimationController entranceController;

  const HomeResourcesWidget({super.key, required this.entranceController});

  static const List<_ResourceItem> _resources = [
    _ResourceItem(
      title: '5 Negotiation Strategies That Actually Work',
      category: 'Pay Equity',
      readTime: '4 min read',
      categoryColor: Color(0xFFE91E8F),
      icon: Icons.article_outlined,
      imageUrl:
          'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?w=400',
      semanticLabel:
          'Professional women in business meeting discussing strategy around a conference table',
    ),
    _ResourceItem(
      title: 'How to Build a Career Roadmap in 2026',
      category: 'Career Growth',
      readTime: '6 min read',
      categoryColor: Color(0xFF123C33),
      icon: Icons.map_outlined,
      imageUrl:
          'https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?w=400',
      semanticLabel:
          'Woman writing career goals on whiteboard in bright modern office',
    ),
    _ResourceItem(
      title: 'Why Women Should Know Their Market Value',
      category: 'Empowerment',
      readTime: '3 min read',
      categoryColor: Color(0xFF7B3FA0),
      icon: Icons.lightbulb_outline_rounded,
      imageUrl:
          'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?w=400',
      semanticLabel:
          'Confident Latina woman presenting to colleagues in a corporate setting',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final fadeAnim = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: entranceController,
        curve: const Interval(0.5, 1.0, curve: Curves.easeOut),
      ),
    );

    return FadeTransition(
      opacity: fadeAnim,
      child: SizedBox(
        height: 200,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 20),
          physics: const BouncingScrollPhysics(),
          itemCount: _resources.length,
          separatorBuilder: (_, __) => const SizedBox(width: 14),
          itemBuilder: (context, index) {
            return _ResourceCard(resource: _resources[index]);
          },
        ),
      ),
    );
  }
}

class _ResourceCard extends StatelessWidget {
  final _ResourceItem resource;

  const _ResourceCard({required this.resource});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        // TODO: Navigate to resource detail
      },
      child: Container(
        width: 220,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withAlpha(13),
              blurRadius: 12,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Image area
            Expanded(
              flex: 5,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  Image.network(
                    resource.imageUrl,
                    fit: BoxFit.cover,
                    semanticLabel: resource.semanticLabel,
                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        color: const Color(0xFFF0F7F4),
                        child: Icon(
                          resource.icon,
                          size: 36,
                          color: resource.categoryColor.withAlpha(128),
                        ),
                      );
                    },
                  ),
                  // Category badge overlay
                  Positioned(
                    top: 10,
                    left: 10,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: resource.categoryColor,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        resource.category,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            // Content area
            Expanded(
              flex: 4,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      resource.title,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: const Color(0xFF1A1A1A),
                        height: 1.35,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Row(
                      children: [
                        Icon(
                          Icons.access_time_rounded,
                          size: 12,
                          color: const Color(0xFF9E9E9E),
                        ),
                        const SizedBox(width: 4),
                        Text(
                          resource.readTime,
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 11,
                            fontWeight: FontWeight.w400,
                            color: const Color(0xFF9E9E9E),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
