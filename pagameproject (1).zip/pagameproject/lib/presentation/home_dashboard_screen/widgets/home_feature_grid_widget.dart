import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';

class _FeatureItem {
  final IconData icon;
  final String title;
  final String description;
  final Color iconColor;
  final Color bgColor;
  final Color accentColor;
  final String buttonLabel;
  final String route;

  const _FeatureItem({
    required this.icon,
    required this.title,
    required this.description,
    required this.iconColor,
    required this.bgColor,
    required this.accentColor,
    required this.buttonLabel,
    required this.route,
  });
}

class HomeFeatureGridWidget extends StatefulWidget {
  final AnimationController entranceController;
  final bool isTablet;

  const HomeFeatureGridWidget({
    super.key,
    required this.entranceController,
    required this.isTablet,
  });

  @override
  State<HomeFeatureGridWidget> createState() => _HomeFeatureGridWidgetState();
}

class _HomeFeatureGridWidgetState extends State<HomeFeatureGridWidget> {
  late ScrollController _scrollController;

  // Her Promotion Club removed from home page per requirements
  static const List<_FeatureItem> _features = [
    _FeatureItem(
      icon: Icons.auto_awesome_rounded,
      title: 'RITA AI',
      description:
          'AI-powered career guidance designed for women\'s advancement.',
      iconColor: Color(0xFFE91E8F),
      bgColor: Color(0xFFFFF0F7),
      accentColor: Color(0xFFE91E8F),
      buttonLabel: 'Explore',
      route: '/rita-ai',
    ),
    _FeatureItem(
      icon: Icons.calculate_outlined,
      title: 'Pay Calculator',
      description: 'Understand your pay gap and negotiate with confidence.',
      iconColor: Color(0xFF123C33),
      bgColor: Color(0xFFF0F7F4),
      accentColor: Color(0xFF123C33),
      buttonLabel: 'Calculate',
      route: '/gender-pay-calculator',
    ),
    _FeatureItem(
      icon: Icons.map_outlined,
      title: 'Career Journey Map',
      description: 'Visualize your career path and hit key milestones.',
      iconColor: Color(0xFF7B3FA0),
      bgColor: Color(0xFFF5F0FA),
      accentColor: Color(0xFF7B3FA0),
      buttonLabel: 'Start Map',
      route: '/career-journey-map',
    ),
    _FeatureItem(
      icon: Icons.people_alt_outlined,
      title: 'Coach Matching',
      description: 'Connect with expert human career coaches, 1:1.',
      iconColor: Color(0xFFD97706),
      bgColor: Color(0xFFFFF8EC),
      accentColor: Color(0xFFD97706),
      buttonLabel: 'Find Coach',
      route: '/career-coach-matching',
    ),
  ];

  @override
  void initState() {
    super.initState();
    _scrollController = ScrollController();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 260,
      child: ListView.builder(
        controller: _scrollController,
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.only(left: 20, right: 8),
        itemCount: _features.length,
        itemBuilder: (context, index) {
          final delay = index * 0.1;
          final endTime = (delay + 0.5).clamp(0.0, 1.0);
          final fadeAnim = Tween<double>(begin: 0, end: 1).animate(
            CurvedAnimation(
              parent: widget.entranceController,
              curve: Interval(delay, endTime, curve: Curves.easeOut),
            ),
          );
          final slideAnim =
              Tween<Offset>(
                begin: const Offset(0.3, 0),
                end: Offset.zero,
              ).animate(
                CurvedAnimation(
                  parent: widget.entranceController,
                  curve: Interval(delay, endTime, curve: Curves.easeOutCubic),
                ),
              );

          return FadeTransition(
            opacity: fadeAnim,
            child: SlideTransition(
              position: slideAnim,
              child: Padding(
                padding: const EdgeInsets.only(right: 14),
                child: _FeatureCard(feature: _features[index]),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _FeatureCard extends StatefulWidget {
  final _FeatureItem feature;
  const _FeatureCard({required this.feature});

  @override
  State<_FeatureCard> createState() => _FeatureCardState();
}

class _FeatureCardState extends State<_FeatureCard> {
  bool _pressed = false;
  bool _buttonLoading = false;

  void _onButtonTap() async {
    setState(() => _buttonLoading = true);
    await Future.delayed(const Duration(milliseconds: 800));
    if (mounted) {
      setState(() => _buttonLoading = false);
      context.push(widget.feature.route);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final cardBg = isDark ? const Color(0xFF2D2D2D) : Colors.white;
    final titleColor = isDark
        ? const Color(0xFFE6E6E6)
        : const Color(0xFF1A1A1A);
    final descColor = isDark
        ? const Color(0xFFAAAAAA)
        : const Color(0xFF9E9E9E);

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        context.push(widget.feature.route);
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          width: 280,
          decoration: BoxDecoration(
            color: cardBg,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: widget.feature.accentColor.withAlpha(30),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: widget.feature.accentColor.withAlpha(isDark ? 10 : 20),
                blurRadius: 16,
                offset: const Offset(0, 6),
              ),
              BoxShadow(
                color: Colors.black.withAlpha(isDark ? 20 : 8),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Top accent strip
                Container(
                  height: 4,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        widget.feature.accentColor,
                        widget.feature.accentColor.withAlpha(120),
                      ],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 14, 18, 14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Icon + title row
                      Row(
                        children: [
                          Container(
                            width: 42,
                            height: 42,
                            decoration: BoxDecoration(
                              color: widget.feature.bgColor,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Icon(
                              widget.feature.icon,
                              size: 22,
                              color: widget.feature.iconColor,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  widget.feature.title,
                                  style: GoogleFonts.plusJakartaSans(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w700,
                                    color: titleColor,
                                    height: 1.2,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                const SizedBox(height: 3),
                                Text(
                                  widget.feature.description,
                                  style: GoogleFonts.plusJakartaSans(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w400,
                                    color: descColor,
                                    height: 1.4,
                                  ),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      // Preview widget
                      _buildPreview(widget.feature, isDark),
                      const SizedBox(height: 14),
                      // CTA button
                      SizedBox(
                        width: double.infinity,
                        height: 38,
                        child: ElevatedButton(
                          onPressed: _buttonLoading ? null : _onButtonTap,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: widget.feature.accentColor,
                            foregroundColor: Colors.white,
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            padding: EdgeInsets.zero,
                          ),
                          child: _buttonLoading
                              ? const SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Colors.white,
                                  ),
                                )
                              : Text(
                                  widget.feature.buttonLabel,
                                  style: GoogleFonts.plusJakartaSans(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPreview(_FeatureItem feature, bool isDark) {
    final previewBg = isDark ? const Color(0xFF3A3A3A) : feature.bgColor;

    if (feature.route == '/rita-ai') {
      return Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: previewBg,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          children: [
            Container(
              width: 28,
              height: 28,
              decoration: BoxDecoration(
                color: feature.accentColor.withAlpha(40),
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.auto_awesome_rounded,
                size: 14,
                color: feature.accentColor,
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: isDark ? const Color(0xFF4A4A4A) : Colors.white,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  'How can I advance my career?',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 10,
                    color: isDark
                        ? const Color(0xFFCCCCCC)
                        : const Color(0xFF757575),
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
          ],
        ),
      );
    } else if (feature.route == '/gender-pay-calculator') {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: previewBg,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Potential Gap',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 11,
                color: isDark
                    ? const Color(0xFFAAAAAA)
                    : const Color(0xFF757575),
              ),
            ),
            Text(
              '\$15,000',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                color: feature.accentColor,
              ),
            ),
          ],
        ),
      );
    } else if (feature.route == '/career-journey-map') {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: previewBg,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '3/6 Milestones',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: feature.accentColor,
                  ),
                ),
                Text(
                  '50%',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: feature.accentColor,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: 0.5,
                backgroundColor: isDark
                    ? const Color(0xFF4A4A4A)
                    : Colors.white,
                valueColor: AlwaysStoppedAnimation<Color>(feature.accentColor),
                minHeight: 6,
              ),
            ),
          ],
        ),
      );
    } else {
      // Coach Matching preview
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: previewBg,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          children: [
            ...['M', 'P', 'T'].map(
              (initial) => Container(
                width: 28,
                height: 28,
                margin: const EdgeInsets.only(right: 4),
                decoration: BoxDecoration(
                  color: feature.accentColor.withAlpha(40),
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: isDark ? const Color(0xFF4A4A4A) : Colors.white,
                    width: 1.5,
                  ),
                ),
                child: Center(
                  child: Text(
                    initial,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: feature.accentColor,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 6),
            Text(
              '3 coaches ready',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 10,
                color: isDark
                    ? const Color(0xFFAAAAAA)
                    : const Color(0xFF757575),
              ),
            ),
          ],
        ),
      );
    }
  }
}
