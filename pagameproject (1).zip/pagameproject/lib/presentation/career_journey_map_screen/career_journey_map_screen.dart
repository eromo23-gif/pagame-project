import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/app_state.dart';

class CareerJourneyMapScreen extends StatefulWidget {
  const CareerJourneyMapScreen({super.key});

  @override
  State<CareerJourneyMapScreen> createState() => _CareerJourneyMapScreenState();
}

class _CareerJourneyMapScreenState extends State<CareerJourneyMapScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _entranceController;
  bool _journeyStarted = false;
  bool _isStarting = false;

  static const List<_Milestone> _milestones = [
    _Milestone(
      step: '01',
      title: 'Discover Your Goals',
      description:
          'Clarify what success looks like for you. Define your values, strengths, and career aspirations.',
      icon: Icons.explore_outlined,
      isActive: true,
    ),
    _Milestone(
      step: '02',
      title: 'Build Your Skills',
      description:
          'Identify skill gaps and take targeted action. Courses, certifications, and mentorship all count.',
      icon: Icons.school_outlined,
      isActive: true,
    ),
    _Milestone(
      step: '03',
      title: 'Strengthen Your Résumé',
      description:
          'Craft a compelling narrative that highlights your impact, not just your duties.',
      icon: Icons.description_outlined,
      isActive: false,
    ),
    _Milestone(
      step: '04',
      title: 'Connect with Support',
      description:
          'Build your network, find a mentor, and connect with a career coach who gets your goals.',
      icon: Icons.people_outline_rounded,
      isActive: false,
    ),
    _Milestone(
      step: '05',
      title: 'Apply for Opportunities',
      description:
          'Put yourself out there with confidence. Apply strategically and track your progress.',
      icon: Icons.send_outlined,
      isActive: false,
    ),
    _Milestone(
      step: '06',
      title: 'Advance & Negotiate',
      description:
          'Know your worth. Negotiate your salary, advocate for promotions, and own your growth.',
      icon: Icons.trending_up_rounded,
      isActive: false,
    ),
  ];

  @override
  void initState() {
    super.initState();
    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _entranceController.forward();
    });
  }

  @override
  void dispose() {
    _entranceController.dispose();
    super.dispose();
  }

  Future<void> _startJourney() async {
    setState(() => _isStarting = true);
    await Future.delayed(const Duration(milliseconds: 1500));
    if (mounted) {
      setState(() {
        _isStarting = false;
        _journeyStarted = true;
      });
      AppState().markCareerJourneyStarted();
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottomPadding = MediaQuery.of(context).padding.bottom;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF1A1A1A) : const Color(0xFFFAFAFA);
    final cardColor = isDark ? const Color(0xFF2D2D2D) : Colors.white;
    final titleColor = isDark
        ? const Color(0xFFE6E6E6)
        : const Color(0xFF123C33);
    final subtitleColor = isDark
        ? const Color(0xFFAAAAAA)
        : const Color(0xFF9E9E9E);

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        backgroundColor: const Color(0xFF123C33),
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text(
          'Career Journey Map',
          style: GoogleFonts.plusJakartaSans(
            fontSize: 17,
            fontWeight: FontWeight.w700,
            color: Colors.white,
          ),
        ),
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_rounded,
            color: Colors.white,
            size: 20,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.fromLTRB(20, 20, 20, bottomPadding + 40),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Hero banner with entrance animation
            _buildEntranceWidget(
              index: 0,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF123C33), Color(0xFF1A5C48)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF123C33).withAlpha(60),
                      blurRadius: 20,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(
                      Icons.map_rounded,
                      color: Color(0xFFE91E8F),
                      size: 32,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Your Path to Career Success',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Chart your career path step by step. Identify key milestones and turn your aspirations into reality.',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 13,
                        color: Colors.white.withAlpha(204),
                        height: 1.5,
                      ),
                    ),
                    const SizedBox(height: 18),
                    if (_journeyStarted)
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 12,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xFF4CAF82).withAlpha(51),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: const Color(0xFF4CAF82).withAlpha(102),
                          ),
                        ),
                        child: Row(
                          children: [
                            const Icon(
                              Icons.check_circle_rounded,
                              color: Color(0xFF4CAF82),
                              size: 18,
                            ),
                            const SizedBox(width: 10),
                            Text(
                              'Journey started! Keep going 🚀',
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                color: const Color(0xFF4CAF82),
                              ),
                            ),
                          ],
                        ),
                      )
                    else
                      _AnimatedCTAButton(
                        label: 'Start My Journey',
                        isLoading: _isStarting,
                        onTap: _isStarting ? null : _startJourney,
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 28),
            _buildEntranceWidget(
              index: 1,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Your Milestones',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: titleColor,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Six steps to advance your career with confidence',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 13,
                      color: subtitleColor,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            // Milestones with staggered entrance
            ...List.generate(_milestones.length, (index) {
              final milestone = _milestones[index];
              final isLast = index == _milestones.length - 1;
              return _buildEntranceWidget(
                index: index + 2,
                child: _MilestoneCard(
                  milestone: milestone,
                  isLast: isLast,
                  isDark: isDark,
                  cardColor: cardColor,
                ),
              );
            }),
            const SizedBox(height: 24),
            _buildEntranceWidget(
              index: 9,
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: isDark
                      ? const Color(0xFF3A2030)
                      : const Color(0xFFFFF0F7),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: const Color(0xFFE91E8F).withAlpha(51),
                  ),
                ),
                child: Row(
                  children: [
                    const Icon(
                      Icons.auto_awesome_rounded,
                      color: Color(0xFFE91E8F),
                      size: 18,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'Future version: personalized insights and AI-powered recommendations for each milestone.',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 12,
                          color: const Color(0xFFB5157A),
                          height: 1.4,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEntranceWidget({required int index, required Widget child}) {
    final delay = (index * 0.08).clamp(0.0, 0.8);
    final end = (delay + 0.35).clamp(0.0, 1.0);

    final fade = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _entranceController,
        curve: Interval(delay, end, curve: Curves.easeOut),
      ),
    );
    final slide = Tween<Offset>(begin: const Offset(0, 0.15), end: Offset.zero)
        .animate(
          CurvedAnimation(
            parent: _entranceController,
            curve: Interval(delay, end, curve: Curves.easeOutCubic),
          ),
        );

    return FadeTransition(
      opacity: fade,
      child: SlideTransition(position: slide, child: child),
    );
  }
}

class _Milestone {
  final String step;
  final String title;
  final String description;
  final IconData icon;
  final bool isActive;

  const _Milestone({
    required this.step,
    required this.title,
    required this.description,
    required this.icon,
    required this.isActive,
  });
}

class _MilestoneCard extends StatefulWidget {
  final _Milestone milestone;
  final bool isLast;
  final bool isDark;
  final Color cardColor;

  const _MilestoneCard({
    required this.milestone,
    required this.isLast,
    required this.isDark,
    required this.cardColor,
  });

  @override
  State<_MilestoneCard> createState() => _MilestoneCardState();
}

class _MilestoneCardState extends State<_MilestoneCard> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final activeColor = widget.milestone.isActive
        ? const Color(0xFFE91E8F)
        : (widget.isDark ? const Color(0xFF555555) : const Color(0xFFE0E0E0));
    final titleColor = widget.isDark
        ? const Color(0xFFE6E6E6)
        : const Color(0xFF1A1A1A);
    final descColor = widget.isDark
        ? const Color(0xFFAAAAAA)
        : const Color(0xFF757575);
    final borderColor = widget.isDark
        ? const Color(0xFF4A4A4A)
        : const Color(0xFFE8D5DF);

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.98 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: IntrinsicHeight(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Timeline column
              Column(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: widget.milestone.isActive
                          ? const Color(0xFFE91E8F)
                          : (widget.isDark
                                ? const Color(0xFF3A3A3A)
                                : const Color(0xFFF5F5F5)),
                      shape: BoxShape.circle,
                      boxShadow: widget.milestone.isActive
                          ? [
                              BoxShadow(
                                color: const Color(0xFFE91E8F).withAlpha(60),
                                blurRadius: 12,
                                offset: const Offset(0, 4),
                              ),
                            ]
                          : null,
                    ),
                    child: Icon(
                      widget.milestone.icon,
                      size: 20,
                      color: widget.milestone.isActive
                          ? Colors.white
                          : (widget.isDark
                                ? const Color(0xFF666666)
                                : const Color(0xFFBDBDBD)),
                    ),
                  ),
                  if (!widget.isLast)
                    Expanded(
                      child: Container(
                        width: 2,
                        margin: const EdgeInsets.symmetric(vertical: 4),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [activeColor, activeColor.withAlpha(30)],
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(width: 16),
              // Card
              Expanded(
                child: Container(
                  margin: const EdgeInsets.only(bottom: 16),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: widget.cardColor,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: widget.milestone.isActive
                          ? const Color(0xFFE91E8F).withAlpha(40)
                          : borderColor,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withAlpha(widget.isDark ? 20 : 8),
                        blurRadius: 10,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 3,
                            ),
                            decoration: BoxDecoration(
                              color: widget.milestone.isActive
                                  ? const Color(0xFFE91E8F).withAlpha(20)
                                  : (widget.isDark
                                        ? const Color(0xFF3A3A3A)
                                        : const Color(0xFFF5F5F5)),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              'Step ${widget.milestone.step}',
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 10,
                                fontWeight: FontWeight.w700,
                                color: widget.milestone.isActive
                                    ? const Color(0xFFE91E8F)
                                    : (widget.isDark
                                          ? const Color(0xFF888888)
                                          : const Color(0xFFBDBDBD)),
                              ),
                            ),
                          ),
                          if (widget.milestone.isActive) ...[
                            const SizedBox(width: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 3,
                              ),
                              decoration: BoxDecoration(
                                color: const Color(0xFF4CAF82).withAlpha(20),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                'In Progress',
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w600,
                                  color: const Color(0xFF4CAF82),
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        widget.milestone.title,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: titleColor,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        widget.milestone.description,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 12,
                          color: descColor,
                          height: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AnimatedCTAButton extends StatefulWidget {
  final String label;
  final bool isLoading;
  final VoidCallback? onTap;

  const _AnimatedCTAButton({
    required this.label,
    required this.isLoading,
    this.onTap,
  });

  @override
  State<_AnimatedCTAButton> createState() => _AnimatedCTAButtonState();
}

class _AnimatedCTAButtonState extends State<_AnimatedCTAButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap?.call();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: SizedBox(
          width: double.infinity,
          height: 48,
          child: ElevatedButton(
            onPressed: widget.onTap,
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFE91E8F),
              foregroundColor: Colors.white,
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: widget.isLoading
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      color: Colors.white,
                    ),
                  )
                : Text(
                    widget.label,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
          ),
        ),
      ),
    );
  }
}
