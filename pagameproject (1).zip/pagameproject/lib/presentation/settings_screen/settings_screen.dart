import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/app_state.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _entranceController;
  final AppState _appState = AppState();

  @override
  void initState() {
    super.initState();
    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _entranceController.forward();
    });
    _appState.addListener(_onStateChanged);
  }

  void _onStateChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _entranceController.dispose();
    _appState.removeListener(_onStateChanged);
    super.dispose();
  }

  Widget _buildEntrance({required int index, required Widget child}) {
    final delay = (index * 0.1).clamp(0.0, 0.7);
    final end = (delay + 0.4).clamp(0.0, 1.0);
    final fade = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _entranceController,
        curve: Interval(delay, end, curve: Curves.easeOut),
      ),
    );
    final slide = Tween<Offset>(begin: const Offset(0, 0.1), end: Offset.zero)
        .animate(
          CurvedAnimation(
            parent: _entranceController,
            curve: Interval(delay, end, curve: Curves.easeOutCubic),
          ),
        );
    return FadeTransition(
      opacity: fade,
      child: SlideTransition(position: slide, child: child),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bottomPadding = MediaQuery.of(context).padding.bottom;
    final isDark = _appState.isDarkMode;
    final bgColor = isDark ? const Color(0xFF1A1A1A) : const Color(0xFFFAFAFA);
    final cardColor = isDark ? const Color(0xFF2D2D2D) : Colors.white;
    final borderColor = isDark
        ? const Color(0xFF4A4A4A)
        : const Color(0xFFE8D5DF);
    final titleColor = isDark
        ? const Color(0xFFE6E6E6)
        : const Color(0xFF1A1A1A);
    final subtitleColor = isDark
        ? const Color(0xFFAAAAAA)
        : const Color(0xFF9E9E9E);
    final sectionHeaderColor = isDark
        ? const Color(0xFF888888)
        : const Color(0xFF9E9E9E);

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        backgroundColor: const Color(0xFF123C33),
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text(
          'Settings',
          style: GoogleFonts.plusJakartaSans(
            fontSize: 17,
            fontWeight: FontWeight.w700,
            color: Colors.white,
          ),
        ),
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_rounded,
            color: Colors.white,
            size: 20,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.fromLTRB(20, 24, 20, bottomPadding + 40),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Account section
            _buildEntrance(
              index: 0,
              child: _SectionLabel(title: 'Account', color: sectionHeaderColor),
            ),
            const SizedBox(height: 8),
            _buildEntrance(
              index: 1,
              child: _SettingsCard(
                isDark: isDark,
                cardColor: cardColor,
                borderColor: borderColor,
                children: [
                  _SettingsRow(
                    icon: Icons.person_outline_rounded,
                    iconColor: const Color(0xFFE91E8F),
                    iconBg: const Color(0xFFFFF0F7),
                    title: 'Edit Profile',
                    subtitle: 'Update your name and email',
                    isDark: isDark,
                    titleColor: titleColor,
                    subtitleColor: subtitleColor,
                    onTap: () {},
                  ),
                  _Divider(isDark: isDark),
                  _SettingsRow(
                    icon: Icons.lock_outline_rounded,
                    iconColor: const Color(0xFF123C33),
                    iconBg: const Color(0xFFE8F5F0),
                    title: 'Change Password',
                    subtitle: 'Update your account password',
                    isDark: isDark,
                    titleColor: titleColor,
                    subtitleColor: subtitleColor,
                    onTap: () {},
                  ),
                  _Divider(isDark: isDark),
                  // Dark Mode Toggle
                  Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 14,
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 36,
                          height: 36,
                          decoration: BoxDecoration(
                            color: isDark
                                ? const Color(0xFF3A3A3A)
                                : const Color(0xFFF5F5F5),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Icon(
                            isDark
                                ? Icons.dark_mode_rounded
                                : Icons.light_mode_rounded,
                            color: isDark
                                ? const Color(0xFFE91E8F)
                                : const Color(0xFF757575),
                            size: 18,
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Dark Mode',
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w500,
                                  color: titleColor,
                                ),
                              ),
                              Text(
                                isDark
                                    ? 'Dark theme active'
                                    : 'Light theme active',
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 12,
                                  color: subtitleColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Switch(
                          value: isDark,
                          onChanged: (value) {
                            _appState.toggleDarkMode(value);
                          },
                          activeThumbColor: const Color(0xFFE91E8F),
                          activeTrackColor: const Color(
                            0xFFE91E8F,
                          ).withAlpha(80),
                          inactiveThumbColor: Colors.white,
                          inactiveTrackColor: isDark
                              ? const Color(0xFF4A4A4A)
                              : const Color(0xFFE0E0E0),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            // Notifications section
            _buildEntrance(
              index: 2,
              child: _SectionLabel(
                title: 'Notifications',
                color: sectionHeaderColor,
              ),
            ),
            const SizedBox(height: 8),
            _buildEntrance(
              index: 3,
              child: _SettingsCard(
                isDark: isDark,
                cardColor: cardColor,
                borderColor: borderColor,
                children: [
                  _SettingsToggleRow(
                    icon: Icons.notifications_outlined,
                    iconColor: const Color(0xFFE91E8F),
                    iconBg: const Color(0xFFFFF0F7),
                    title: 'Push Notifications',
                    subtitle: 'Career tips and updates',
                    isDark: isDark,
                    titleColor: titleColor,
                    subtitleColor: subtitleColor,
                    value: true,
                    onChanged: (_) {},
                  ),
                  _Divider(isDark: isDark),
                  _SettingsToggleRow(
                    icon: Icons.email_outlined,
                    iconColor: const Color(0xFF123C33),
                    iconBg: const Color(0xFFE8F5F0),
                    title: 'Email Updates',
                    subtitle: 'Weekly career insights',
                    isDark: isDark,
                    titleColor: titleColor,
                    subtitleColor: subtitleColor,
                    value: false,
                    onChanged: (_) {},
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            // Privacy section
            _buildEntrance(
              index: 4,
              child: _SectionLabel(title: 'Privacy', color: sectionHeaderColor),
            ),
            const SizedBox(height: 8),
            _buildEntrance(
              index: 5,
              child: _SettingsCard(
                isDark: isDark,
                cardColor: cardColor,
                borderColor: borderColor,
                children: [
                  _SettingsRow(
                    icon: Icons.privacy_tip_outlined,
                    iconColor: const Color(0xFF7B3FA0),
                    iconBg: const Color(0xFFF5F0FA),
                    title: 'Privacy Policy',
                    subtitle: 'How we use your data',
                    isDark: isDark,
                    titleColor: titleColor,
                    subtitleColor: subtitleColor,
                    onTap: () {},
                  ),
                  _Divider(isDark: isDark),
                  _SettingsRow(
                    icon: Icons.delete_outline_rounded,
                    iconColor: const Color(0xFFB91C1C),
                    iconBg: const Color(0xFFFEF2F2),
                    title: 'Delete Account',
                    subtitle: 'Permanently remove your data',
                    isDark: isDark,
                    titleColor: const Color(0xFFB91C1C),
                    subtitleColor: subtitleColor,
                    onTap: () {},
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            _buildEntrance(
              index: 6,
              child: Center(
                child: Text(
                  'Págame Project v1.0.0',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 12,
                    color: subtitleColor,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String title;
  final Color color;
  const _SectionLabel({required this.title, required this.color});

  @override
  Widget build(BuildContext context) {
    return Text(
      title.toUpperCase(),
      style: GoogleFonts.plusJakartaSans(
        fontSize: 11,
        fontWeight: FontWeight.w700,
        color: color,
        letterSpacing: 1.0,
      ),
    );
  }
}

class _SettingsCard extends StatelessWidget {
  final List<Widget> children;
  final bool isDark;
  final Color cardColor;
  final Color borderColor;

  const _SettingsCard({
    required this.children,
    required this.isDark,
    required this.cardColor,
    required this.borderColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(isDark ? 20 : 8),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(children: children),
    );
  }
}

class _Divider extends StatelessWidget {
  final bool isDark;
  const _Divider({required this.isDark});

  @override
  Widget build(BuildContext context) {
    return Divider(
      height: 1,
      thickness: 1,
      color: isDark ? const Color(0xFF3A3A3A) : const Color(0xFFF5F0F3),
      indent: 58,
    );
  }
}

class _SettingsRow extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final Color iconBg;
  final String title;
  final String subtitle;
  final bool isDark;
  final Color titleColor;
  final Color subtitleColor;
  final VoidCallback onTap;

  const _SettingsRow({
    required this.icon,
    required this.iconColor,
    required this.iconBg,
    required this.title,
    required this.subtitle,
    required this.isDark,
    required this.titleColor,
    required this.subtitleColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: iconBg,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: iconColor, size: 18),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                      color: titleColor,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 12,
                      color: subtitleColor,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.chevron_right_rounded,
              size: 20,
              color: isDark ? const Color(0xFF666666) : const Color(0xFFBDBDBD),
            ),
          ],
        ),
      ),
    );
  }
}

class _SettingsToggleRow extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final Color iconBg;
  final String title;
  final String subtitle;
  final bool isDark;
  final Color titleColor;
  final Color subtitleColor;
  final bool value;
  final ValueChanged<bool> onChanged;

  const _SettingsToggleRow({
    required this.icon,
    required this.iconColor,
    required this.iconBg,
    required this.title,
    required this.subtitle,
    required this.isDark,
    required this.titleColor,
    required this.subtitleColor,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: iconBg,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: iconColor, size: 18),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 15,
                    fontWeight: FontWeight.w500,
                    color: titleColor,
                  ),
                ),
                Text(
                  subtitle,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 12,
                    color: subtitleColor,
                  ),
                ),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeThumbColor: const Color(0xFFE91E8F),
            activeTrackColor: const Color(0xFFE91E8F).withAlpha(80),
          ),
        ],
      ),
    );
  }
}
