import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/app_state.dart';

class HelpSupportScreen extends StatefulWidget {
  const HelpSupportScreen({super.key});

  @override
  State<HelpSupportScreen> createState() => _HelpSupportScreenState();
}

class _HelpSupportScreenState extends State<HelpSupportScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _entranceController;
  final AppState _appState = AppState();
  int _selectedTab = 0;
  final TextEditingController _searchController = TextEditingController();
  final TextEditingController _subjectController = TextEditingController();
  final TextEditingController _messageController = TextEditingController();
  bool _isSubmitting = false;

  final List<Map<String, String>> _faqs = [
    {
      'q': 'How do I use the Pay Calculator?',
      'a':
          'Navigate to the Gender Pay Calculator from the home screen or Career Tools. Select your industry, job title, experience, education, state, and enter your current salary. Tap "Calculate" to see your personalized pay gap analysis.',
    },
    {
      'q': 'What is the Career Journey Map?',
      'a':
          'The Career Journey Map is a visual tool that helps you track your career milestones and progress. It shows your current stage, completed achievements, and upcoming goals to help you stay on track.',
    },
    {
      'q': 'How do I connect with a coach?',
      'a':
          'Go to Career Coach Matching from the home screen. Complete the Career Assessment questionnaire (15 questions) to get a personalized coach recommendation based on your goals and challenges.',
    },
    {
      'q': 'How is my Career Score calculated?',
      'a':
          'Your Career Score (0–100) is based on your profile completeness, tools used, milestones achieved, and engagement with the platform. Complete more activities to increase your score.',
    },
    {
      'q': 'Can I save my pay calculations?',
      'a':
          'Yes! After running a pay gap calculation, your results are automatically saved to your profile under "Saved Results." You can view, compare, and delete saved calculations anytime.',
    },
    {
      'q': 'What is Her Promotion Club?',
      'a':
          'Her Promotion Club is an exclusive community for women in the workplace. Members get access to premium resources, networking opportunities, expert webinars, and personalized career guidance.',
    },
  ];

  final List<Map<String, dynamic>> _resources = [
    {
      'icon': Icons.menu_book_outlined,
      'title': 'Getting Started Guide',
      'desc': 'Learn how to use all features',
      'color': const Color(0xFFE91E8F),
      'bg': const Color(0xFFFFF0F7),
    },
    {
      'icon': Icons.play_circle_outline_rounded,
      'title': 'Video Tutorials',
      'desc': 'Step-by-step video walkthroughs',
      'color': const Color(0xFF123C33),
      'bg': const Color(0xFFE8F5F0),
    },
    {
      'icon': Icons.library_books_outlined,
      'title': 'Career Resources',
      'desc': 'Articles, templates & tools',
      'color': const Color(0xFF7B2D8B),
      'bg': const Color(0xFFF3E8F9),
    },
  ];

  @override
  void initState() {
    super.initState();
    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _entranceController.forward();
    });
    _appState.addListener(_onStateChanged);
  }

  void _onStateChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _entranceController.dispose();
    _searchController.dispose();
    _subjectController.dispose();
    _messageController.dispose();
    _appState.removeListener(_onStateChanged);
    super.dispose();
  }

  Widget _buildEntrance({required int index, required Widget child}) {
    final delay = (index * 0.08).clamp(0.0, 0.65);
    final end = (delay + 0.35).clamp(0.0, 1.0);
    final fade = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _entranceController,
        curve: Interval(delay, end, curve: Curves.easeOut),
      ),
    );
    final slide = Tween<Offset>(begin: const Offset(0, 0.1), end: Offset.zero)
        .animate(
          CurvedAnimation(
            parent: _entranceController,
            curve: Interval(delay, end, curve: Curves.easeOutCubic),
          ),
        );
    return FadeTransition(
      opacity: fade,
      child: SlideTransition(position: slide, child: child),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bottomPadding = MediaQuery.of(context).padding.bottom;
    final isDark = _appState.isDarkMode;
    final bgColor = isDark ? const Color(0xFF1A1A1A) : const Color(0xFFFAFAFA);
    final cardColor = isDark ? const Color(0xFF2D2D2D) : Colors.white;
    final borderColor = isDark
        ? const Color(0xFF4A4A4A)
        : const Color(0xFFE8D5DF);
    final titleColor = isDark
        ? const Color(0xFFE6E6E6)
        : const Color(0xFF1A1A1A);
    final subtitleColor = isDark
        ? const Color(0xFFAAAAAA)
        : const Color(0xFF757575);

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        backgroundColor: const Color(0xFF123C33),
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text(
          'Help & Support',
          style: GoogleFonts.plusJakartaSans(
            fontSize: 17,
            fontWeight: FontWeight.w700,
            color: Colors.white,
          ),
        ),
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_rounded,
            color: Colors.white,
            size: 20,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: Column(
        children: [
          // Tab bar
          Container(
            color: isDark ? const Color(0xFF2D2D2D) : Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            child: Row(
              children: [
                _TabChip(
                  label: 'FAQ',
                  selected: _selectedTab == 0,
                  onTap: () => setState(() => _selectedTab = 0),
                ),
                const SizedBox(width: 8),
                _TabChip(
                  label: 'Contact',
                  selected: _selectedTab == 1,
                  onTap: () => setState(() => _selectedTab = 1),
                ),
                const SizedBox(width: 8),
                _TabChip(
                  label: 'Resources',
                  selected: _selectedTab == 2,
                  onTap: () => setState(() => _selectedTab = 2),
                ),
              ],
            ),
          ),
          Expanded(
            child: IndexedStack(
              index: _selectedTab,
              children: [
                // FAQ
                SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: EdgeInsets.fromLTRB(20, 20, 20, bottomPadding + 40),
                  child: Column(
                    children: [
                      // Search
                      _buildEntrance(
                        index: 0,
                        child: TextField(
                          controller: _searchController,
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 14,
                            color: titleColor,
                          ),
                          decoration: InputDecoration(
                            hintText: 'Search FAQ...',
                            hintStyle: GoogleFonts.plusJakartaSans(
                              color: subtitleColor,
                            ),
                            prefixIcon: Icon(
                              Icons.search_rounded,
                              color: subtitleColor,
                            ),
                            filled: true,
                            fillColor: cardColor,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(14),
                              borderSide: BorderSide(color: borderColor),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(14),
                              borderSide: BorderSide(color: borderColor),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(14),
                              borderSide: const BorderSide(
                                color: Color(0xFFE91E8F),
                                width: 2,
                              ),
                            ),
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 14,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      ...List.generate(_faqs.length, (i) {
                        return _buildEntrance(
                          index: i + 1,
                          child: Padding(
                            padding: const EdgeInsets.only(bottom: 10),
                            child: _FaqCard(
                              faq: _faqs[i],
                              isDark: isDark,
                              cardColor: cardColor,
                              borderColor: borderColor,
                              titleColor: titleColor,
                              subtitleColor: subtitleColor,
                            ),
                          ),
                        );
                      }),
                    ],
                  ),
                ),
                // Contact
                SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: EdgeInsets.fromLTRB(20, 20, 20, bottomPadding + 40),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildEntrance(
                        index: 0,
                        child: Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: cardColor,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: borderColor),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withAlpha(isDark ? 20 : 8),
                                blurRadius: 8,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Submit a Support Request',
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w700,
                                  color: titleColor,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                "We'll get back to you within 24 hours.",
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 13,
                                  color: subtitleColor,
                                ),
                              ),
                              const SizedBox(height: 20),
                              TextField(
                                controller: _subjectController,
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 14,
                                  color: titleColor,
                                ),
                                decoration: InputDecoration(
                                  labelText: 'Subject',
                                  labelStyle: GoogleFonts.plusJakartaSans(
                                    color: subtitleColor,
                                  ),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(12),
                                    borderSide: const BorderSide(
                                      color: Color(0xFFE91E8F),
                                      width: 2,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 14),
                              TextField(
                                controller: _messageController,
                                maxLines: 5,
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 14,
                                  color: titleColor,
                                ),
                                decoration: InputDecoration(
                                  labelText: 'Message',
                                  labelStyle: GoogleFonts.plusJakartaSans(
                                    color: subtitleColor,
                                  ),
                                  alignLabelWithHint: true,
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(12),
                                    borderSide: const BorderSide(
                                      color: Color(0xFFE91E8F),
                                      width: 2,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 14),
                              OutlinedButton.icon(
                                onPressed: () {},
                                icon: const Icon(
                                  Icons.attach_file_rounded,
                                  size: 18,
                                  color: Color(0xFF123C33),
                                ),
                                label: Text(
                                  'Attach Screenshot',
                                  style: GoogleFonts.plusJakartaSans(
                                    color: const Color(0xFF123C33),
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                style: OutlinedButton.styleFrom(
                                  side: const BorderSide(
                                    color: Color(0xFF123C33),
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 16,
                                    vertical: 12,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 20),
                              SizedBox(
                                width: double.infinity,
                                child: ElevatedButton(
                                  onPressed: _isSubmitting
                                      ? null
                                      : () async {
                                          setState(() => _isSubmitting = true);
                                          await Future.delayed(
                                            const Duration(milliseconds: 1200),
                                          );
                                          if (mounted) {
                                            setState(
                                              () => _isSubmitting = false,
                                            );
                                            _subjectController.clear();
                                            _messageController.clear();
                                            ScaffoldMessenger.of(
                                              context,
                                            ).showSnackBar(
                                              SnackBar(
                                                content: Text(
                                                  'Support request submitted! We\'ll be in touch soon.',
                                                  style:
                                                      GoogleFonts.plusJakartaSans(),
                                                ),
                                                backgroundColor: const Color(
                                                  0xFF123C33,
                                                ),
                                                behavior:
                                                    SnackBarBehavior.floating,
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(12),
                                                ),
                                              ),
                                            );
                                          }
                                        },
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: const Color(0xFFE91E8F),
                                    foregroundColor: Colors.white,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    padding: const EdgeInsets.symmetric(
                                      vertical: 16,
                                    ),
                                  ),
                                  child: _isSubmitting
                                      ? const SizedBox(
                                          width: 20,
                                          height: 20,
                                          child: CircularProgressIndicator(
                                            strokeWidth: 2,
                                            valueColor:
                                                AlwaysStoppedAnimation<Color>(
                                                  Colors.white,
                                                ),
                                          ),
                                        )
                                      : Text(
                                          'Submit Request',
                                          style: GoogleFonts.plusJakartaSans(
                                            fontWeight: FontWeight.w600,
                                            fontSize: 15,
                                          ),
                                        ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                // Resources
                SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: EdgeInsets.fromLTRB(20, 20, 20, bottomPadding + 40),
                  child: Column(
                    children: List.generate(_resources.length, (i) {
                      final res = _resources[i];
                      return _buildEntrance(
                        index: i,
                        child: Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: GestureDetector(
                            onTap: () {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(
                                    '${res['title']} coming soon!',
                                    style: GoogleFonts.plusJakartaSans(),
                                  ),
                                  backgroundColor: const Color(0xFF123C33),
                                  behavior: SnackBarBehavior.floating,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                ),
                              );
                            },
                            child: Container(
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                color: cardColor,
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(color: borderColor),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withAlpha(
                                      isDark ? 20 : 8,
                                    ),
                                    blurRadius: 8,
                                    offset: const Offset(0, 2),
                                  ),
                                ],
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    width: 48,
                                    height: 48,
                                    decoration: BoxDecoration(
                                      color: res['bg'] as Color,
                                      borderRadius: BorderRadius.circular(14),
                                    ),
                                    child: Icon(
                                      res['icon'] as IconData,
                                      color: res['color'] as Color,
                                      size: 24,
                                    ),
                                  ),
                                  const SizedBox(width: 14),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          res['title'] as String,
                                          style: GoogleFonts.plusJakartaSans(
                                            fontSize: 15,
                                            fontWeight: FontWeight.w600,
                                            color: titleColor,
                                          ),
                                        ),
                                        const SizedBox(height: 2),
                                        Text(
                                          res['desc'] as String,
                                          style: GoogleFonts.plusJakartaSans(
                                            fontSize: 12,
                                            color: subtitleColor,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Icon(
                                    Icons.arrow_forward_ios_rounded,
                                    size: 16,
                                    color: isDark
                                        ? const Color(0xFF666666)
                                        : const Color(0xFFBDBDBD),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    }),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _TabChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _TabChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFE91E8F) : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: selected ? const Color(0xFFE91E8F) : const Color(0xFFE8D5DF),
          ),
        ),
        child: Text(
          label,
          style: GoogleFonts.plusJakartaSans(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: selected ? Colors.white : const Color(0xFF757575),
          ),
        ),
      ),
    );
  }
}

class _FaqCard extends StatefulWidget {
  final Map<String, String> faq;
  final bool isDark;
  final Color cardColor;
  final Color borderColor;
  final Color titleColor;
  final Color subtitleColor;

  const _FaqCard({
    required this.faq,
    required this.isDark,
    required this.cardColor,
    required this.borderColor,
    required this.titleColor,
    required this.subtitleColor,
  });

  @override
  State<_FaqCard> createState() => _FaqCardState();
}

class _FaqCardState extends State<_FaqCard>
    with SingleTickerProviderStateMixin {
  bool _expanded = false;
  late AnimationController _controller;
  late Animation<double> _expandAnim;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 250),
    );
    _expandAnim = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOutCubic,
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        setState(() => _expanded = !_expanded);
        _expanded ? _controller.forward() : _controller.reverse();
      },
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: widget.cardColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: widget.borderColor),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withAlpha(widget.isDark ? 20 : 8),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    widget.faq['q']!,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: widget.titleColor,
                    ),
                  ),
                ),
                AnimatedRotation(
                  turns: _expanded ? 0.5 : 0,
                  duration: const Duration(milliseconds: 250),
                  child: Icon(
                    Icons.keyboard_arrow_down_rounded,
                    color: const Color(0xFFE91E8F),
                    size: 22,
                  ),
                ),
              ],
            ),
            SizeTransition(
              sizeFactor: _expandAnim,
              child: Column(
                children: [
                  const SizedBox(height: 10),
                  Text(
                    widget.faq['a']!,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 13,
                      color: widget.subtitleColor,
                      height: 1.5,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
