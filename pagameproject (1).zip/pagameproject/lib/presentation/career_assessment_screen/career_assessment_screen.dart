import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';

import '../../core/app_state.dart';

class AssessmentQuestion {
  final String topic;
  final String question;
  final List<String> options;

  const AssessmentQuestion({
    required this.topic,
    required this.question,
    required this.options,
  });
}

const List<AssessmentQuestion> kAssessmentQuestions = [
  AssessmentQuestion(
    topic: 'Career Stage',
    question: 'Which best describes your current career stage?',
    options: [
      'Early career (0–3 years)',
      'Mid-level professional (4–8 years)',
      'Senior professional (9–15 years)',
      'Executive / Leadership (15+ years)',
    ],
  ),
  AssessmentQuestion(
    topic: 'Long-Term Goals',
    question: 'What is your primary long-term career goal?',
    options: [
      'Reach a C-suite or VP-level role',
      'Transition into a new industry or field',
      'Build and lead my own team',
      'Start my own business or consultancy',
    ],
  ),
  AssessmentQuestion(
    topic: 'Biggest Challenge',
    question: 'What is your biggest career challenge right now?',
    options: [
      'Getting promoted or recognized',
      'Negotiating a higher salary',
      'Building confidence in the workplace',
      'Finding the right opportunities',
    ],
  ),
  AssessmentQuestion(
    topic: 'Salary Growth',
    question: 'What is your salary growth goal in the next 12 months?',
    options: [
      'Increase by 10–15%',
      'Increase by 20–30%',
      'Double my current income',
      'Secure equity or performance bonuses',
    ],
  ),
  AssessmentQuestion(
    topic: 'Leadership Aspirations',
    question: 'How would you describe your leadership aspirations?',
    options: [
      'I want to lead a small team soon',
      'I aim to manage a department or division',
      'I want to become a thought leader in my field',
      'Leadership is not my primary focus right now',
    ],
  ),
  AssessmentQuestion(
    topic: 'Interview Confidence',
    question: 'How confident do you feel in job interviews?',
    options: [
      'Very confident — I perform well under pressure',
      'Somewhat confident — I could use some polish',
      'Nervous — I struggle to articulate my value',
      'I haven\'t interviewed in a long time',
    ],
  ),
  AssessmentQuestion(
    topic: 'Resume Quality',
    question: 'How would you rate your current resume?',
    options: [
      'Strong — it clearly showcases my achievements',
      'Decent — but it needs updating',
      'Weak — I\'m not sure how to highlight my skills',
      'I don\'t have an updated resume',
    ],
  ),
  AssessmentQuestion(
    topic: 'Networking Skills',
    question: 'How active are you in professional networking?',
    options: [
      'Very active — I regularly attend events and connect online',
      'Somewhat active — I network occasionally',
      'Rarely — I find networking uncomfortable',
      'I\'m just starting to build my network',
    ],
  ),
  AssessmentQuestion(
    topic: 'Personal Branding',
    question: 'How strong is your personal brand online?',
    options: [
      'Strong — I have an active LinkedIn and online presence',
      'Moderate — I have profiles but rarely post',
      'Minimal — I\'m not sure what my brand is',
      'I haven\'t thought about personal branding yet',
    ],
  ),
  AssessmentQuestion(
    topic: 'Career Transition',
    question: 'Are you considering a career transition?',
    options: [
      'Yes — I want to switch industries entirely',
      'Yes — I want to move into a different role or function',
      'Maybe — I\'m exploring my options',
      'No — I\'m focused on growing in my current path',
    ],
  ),
  AssessmentQuestion(
    topic: 'Promotion Goals',
    question: 'When do you hope to receive your next promotion?',
    options: [
      'Within the next 6 months',
      'Within the next year',
      'In 1–2 years',
      'I\'m not currently focused on promotion',
    ],
  ),
  AssessmentQuestion(
    topic: 'Workplace Confidence',
    question: 'How confident are you advocating for yourself at work?',
    options: [
      'Very confident — I speak up and set boundaries',
      'Somewhat confident — I\'m working on it',
      'Not confident — I often hold back',
      'I struggle with imposter syndrome',
    ],
  ),
  AssessmentQuestion(
    topic: 'Entrepreneurship',
    question: 'How interested are you in entrepreneurship?',
    options: [
      'Very interested — I have a business idea I\'m developing',
      'Somewhat interested — I\'d like to explore it',
      'Curious but unsure where to start',
      'Not interested — I prefer corporate career growth',
    ],
  ),
  AssessmentQuestion(
    topic: 'Skill Development',
    question: 'Which professional skill area do you most want to develop?',
    options: [
      'Technical or industry-specific skills',
      'Leadership and management skills',
      'Communication and executive presence',
      'Strategic thinking and business acumen',
    ],
  ),
  AssessmentQuestion(
    topic: 'Coaching Style',
    question: 'What coaching style works best for you?',
    options: [
      'Direct and action-oriented — give me a clear plan',
      'Collaborative — let\'s explore together',
      'Supportive and empathetic — I need encouragement',
      'Data-driven — show me the numbers and strategy',
    ],
  ),
];

class CareerAssessmentScreen extends StatefulWidget {
  const CareerAssessmentScreen({super.key});

  @override
  State<CareerAssessmentScreen> createState() => _CareerAssessmentScreenState();
}

class _CareerAssessmentScreenState extends State<CareerAssessmentScreen>
    with SingleTickerProviderStateMixin {
  int _currentIndex = 0;
  final List<int?> _answers = List.filled(kAssessmentQuestions.length, null);
  late AnimationController _animController;
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;
  bool _isForward = true;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 320),
    );
    _buildAnimations();
    _animController.forward();
  }

  void _buildAnimations() {
    _fadeAnim = Tween<double>(
      begin: 0,
      end: 1,
    ).animate(CurvedAnimation(parent: _animController, curve: Curves.easeOut));
    _slideAnim =
        Tween<Offset>(
          begin: Offset(_isForward ? 0.06 : -0.06, 0),
          end: Offset.zero,
        ).animate(
          CurvedAnimation(parent: _animController, curve: Curves.easeOutCubic),
        );
  }

  Future<void> _navigateTo(int index, bool forward) async {
    _isForward = forward;
    await _animController.reverse();
    setState(() => _currentIndex = index);
    _buildAnimations();
    _animController.forward();
  }

  void _onNext() {
    if (_answers[_currentIndex] == null) return;
    if (_currentIndex < kAssessmentQuestions.length - 1) {
      _navigateTo(_currentIndex + 1, true);
    } else {
      _finishAssessment();
    }
  }

  void _onBack() {
    if (_currentIndex > 0) {
      _navigateTo(_currentIndex - 1, false);
    } else {
      Navigator.of(context).pop();
    }
  }

  void _finishAssessment() {
    // Build assessment result from answers
    final result = AssessmentResult.fromAnswers(_answers);
    AppState().setAssessmentResult(result);
    context.push('/career-coach-matching', extra: result);
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF1A1A1A) : const Color(0xFFFAFAFA);
    final cardColor = isDark ? const Color(0xFF2D2D2D) : Colors.white;
    final titleColor = isDark
        ? const Color(0xFFE6E6E6)
        : const Color(0xFF123C33);
    final subtitleColor = isDark
        ? const Color(0xFFAAAAAA)
        : const Color(0xFF757575);
    final borderColor = isDark
        ? const Color(0xFF4A4A4A)
        : const Color(0xFFE8D5DF);

    final question = kAssessmentQuestions[_currentIndex];
    final total = kAssessmentQuestions.length;
    final progress = (_currentIndex + 1) / total;
    final isLast = _currentIndex == total - 1;
    final hasAnswer = _answers[_currentIndex] != null;

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        backgroundColor: const Color(0xFF123C33),
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text(
          'Career Assessment',
          style: GoogleFonts.plusJakartaSans(
            fontSize: 17,
            fontWeight: FontWeight.w700,
            color: Colors.white,
          ),
        ),
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_rounded,
            color: Colors.white,
            size: 20,
          ),
          onPressed: _onBack,
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Progress bar
            Container(
              color: const Color(0xFF123C33),
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Question ${_currentIndex + 1} of $total',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: Colors.white.withAlpha(204),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE91E8F).withAlpha(51),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          question.topic,
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            color: const Color(0xFFFF85C8),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: progress,
                      backgroundColor: Colors.white.withAlpha(40),
                      valueColor: const AlwaysStoppedAnimation<Color>(
                        Color(0xFFE91E8F),
                      ),
                      minHeight: 6,
                    ),
                  ),
                ],
              ),
            ),
            // Question + options
            Expanded(
              child: FadeTransition(
                opacity: _fadeAnim,
                child: SlideTransition(
                  position: _slideAnim,
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(20, 24, 20, 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          question.question,
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            color: titleColor,
                            height: 1.35,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Select the option that best describes you',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 13,
                            color: subtitleColor,
                          ),
                        ),
                        const SizedBox(height: 24),
                        ...question.options.asMap().entries.map((entry) {
                          final idx = entry.key;
                          final option = entry.value;
                          final isSelected = _answers[_currentIndex] == idx;
                          return Padding(
                            padding: const EdgeInsets.only(bottom: 12),
                            child: _OptionCard(
                              label: option,
                              isSelected: isSelected,
                              isDark: isDark,
                              cardColor: cardColor,
                              borderColor: borderColor,
                              onTap: () {
                                setState(() => _answers[_currentIndex] = idx);
                              },
                            ),
                          );
                        }),
                        const SizedBox(height: 8),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            // Navigation buttons
            Container(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
              decoration: BoxDecoration(
                color: cardColor,
                border: Border(top: BorderSide(color: borderColor, width: 1)),
              ),
              child: Row(
                children: [
                  if (_currentIndex > 0)
                    Expanded(
                      child: _NavButton(
                        label: 'Back',
                        isPrimary: false,
                        isDark: isDark,
                        onTap: _onBack,
                      ),
                    ),
                  if (_currentIndex > 0) const SizedBox(width: 12),
                  Expanded(
                    flex: 2,
                    child: _NavButton(
                      label: isLast ? 'Find My Coach →' : 'Next →',
                      isPrimary: true,
                      isDark: isDark,
                      enabled: hasAnswer,
                      onTap: hasAnswer ? _onNext : null,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _OptionCard extends StatefulWidget {
  final String label;
  final bool isSelected;
  final bool isDark;
  final Color cardColor;
  final Color borderColor;
  final VoidCallback onTap;

  const _OptionCard({
    required this.label,
    required this.isSelected,
    required this.isDark,
    required this.cardColor,
    required this.borderColor,
    required this.onTap,
  });

  @override
  State<_OptionCard> createState() => _OptionCardState();
}

class _OptionCardState extends State<_OptionCard> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.98 : 1.0,
        duration: const Duration(milliseconds: 100),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: widget.isSelected
                ? const Color(0xFFE91E8F).withAlpha(15)
                : widget.cardColor,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: widget.isSelected
                  ? const Color(0xFFE91E8F)
                  : widget.borderColor,
              width: widget.isSelected ? 2 : 1,
            ),
            boxShadow: widget.isSelected
                ? [
                    BoxShadow(
                      color: const Color(0xFFE91E8F).withAlpha(30),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                  ]
                : [
                    BoxShadow(
                      color: Colors.black.withAlpha(widget.isDark ? 15 : 6),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
          ),
          child: Row(
            children: [
              AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                width: 22,
                height: 22,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: widget.isSelected
                      ? const Color(0xFFE91E8F)
                      : Colors.transparent,
                  border: Border.all(
                    color: widget.isSelected
                        ? const Color(0xFFE91E8F)
                        : (widget.isDark
                              ? const Color(0xFF666666)
                              : const Color(0xFFCCCCCC)),
                    width: 2,
                  ),
                ),
                child: widget.isSelected
                    ? const Icon(
                        Icons.check_rounded,
                        size: 14,
                        color: Colors.white,
                      )
                    : null,
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Text(
                  widget.label,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 14,
                    fontWeight: widget.isSelected
                        ? FontWeight.w600
                        : FontWeight.w400,
                    color: widget.isSelected
                        ? const Color(0xFFE91E8F)
                        : (widget.isDark
                              ? const Color(0xFFE6E6E6)
                              : const Color(0xFF1A1A1A)),
                    height: 1.4,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NavButton extends StatefulWidget {
  final String label;
  final bool isPrimary;
  final bool isDark;
  final bool enabled;
  final VoidCallback? onTap;

  const _NavButton({
    required this.label,
    required this.isPrimary,
    required this.isDark,
    this.enabled = true,
    this.onTap,
  });

  @override
  State<_NavButton> createState() => _NavButtonState();
}

class _NavButtonState extends State<_NavButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final isActive = widget.enabled && widget.onTap != null;
    return GestureDetector(
      onTapDown: isActive ? (_) => setState(() => _pressed = true) : null,
      onTapUp: isActive
          ? (_) {
              setState(() => _pressed = false);
              widget.onTap!();
            }
          : null,
      onTapCancel: isActive ? () => setState(() => _pressed = false) : null,
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 100),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          height: 52,
          decoration: BoxDecoration(
            color: widget.isPrimary
                ? (isActive
                      ? const Color(0xFFE91E8F)
                      : const Color(0xFFE91E8F).withAlpha(80))
                : (widget.isDark
                      ? const Color(0xFF3A3A3A)
                      : const Color(0xFFF5F5F5)),
            borderRadius: BorderRadius.circular(14),
            boxShadow: widget.isPrimary && isActive
                ? [
                    BoxShadow(
                      color: const Color(0xFFE91E8F).withAlpha(60),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                  ]
                : null,
          ),
          child: Center(
            child: Text(
              widget.label,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 15,
                fontWeight: FontWeight.w700,
                color: widget.isPrimary
                    ? Colors.white
                    : (widget.isDark
                          ? const Color(0xFFCCCCCC)
                          : const Color(0xFF424242)),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ── Assessment Result Model ──────────────────────────────────────────────────

class AssessmentResult {
  final List<int?> answers;
  final String recommendedCoach;
  final int matchPercentage;
  final List<String> topFocusAreas;
  final String matchReason;

  const AssessmentResult({
    required this.answers,
    required this.recommendedCoach,
    required this.matchPercentage,
    required this.topFocusAreas,
    required this.matchReason,
  });

  factory AssessmentResult.fromAnswers(List<int?> answers) {
    // Scoring logic: tally coach affinity scores
    // Coach 0 = Dr. Maria Santos (Executive Leadership, Salary Negotiation)
    // Coach 1 = Priya Nair (Career Transitions, Tech Industry)
    // Coach 2 = Tamara Williams (Pay Equity, Workplace Advocacy)

    final scores = [0, 0, 0];
    final focusAreas = <String>[];

    // Q0: Career Stage
    final q0 = answers[0];
    if (q0 == 2 || q0 == 3) {
      scores[0] += 3; // Senior/Executive → Maria
      focusAreas.add('Executive Leadership');
    } else if (q0 == 1) {
      scores[1] += 2;
    }

    // Q1: Long-term goals
    final q1 = answers[1];
    if (q1 == 0) {
      scores[0] += 3;
      focusAreas.add('C-Suite Advancement');
    } else if (q1 == 1) {
      scores[1] += 3;
      focusAreas.add('Career Transition');
    } else if (q1 == 3) {
      scores[1] += 2;
      focusAreas.add('Entrepreneurship');
    }

    // Q2: Biggest challenge
    final q2 = answers[2];
    if (q2 == 0) {
      scores[0] += 2;
      focusAreas.add('Promotion Strategy');
    } else if (q2 == 1) {
      scores[2] += 3;
      focusAreas.add('Salary Negotiation');
    } else if (q2 == 2) {
      scores[2] += 2;
      focusAreas.add('Workplace Confidence');
    }

    // Q3: Salary growth
    final q3 = answers[3];
    if (q3 == 1 || q3 == 2) {
      scores[2] += 2;
      if (!focusAreas.contains('Salary Negotiation')) {
        focusAreas.add('Salary Negotiation');
      }
    } else if (q3 == 3) {
      scores[0] += 2;
    }

    // Q4: Leadership
    final q4 = answers[4];
    if (q4 == 0 || q4 == 1) {
      scores[0] += 2;
      if (!focusAreas.contains('Executive Leadership')) {
        focusAreas.add('Leadership Development');
      }
    } else if (q4 == 2) {
      scores[1] += 1;
    }

    // Q5: Interview confidence
    final q5 = answers[5];
    if (q5 == 2 || q5 == 3) {
      scores[1] += 2;
      focusAreas.add('Interview Preparation');
    }

    // Q6: Resume quality
    final q6 = answers[6];
    if (q6 == 2 || q6 == 3) {
      scores[1] += 2;
      focusAreas.add('Resume Building');
    }

    // Q7: Networking
    final q7 = answers[7];
    if (q7 == 2 || q7 == 3) {
      scores[2] += 1;
      focusAreas.add('Networking Skills');
    }

    // Q8: Personal branding
    final q8 = answers[8];
    if (q8 == 2 || q8 == 3) {
      scores[1] += 1;
      focusAreas.add('Personal Branding');
    }

    // Q9: Career transition
    final q9 = answers[9];
    if (q9 == 0 || q9 == 1) {
      scores[1] += 3;
      if (!focusAreas.contains('Career Transition')) {
        focusAreas.add('Career Transition');
      }
    }

    // Q10: Promotion goals
    final q10 = answers[10];
    if (q10 == 0 || q10 == 1) {
      scores[0] += 2;
      if (!focusAreas.contains('Promotion Strategy')) {
        focusAreas.add('Promotion Strategy');
      }
    }

    // Q11: Workplace confidence
    final q11 = answers[11];
    if (q11 == 2 || q11 == 3) {
      scores[2] += 3;
      if (!focusAreas.contains('Workplace Confidence')) {
        focusAreas.add('Workplace Confidence');
      }
    }

    // Q12: Entrepreneurship
    final q12 = answers[12];
    if (q12 == 0 || q12 == 1) {
      scores[1] += 2;
      if (!focusAreas.contains('Entrepreneurship')) {
        focusAreas.add('Entrepreneurship');
      }
    }

    // Q13: Skill development
    final q13 = answers[13];
    if (q13 == 1) {
      scores[0] += 2;
    } else if (q13 == 0) {
      scores[1] += 1;
    } else if (q13 == 2) {
      scores[2] += 1;
      focusAreas.add('Executive Presence');
    }

    // Q14: Coaching style
    final q14 = answers[14];
    if (q14 == 0) {
      scores[0] += 1;
    } else if (q14 == 1) {
      scores[1] += 1;
    } else if (q14 == 2) {
      scores[2] += 1;
    } else if (q14 == 3) {
      scores[2] += 1;
    }

    // Determine best coach
    int bestIdx = 0;
    for (int i = 1; i < scores.length; i++) {
      if (scores[i] > scores[bestIdx]) bestIdx = i;
    }

    final coachNames = [
      'Dr. Maria Santos',
      'Priya Nair, MBA',
      'Tamara Williams',
    ];

    final matchReasons = [
      'Based on your assessment, you\'re focused on executive advancement and salary growth. Dr. Maria Santos specializes in helping senior professionals break through glass ceilings and negotiate high-value compensation packages.',
      'Your responses indicate you\'re navigating a career transition and building new skills. Priya Nair\'s background in tech and career pivots makes her the ideal guide for your next chapter.',
      'Your assessment highlights pay equity and workplace confidence as key priorities. Tamara Williams is a certified DEI strategist who empowers women to advocate for fair pay and equal opportunities.',
    ];

    // Calculate match percentage (60–98 range based on score dominance)
    final totalScore = scores.reduce((a, b) => a + b);
    final bestScore = scores[bestIdx];
    final rawPct = totalScore > 0 ? (bestScore / totalScore) : 0.5;
    final matchPct = (60 + (rawPct * 38)).round().clamp(62, 98);

    // Top 3 focus areas
    final topAreas = focusAreas.take(4).toList();
    if (topAreas.isEmpty) topAreas.add('Career Growth');

    return AssessmentResult(
      answers: answers,
      recommendedCoach: coachNames[bestIdx],
      matchPercentage: matchPct,
      topFocusAreas: topAreas,
      matchReason: matchReasons[bestIdx],
    );
  }
}
