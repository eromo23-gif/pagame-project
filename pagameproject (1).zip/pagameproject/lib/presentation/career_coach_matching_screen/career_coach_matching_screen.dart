import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';

import '../../core/app_state.dart';
import '../career_assessment_screen/career_assessment_screen.dart';

class _Coach {
  final String name;
  final String specialty;
  final String bio;
  final String rating;
  final String sessions;
  final String imageInitial;
  final Color color;
  final List<String> tags;

  const _Coach({
    required this.name,
    required this.specialty,
    required this.bio,
    required this.rating,
    required this.sessions,
    required this.imageInitial,
    required this.color,
    required this.tags,
  });
}

class CareerCoachMatchingScreen extends StatefulWidget {
  final AssessmentResult? assessmentResult;

  const CareerCoachMatchingScreen({super.key, this.assessmentResult});

  @override
  State<CareerCoachMatchingScreen> createState() =>
      _CareerCoachMatchingScreenState();
}

class _CareerCoachMatchingScreenState extends State<CareerCoachMatchingScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _entranceController;
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  String? _selectedFilter;
  bool _showMatchBanner = false;

  static const List<_Coach> _allCoaches = [
    _Coach(
      name: 'Dr. Maria Santos',
      specialty: 'Executive Leadership & Salary Negotiation',
      bio:
          'With 15+ years in HR and executive coaching, Maria helps women break through glass ceilings and negotiate compensation packages with confidence.',
      rating: '4.9',
      sessions: '200+',
      imageInitial: 'M',
      color: Color(0xFFE91E8F),
      tags: ['Executive Leadership'],
    ),
    _Coach(
      name: 'Priya Nair, MBA',
      specialty: 'Career Transitions & Tech Industry',
      bio:
          'Former tech recruiter turned career coach. Priya specializes in helping women pivot into high-growth tech roles and navigate workplace dynamics.',
      rating: '4.8',
      sessions: '150+',
      imageInitial: 'P',
      color: Color(0xFF123C33),
      tags: ['Tech Industry', 'Career Transitions'],
    ),
    _Coach(
      name: 'Tamara Williams',
      specialty: 'Pay Equity & Workplace Advocacy',
      bio:
          'Tamara is a certified DEI consultant and career strategist who empowers women to advocate for fair pay and equitable opportunities.',
      rating: '5.0',
      sessions: '300+',
      imageInitial: 'T',
      color: Color(0xFF7B2D8B),
      tags: ['Pay Equity', 'Workplace Advocacy'],
    ),
  ];

  static const List<String> _filterChips = [
    'Executive Leadership',
    'Tech Industry',
    'Pay Equity',
    'Career Transitions',
    'Workplace Advocacy',
  ];

  AssessmentResult? get _result =>
      widget.assessmentResult ?? AppState().assessmentResult;

  @override
  void initState() {
    super.initState();
    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _entranceController.forward();
      if (_result != null) {
        setState(() => _showMatchBanner = true);
      }
    });
    _searchController.addListener(() {
      setState(() => _searchQuery = _searchController.text.toLowerCase());
    });
  }

  @override
  void dispose() {
    _entranceController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  List<_Coach> get _filteredCoaches {
    List<_Coach> coaches = _allCoaches;

    if (_selectedFilter != null) {
      coaches = coaches.where((c) => c.tags.contains(_selectedFilter)).toList();
    }

    if (_searchQuery.isNotEmpty) {
      coaches = coaches
          .where(
            (c) =>
                c.name.toLowerCase().contains(_searchQuery) ||
                c.specialty.toLowerCase().contains(_searchQuery) ||
                c.tags.any((t) => t.toLowerCase().contains(_searchQuery)),
          )
          .toList();
    }

    return coaches;
  }

  Widget _buildEntranceWidget({required int index, required Widget child}) {
    final delay = (index * 0.1).clamp(0.0, 0.7);
    final end = (delay + 0.4).clamp(0.0, 1.0);
    final fade = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _entranceController,
        curve: Interval(delay, end, curve: Curves.easeOut),
      ),
    );
    final slide = Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero)
        .animate(
          CurvedAnimation(
            parent: _entranceController,
            curve: Interval(delay, end, curve: Curves.easeOutCubic),
          ),
        );
    return FadeTransition(
      opacity: fade,
      child: SlideTransition(position: slide, child: child),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bottomPadding = MediaQuery.of(context).padding.bottom;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF1A1A1A) : const Color(0xFFFAFAFA);
    final cardColor = isDark ? const Color(0xFF2D2D2D) : Colors.white;
    final titleColor = isDark
        ? const Color(0xFFE6E6E6)
        : const Color(0xFF123C33);
    final subtitleColor = isDark
        ? const Color(0xFFAAAAAA)
        : const Color(0xFF9E9E9E);
    final borderColor = isDark
        ? const Color(0xFF4A4A4A)
        : const Color(0xFFE8D5DF);

    final filtered = _filteredCoaches;
    final result = _result;

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        backgroundColor: const Color(0xFF123C33),
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text(
          'Career Coach Matching',
          style: GoogleFonts.plusJakartaSans(
            fontSize: 17,
            fontWeight: FontWeight.w700,
            color: Colors.white,
          ),
        ),
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_rounded,
            color: Colors.white,
            size: 20,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.fromLTRB(20, 20, 20, bottomPadding + 40),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            _buildEntranceWidget(
              index: 0,
              child: Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: const Color(0xFF123C33),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: const Color(0xFFE91E8F).withAlpha(51),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Icon(
                            Icons.people_alt_rounded,
                            color: Color(0xFFE91E8F),
                            size: 22,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            'Find Your Perfect Coach',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Our AI-powered matching connects you with highly qualified human career coaches for tailored 1:1 coaching sessions.',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 13,
                        color: Colors.white.withAlpha(204),
                        height: 1.5,
                      ),
                    ),
                    if (result == null) ...[
                      const SizedBox(height: 14),
                      _StartAssessmentButton(
                        onTap: () => context.push('/career-assessment'),
                      ),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // ── Assessment Match Banner ──────────────────────────────────────
            if (result != null && _showMatchBanner) ...[
              _buildEntranceWidget(
                index: 1,
                child: _MatchResultBanner(
                  result: result,
                  isDark: isDark,
                  cardColor: cardColor,
                  borderColor: borderColor,
                ),
              ),
              const SizedBox(height: 20),
            ],

            // Featured Coaches header
            _buildEntranceWidget(
              index: result != null ? 2 : 1,
              child: Text(
                result != null
                    ? 'Your Recommended Coaches'
                    : 'Featured Coaches',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: titleColor,
                ),
              ),
            ),
            const SizedBox(height: 4),
            _buildEntranceWidget(
              index: result != null ? 2 : 1,
              child: Text(
                result != null
                    ? 'Ranked by compatibility with your assessment'
                    : 'Experienced coaches ready to support your journey',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 13,
                  color: subtitleColor,
                ),
              ),
            ),
            const SizedBox(height: 16),
            // Search bar
            _buildEntranceWidget(
              index: result != null ? 3 : 2,
              child: Container(
                decoration: BoxDecoration(
                  color: cardColor,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: borderColor),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withAlpha(isDark ? 20 : 8),
                      blurRadius: 10,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: TextField(
                  controller: _searchController,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 14,
                    color: isDark
                        ? const Color(0xFFE6E6E6)
                        : const Color(0xFF1A1A1A),
                  ),
                  decoration: InputDecoration(
                    hintText: 'Search by specialty...',
                    hintStyle: GoogleFonts.plusJakartaSans(
                      fontSize: 14,
                      color: isDark
                          ? const Color(0xFF888888)
                          : const Color(0xFFBDBDBD),
                    ),
                    prefixIcon: Icon(
                      Icons.search_rounded,
                      color: isDark
                          ? const Color(0xFF888888)
                          : const Color(0xFF9E9E9E),
                      size: 20,
                    ),
                    suffixIcon: _searchQuery.isNotEmpty
                        ? IconButton(
                            icon: Icon(
                              Icons.clear_rounded,
                              size: 18,
                              color: isDark
                                  ? const Color(0xFF888888)
                                  : const Color(0xFF9E9E9E),
                            ),
                            onPressed: () {
                              _searchController.clear();
                              setState(() => _searchQuery = '');
                            },
                          )
                        : null,
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 14,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),
            // Filter chips
            _buildEntranceWidget(
              index: result != null ? 4 : 3,
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                child: Row(
                  children: _filterChips.map((chip) {
                    final isSelected = _selectedFilter == chip;
                    return Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: GestureDetector(
                        onTap: () => setState(() {
                          _selectedFilter = isSelected ? null : chip;
                        }),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 8,
                          ),
                          decoration: BoxDecoration(
                            color: isSelected
                                ? const Color(0xFFE91E8F)
                                : (isDark
                                      ? const Color(0xFF2D2D2D)
                                      : Colors.white),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: isSelected
                                  ? const Color(0xFFE91E8F)
                                  : borderColor,
                              width: 1.5,
                            ),
                            boxShadow: isSelected
                                ? [
                                    BoxShadow(
                                      color: const Color(
                                        0xFFE91E8F,
                                      ).withAlpha(60),
                                      blurRadius: 8,
                                      offset: const Offset(0, 3),
                                    ),
                                  ]
                                : null,
                          ),
                          child: Text(
                            chip,
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 12,
                              fontWeight: isSelected
                                  ? FontWeight.w600
                                  : FontWeight.w500,
                              color: isSelected
                                  ? Colors.white
                                  : (isDark
                                        ? const Color(0xFFCCCCCC)
                                        : const Color(0xFF757575)),
                            ),
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
            ),
            const SizedBox(height: 20),
            // Coach list
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              child: filtered.isEmpty
                  ? _buildEmptyState(isDark, cardColor, borderColor)
                  : Column(
                      key: ValueKey('$_selectedFilter-$_searchQuery'),
                      children: filtered.map((coach) {
                        final isRecommended =
                            result?.recommendedCoach == coach.name;
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 14),
                          child: _CoachCard(
                            coach: coach,
                            isDark: isDark,
                            cardColor: cardColor,
                            borderColor: borderColor,
                            isRecommended: isRecommended,
                            matchPercentage: isRecommended
                                ? result?.matchPercentage
                                : null,
                          ),
                        );
                      }).toList(),
                    ),
            ),
            const SizedBox(height: 8),
            // Take assessment CTA (if no result yet)
            if (result == null)
              _buildEntranceWidget(
                index: 7,
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: isDark
                        ? const Color(0xFF3A2030)
                        : const Color(0xFFFFF0F7),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: const Color(0xFFE91E8F).withAlpha(51),
                    ),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(
                        Icons.auto_awesome_rounded,
                        color: Color(0xFFE91E8F),
                        size: 18,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Get a Personalized Match',
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 13,
                                fontWeight: FontWeight.w700,
                                color: const Color(0xFFB5157A),
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Take our 15-question Career Assessment to get a coach recommendation tailored to your goals, challenges, and career stage.',
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 12,
                                color: const Color(0xFFB5157A),
                                height: 1.4,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState(bool isDark, Color cardColor, Color borderColor) {
    return Container(
      key: const ValueKey('empty'),
      padding: const EdgeInsets.all(32),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: borderColor),
      ),
      child: Column(
        children: [
          Icon(
            Icons.search_off_rounded,
            size: 48,
            color: isDark ? const Color(0xFF555555) : const Color(0xFFE0E0E0),
          ),
          const SizedBox(height: 16),
          Text(
            'No coaches found yet',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: isDark ? const Color(0xFFCCCCCC) : const Color(0xFF757575),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Try a different filter or search term.\nMore coaches are being added soon!',
            textAlign: TextAlign.center,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 13,
              color: isDark ? const Color(0xFF888888) : const Color(0xFFBDBDBD),
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }
}

// ── Match Result Banner ──────────────────────────────────────────────────────

class _MatchResultBanner extends StatelessWidget {
  final AssessmentResult result;
  final bool isDark;
  final Color cardColor;
  final Color borderColor;

  const _MatchResultBanner({
    required this.result,
    required this.isDark,
    required this.cardColor,
    required this.borderColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFE91E8F), Color(0xFFB5157A)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFE91E8F).withAlpha(60),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.white.withAlpha(40),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.verified_rounded,
                  color: Colors.white,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Your Best Match',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Colors.white.withAlpha(204),
                      ),
                    ),
                    Text(
                      result.recommendedCoach,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
              // Match percentage circle
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  color: Colors.white.withAlpha(30),
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Colors.white.withAlpha(80),
                    width: 2,
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      '${result.matchPercentage}%',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      'match',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 9,
                        fontWeight: FontWeight.w500,
                        color: Colors.white.withAlpha(204),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Text(
            result.matchReason,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 13,
              color: Colors.white.withAlpha(230),
              height: 1.5,
            ),
          ),
          const SizedBox(height: 14),
          // Top focus areas header row with Book button
          Row(
            children: [
              Text(
                'Your Top Focus Areas',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: Colors.white.withAlpha(204),
                ),
              ),
              const Spacer(),
              _BannerActionButton(
                label: 'Book',
                icon: Icons.calendar_today_rounded,
                onTap: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        'Booking session with ${result.recommendedCoach}…',
                        style: GoogleFonts.plusJakartaSans(fontSize: 13),
                      ),
                      backgroundColor: const Color(0xFF123C33),
                      behavior: SnackBarBehavior.floating,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      duration: const Duration(seconds: 2),
                    ),
                  );
                },
              ),
            ],
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: result.topFocusAreas.map((area) {
              return Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 5,
                ),
                decoration: BoxDecoration(
                  color: Colors.white.withAlpha(30),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white.withAlpha(60)),
                ),
                child: Text(
                  area,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 16),
          // Save button
          _SaveAssessmentButton(result: result),
        ],
      ),
    );
  }
}

// ── Banner Action Button (Book) ──────────────────────────────────────────────

class _BannerActionButton extends StatefulWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;

  const _BannerActionButton({
    required this.label,
    required this.icon,
    required this.onTap,
  });

  @override
  State<_BannerActionButton> createState() => _BannerActionButtonState();
}

class _BannerActionButtonState extends State<_BannerActionButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.95 : 1.0,
        duration: const Duration(milliseconds: 100),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: Colors.white.withAlpha(30),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white.withAlpha(80)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(widget.icon, size: 12, color: Colors.white),
              const SizedBox(width: 5),
              Text(
                widget.label,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ── Save Assessment Button ───────────────────────────────────────────────────

class _SaveAssessmentButton extends StatefulWidget {
  final AssessmentResult result;

  const _SaveAssessmentButton({required this.result});

  @override
  State<_SaveAssessmentButton> createState() => _SaveAssessmentButtonState();
}

class _SaveAssessmentButtonState extends State<_SaveAssessmentButton> {
  bool _pressed = false;
  bool _saved = false;
  bool _saving = false;

  Future<void> _handleSave() async {
    if (_saved || _saving) return;
    setState(() => _saving = true);
    await Future.delayed(const Duration(milliseconds: 900));
    if (mounted) {
      setState(() {
        _saving = false;
        _saved = true;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              const Icon(
                Icons.check_circle_rounded,
                color: Colors.white,
                size: 16,
              ),
              const SizedBox(width: 8),
              Text(
                'Assessment saved successfully!',
                style: GoogleFonts.plusJakartaSans(fontSize: 13),
              ),
            ],
          ),
          backgroundColor: const Color(0xFF123C33),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        _handleSave();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 100),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: _saved ? Colors.white.withAlpha(40) : Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.white.withAlpha(_saved ? 80 : 0)),
          ),
          child: _saving
              ? const Center(
                  child: SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: Color(0xFFE91E8F),
                    ),
                  ),
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      _saved
                          ? Icons.bookmark_rounded
                          : Icons.bookmark_border_rounded,
                      size: 16,
                      color: _saved ? Colors.white : const Color(0xFFE91E8F),
                    ),
                    const SizedBox(width: 7),
                    Text(
                      _saved ? 'Assessment Saved' : 'Save Assessment',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: _saved ? Colors.white : const Color(0xFFE91E8F),
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}

// ── Start Assessment Button ──────────────────────────────────────────────────

class _StartAssessmentButton extends StatefulWidget {
  final VoidCallback onTap;
  const _StartAssessmentButton({required this.onTap});

  @override
  State<_StartAssessmentButton> createState() => _StartAssessmentButtonState();
}

class _StartAssessmentButtonState extends State<_StartAssessmentButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 100),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: const Color(0xFFE91E8F),
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFE91E8F).withAlpha(80),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.quiz_rounded, color: Colors.white, size: 16),
              const SizedBox(width: 8),
              Text(
                'Take Career Assessment →',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ── Coach Card ───────────────────────────────────────────────────────────────

class _CoachCard extends StatefulWidget {
  final _Coach coach;
  final bool isDark;
  final Color cardColor;
  final Color borderColor;
  final bool isRecommended;
  final int? matchPercentage;

  const _CoachCard({
    required this.coach,
    required this.isDark,
    required this.cardColor,
    required this.borderColor,
    this.isRecommended = false,
    this.matchPercentage,
  });

  @override
  State<_CoachCard> createState() => _CoachCardState();
}

class _CoachCardState extends State<_CoachCard> {
  bool _pressed = false;
  bool _connecting = false;

  @override
  Widget build(BuildContext context) {
    final titleColor = widget.isDark
        ? const Color(0xFFE6E6E6)
        : const Color(0xFF1A1A1A);
    final subtitleColor = widget.isDark
        ? const Color(0xFFAAAAAA)
        : const Color(0xFF757575);
    final descColor = widget.isDark
        ? const Color(0xFFCCCCCC)
        : const Color(0xFF424242);

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.98 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: widget.cardColor,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: widget.isRecommended
                  ? const Color(0xFFE91E8F).withAlpha(120)
                  : widget.borderColor,
              width: widget.isRecommended ? 2 : 1,
            ),
            boxShadow: [
              BoxShadow(
                color: widget.isRecommended
                    ? const Color(0xFFE91E8F).withAlpha(20)
                    : Colors.black.withAlpha(widget.isDark ? 20 : 10),
                blurRadius: 14,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (widget.isRecommended) ...[
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: const Color(0xFFE91E8F).withAlpha(20),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: const Color(0xFFE91E8F).withAlpha(60),
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.verified_rounded,
                        size: 12,
                        color: Color(0xFFE91E8F),
                      ),
                      const SizedBox(width: 4),
                      Text(
                        'Best Match${widget.matchPercentage != null ? ' · ${widget.matchPercentage}% Compatible' : ''}',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          color: const Color(0xFFE91E8F),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
              ],
              Row(
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: widget.coach.color.withAlpha(31),
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: widget.coach.color.withAlpha(60),
                        width: 2,
                      ),
                    ),
                    child: Center(
                      child: Text(
                        widget.coach.imageInitial,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                          color: widget.coach.color,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.coach.name,
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                            color: titleColor,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          widget.coach.specialty,
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 12,
                            color: widget.coach.color,
                            fontWeight: FontWeight.w500,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                widget.coach.bio,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 13,
                  color: descColor,
                  height: 1.5,
                ),
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  _StatBadge(
                    icon: Icons.star_rounded,
                    value: widget.coach.rating,
                    color: const Color(0xFFD97706),
                    isDark: widget.isDark,
                  ),
                  const SizedBox(width: 8),
                  _StatBadge(
                    icon: Icons.people_outline_rounded,
                    value: '${widget.coach.sessions} sessions',
                    color: const Color(0xFF123C33),
                    isDark: widget.isDark,
                  ),
                  const Spacer(),
                  _ConnectButton(
                    color: widget.coach.color,
                    isLoading: _connecting,
                    onTap: () async {
                      setState(() => _connecting = true);
                      await Future.delayed(const Duration(milliseconds: 1200));
                      if (mounted) setState(() => _connecting = false);
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatBadge extends StatelessWidget {
  final IconData icon;
  final String value;
  final Color color;
  final bool isDark;

  const _StatBadge({
    required this.icon,
    required this.value,
    required this.color,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF3A3A3A) : color.withAlpha(15),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: color),
          const SizedBox(width: 4),
          Text(
            value,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}

class _ConnectButton extends StatefulWidget {
  final Color color;
  final bool isLoading;
  final VoidCallback onTap;

  const _ConnectButton({
    required this.color,
    required this.isLoading,
    required this.onTap,
  });

  @override
  State<_ConnectButton> createState() => _ConnectButtonState();
}

class _ConnectButtonState extends State<_ConnectButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.95 : 1.0,
        duration: const Duration(milliseconds: 100),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: widget.color,
            borderRadius: BorderRadius.circular(10),
            boxShadow: [
              BoxShadow(
                color: widget.color.withAlpha(60),
                blurRadius: 8,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: widget.isLoading
              ? const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.white,
                  ),
                )
              : Text(
                  'Book Session',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
        ),
      ),
    );
  }
}
