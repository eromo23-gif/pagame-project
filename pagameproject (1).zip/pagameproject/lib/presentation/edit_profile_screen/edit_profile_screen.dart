import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

class EditProfileScreen extends StatefulWidget {
  final String initialName;
  final String initialJobTitle;
  final String initialBio;
  final VoidCallback? onSaved;

  const EditProfileScreen({
    super.key,
    this.initialName = 'Maria Rodriguez',
    this.initialJobTitle = 'Senior Product Manager',
    this.initialBio =
        'Passionate about product strategy and pay equity | 5+ years in SaaS',
    this.onSaved,
  });

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen>
    with TickerProviderStateMixin {
  late AnimationController _slideController;
  late Animation<Offset> _slideAnim;

  // Controllers
  late TextEditingController _firstNameCtrl;
  late TextEditingController _lastNameCtrl;
  late TextEditingController _jobTitleCtrl;
  late TextEditingController _companyCtrl;
  late TextEditingController _bioCtrl;
  late TextEditingController _yearsExpCtrl;
  late TextEditingController _cityCtrl;
  late TextEditingController _stateCtrl;
  late TextEditingController _linkedinCtrl;
  late TextEditingController _websiteCtrl;

  // Dropdown values
  String? _selectedIndustry;
  String? _selectedCareerGoal;
  bool _payTransparency = false;
  bool _isSaving = false;

  // Validation errors
  final Map<String, String?> _errors = {};

  static const List<String> _industries = [
    'Tech',
    'Finance',
    'Healthcare',
    'Education',
    'Retail',
    'Other',
  ];

  static const List<String> _careerGoals = [
    'Get a Promotion',
    'Change Careers',
    'Negotiate a Raise',
    'Build Network',
    'Develop Skills',
  ];

  @override
  void initState() {
    super.initState();
    final nameParts = widget.initialName.split(' ');
    _firstNameCtrl = TextEditingController(
      text: nameParts.isNotEmpty ? nameParts.first : '',
    );
    _lastNameCtrl = TextEditingController(
      text: nameParts.length > 1 ? nameParts.sublist(1).join(' ') : '',
    );
    _jobTitleCtrl = TextEditingController(text: widget.initialJobTitle);
    _companyCtrl = TextEditingController(text: 'TechCorp Inc.');
    _bioCtrl = TextEditingController(text: widget.initialBio);
    _yearsExpCtrl = TextEditingController(text: '5');
    _cityCtrl = TextEditingController(text: 'San Francisco');
    _stateCtrl = TextEditingController(text: 'California');
    _linkedinCtrl = TextEditingController(
      text: 'https://linkedin.com/in/mariarodriguez',
    );
    _websiteCtrl = TextEditingController();

    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 320),
    );
    _slideAnim = Tween<Offset>(begin: const Offset(1.0, 0), end: Offset.zero)
        .animate(
          CurvedAnimation(parent: _slideController, curve: Curves.easeOutCubic),
        );
    _slideController.forward();

    _bioCtrl.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _slideController.dispose();
    _firstNameCtrl.dispose();
    _lastNameCtrl.dispose();
    _jobTitleCtrl.dispose();
    _companyCtrl.dispose();
    _bioCtrl.dispose();
    _yearsExpCtrl.dispose();
    _cityCtrl.dispose();
    _stateCtrl.dispose();
    _linkedinCtrl.dispose();
    _websiteCtrl.dispose();
    super.dispose();
  }

  bool _validate() {
    final newErrors = <String, String?>{};
    if (_firstNameCtrl.text.trim().isEmpty) {
      newErrors['firstName'] = 'First name is required';
    }
    if (_lastNameCtrl.text.trim().isEmpty) {
      newErrors['lastName'] = 'Last name is required';
    }
    if (_jobTitleCtrl.text.trim().isEmpty) {
      newErrors['jobTitle'] = 'Job title is required';
    }
    if (_bioCtrl.text.trim().length < 10) {
      newErrors['bio'] = 'Bio must be at least 10 characters';
    }
    setState(() => _errors.addAll(newErrors));
    return newErrors.isEmpty;
  }

  Future<void> _save() async {
    setState(() => _errors.clear());
    if (!_validate()) {
      HapticFeedback.lightImpact();
      return;
    }
    setState(() => _isSaving = true);
    await Future.delayed(const Duration(milliseconds: 900));
    if (!mounted) return;
    setState(() => _isSaving = false);
    widget.onSaved?.call();
    _showSuccessToast();
    await Future.delayed(const Duration(milliseconds: 300));
    if (mounted) Navigator.of(context).pop(true);
  }

  void _showSuccessToast() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(
              Icons.check_circle_rounded,
              color: Colors.white,
              size: 20,
            ),
            const SizedBox(width: 10),
            Text(
              'Profile updated successfully!',
              style: GoogleFonts.plusJakartaSans(
                fontWeight: FontWeight.w600,
                color: Colors.white,
              ),
            ),
          ],
        ),
        backgroundColor: const Color(0xFF34C759),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 24),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  void _showPhotoOptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: const Color(0xFFE0E0E0),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'Change Profile Photo',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: const Color(0xFF1A1A1A),
              ),
            ),
            const SizedBox(height: 16),
            _PhotoOptionTile(
              icon: Icons.camera_alt_outlined,
              label: 'Take Photo',
              onTap: () => Navigator.pop(ctx),
            ),
            _PhotoOptionTile(
              icon: Icons.photo_library_outlined,
              label: 'Choose from Library',
              onTap: () => Navigator.pop(ctx),
            ),
            _PhotoOptionTile(
              icon: Icons.delete_outline_rounded,
              label: 'Remove Photo',
              color: const Color(0xFFFF3B30),
              onTap: () => Navigator.pop(ctx),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final topPad = MediaQuery.of(context).padding.top;
    final bottomPad = MediaQuery.of(context).padding.bottom;

    return SlideTransition(
      position: _slideAnim,
      child: Scaffold(
        backgroundColor: const Color(0xFFF8F8F8),
        body: Column(
          children: [
            // Header
            Container(
              color: Colors.white,
              padding: EdgeInsets.fromLTRB(16, topPad + 8, 16, 12),
              child: Row(
                children: [
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(),
                    style: TextButton.styleFrom(
                      foregroundColor: const Color(0xFF757575),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                    ),
                    child: Text(
                      'Cancel',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Text(
                      'Edit Profile',
                      textAlign: TextAlign.center,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 17,
                        fontWeight: FontWeight.w700,
                        color: const Color(0xFF1A1A1A),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 72,
                    child: _isSaving
                        ? const Center(
                            child: SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2.5,
                                color: Color(0xFFE91E8F),
                              ),
                            ),
                          )
                        : TextButton(
                            onPressed: _save,
                            style: TextButton.styleFrom(
                              foregroundColor: const Color(0xFFE91E8F),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 4,
                              ),
                            ),
                            child: Text(
                              'Save',
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 15,
                                fontWeight: FontWeight.w700,
                                color: const Color(0xFFE91E8F),
                              ),
                            ),
                          ),
                  ),
                ],
              ),
            ),
            // Body
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: EdgeInsets.fromLTRB(16, 16, 16, bottomPad + 40),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Profile Photo
                    _buildSection(
                      title: 'Profile Photo',
                      child: Center(
                        child: Column(
                          children: [
                            Container(
                              width: 90,
                              height: 90,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: const Color(0xFFE91E8F),
                                  width: 3,
                                ),
                                gradient: const LinearGradient(
                                  colors: [
                                    Color(0xFFE91E8F),
                                    Color(0xFFB5157A),
                                  ],
                                ),
                              ),
                              child: const Center(
                                child: Text(
                                  'M',
                                  style: TextStyle(
                                    fontSize: 34,
                                    fontWeight: FontWeight.w700,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(height: 12),
                            TextButton.icon(
                              onPressed: _showPhotoOptions,
                              icon: const Icon(
                                Icons.camera_alt_outlined,
                                size: 16,
                                color: Color(0xFFE91E8F),
                              ),
                              label: Text(
                                'Change Photo',
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  color: const Color(0xFFE91E8F),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Personal Information
                    _buildSection(
                      title: 'Personal Information',
                      child: Column(
                        children: [
                          _buildTextField(
                            controller: _firstNameCtrl,
                            label: 'First Name',
                            error: _errors['firstName'],
                            onChanged: (_) =>
                                setState(() => _errors.remove('firstName')),
                          ),
                          const SizedBox(height: 12),
                          _buildTextField(
                            controller: _lastNameCtrl,
                            label: 'Last Name',
                            error: _errors['lastName'],
                            onChanged: (_) =>
                                setState(() => _errors.remove('lastName')),
                          ),
                          const SizedBox(height: 12),
                          _buildTextField(
                            controller: _jobTitleCtrl,
                            label: 'Job Title',
                            error: _errors['jobTitle'],
                            onChanged: (_) =>
                                setState(() => _errors.remove('jobTitle')),
                          ),
                          const SizedBox(height: 12),
                          _buildTextField(
                            controller: _companyCtrl,
                            label: 'Company',
                          ),
                          const SizedBox(height: 12),
                          _buildDropdown(
                            label: 'Industry',
                            value: _selectedIndustry,
                            items: _industries,
                            onChanged: (v) =>
                                setState(() => _selectedIndustry = v),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Bio
                    _buildSection(
                      title: 'Bio',
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildTextField(
                            controller: _bioCtrl,
                            label: 'Bio',
                            maxLines: 4,
                            maxLength: 150,
                            error: _errors['bio'],
                            hint:
                                'Tell us about yourself, your career goals, and what you\'re passionate about.',
                            onChanged: (_) =>
                                setState(() => _errors.remove('bio')),
                          ),
                          const SizedBox(height: 4),
                          Align(
                            alignment: Alignment.centerRight,
                            child: Text(
                              '${_bioCtrl.text.length}/150',
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 11,
                                color: _bioCtrl.text.length > 140
                                    ? const Color(0xFFFF3B30)
                                    : const Color(0xFF9E9E9E),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Career Details
                    _buildSection(
                      title: 'Career Details',
                      child: Column(
                        children: [
                          _buildTextField(
                            controller: _yearsExpCtrl,
                            label: 'Years of Experience',
                            keyboardType: TextInputType.number,
                          ),
                          const SizedBox(height: 12),
                          _buildDropdown(
                            label: 'Career Goal',
                            value: _selectedCareerGoal,
                            items: _careerGoals,
                            onChanged: (v) =>
                                setState(() => _selectedCareerGoal = v),
                          ),
                          const SizedBox(height: 12),
                          _buildToggle(
                            label: 'Pay Transparency',
                            subtitle:
                                'Share my salary insights anonymously to help others',
                            value: _payTransparency,
                            onChanged: (v) =>
                                setState(() => _payTransparency = v),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Location
                    _buildSection(
                      title: 'Location',
                      child: Column(
                        children: [
                          _buildTextField(controller: _cityCtrl, label: 'City'),
                          const SizedBox(height: 12),
                          _buildTextField(
                            controller: _stateCtrl,
                            label: 'State / Region',
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Social Links
                    _buildSection(
                      title: 'Social Links',
                      child: Column(
                        children: [
                          _buildTextField(
                            controller: _linkedinCtrl,
                            label: 'LinkedIn URL',
                            hint: 'https://linkedin.com/in/yourprofile',
                            keyboardType: TextInputType.url,
                            prefixIcon: Icons.link_rounded,
                          ),
                          const SizedBox(height: 12),
                          _buildTextField(
                            controller: _websiteCtrl,
                            label: 'Website / Portfolio (optional)',
                            hint: 'https://yourwebsite.com',
                            keyboardType: TextInputType.url,
                            prefixIcon: Icons.language_rounded,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),

                    // Save button
                    SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: ElevatedButton(
                        onPressed: _isSaving ? null : _save,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFE91E8F),
                          foregroundColor: Colors.white,
                          disabledBackgroundColor: const Color(
                            0xFFE91E8F,
                          ).withAlpha(120),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                          elevation: 0,
                        ),
                        child: _isSaving
                            ? Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const SizedBox(
                                    width: 18,
                                    height: 18,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      color: Colors.white,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Text(
                                    'Saving...',
                                    style: GoogleFonts.plusJakartaSans(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              )
                            : Text(
                                'Save Changes',
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSection({required String title, required Widget child}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(8),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title.toUpperCase(),
            style: GoogleFonts.plusJakartaSans(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: const Color(0xFF9E9E9E),
              letterSpacing: 0.8,
            ),
          ),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    String? hint,
    String? error,
    int maxLines = 1,
    int? maxLength,
    TextInputType? keyboardType,
    IconData? prefixIcon,
    ValueChanged<String>? onChanged,
  }) {
    final hasError = error != null && error.isNotEmpty;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          child: TextField(
            controller: controller,
            maxLines: maxLines,
            maxLength: maxLength,
            keyboardType: keyboardType,
            onChanged: onChanged,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 14,
              color: const Color(0xFF1A1A1A),
            ),
            decoration: InputDecoration(
              labelText: label,
              hintText: hint,
              counterText: '',
              prefixIcon: prefixIcon != null
                  ? Icon(prefixIcon, size: 18, color: const Color(0xFF9E9E9E))
                  : null,
              labelStyle: GoogleFonts.plusJakartaSans(
                fontSize: 13,
                color: hasError
                    ? const Color(0xFFFF3B30)
                    : const Color(0xFF9E9E9E),
              ),
              hintStyle: GoogleFonts.plusJakartaSans(
                fontSize: 13,
                color: const Color(0xFFBDBDBD),
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: hasError
                      ? const Color(0xFFFF3B30)
                      : const Color(0xFFE0E0E0),
                ),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: hasError
                      ? const Color(0xFFFF3B30)
                      : const Color(0xFFE0E0E0),
                ),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: hasError
                      ? const Color(0xFFFF3B30)
                      : const Color(0xFFE91E8F),
                  width: 2,
                ),
              ),
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 14,
                vertical: 14,
              ),
              filled: true,
              fillColor: const Color(0xFFFAFAFA),
            ),
          ),
        ),
        if (hasError) ...[
          const SizedBox(height: 4),
          Text(
            error,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 11,
              color: const Color(0xFFFF3B30),
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildDropdown({
    required String label,
    required String? value,
    required List<String> items,
    required ValueChanged<String?> onChanged,
  }) {
    return DropdownButtonFormField<String>(
      initialValue: value,
      onChanged: onChanged,
      style: GoogleFonts.plusJakartaSans(
        fontSize: 14,
        color: const Color(0xFF1A1A1A),
      ),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: GoogleFonts.plusJakartaSans(
          fontSize: 13,
          color: const Color(0xFF9E9E9E),
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFFE0E0E0)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFFE0E0E0)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFFE91E8F), width: 2),
        ),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 14,
          vertical: 14,
        ),
        filled: true,
        fillColor: const Color(0xFFFAFAFA),
      ),
      items: items
          .map(
            (item) => DropdownMenuItem(
              value: item,
              child: Text(
                item,
                style: GoogleFonts.plusJakartaSans(fontSize: 14),
              ),
            ),
          )
          .toList(),
    );
  }

  Widget _buildToggle({
    required String label,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: const Color(0xFF1A1A1A),
                ),
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 12,
                  color: const Color(0xFF757575),
                  height: 1.4,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 12),
        Switch.adaptive(
          value: value,
          onChanged: onChanged,
          activeColor: const Color(0xFFE91E8F),
        ),
      ],
    );
  }
}

class _PhotoOptionTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _PhotoOptionTile({
    required this.icon,
    required this.label,
    required this.onTap,
    this.color = const Color(0xFF1A1A1A),
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: color, size: 22),
      title: Text(
        label,
        style: GoogleFonts.plusJakartaSans(
          fontSize: 15,
          fontWeight: FontWeight.w500,
          color: color,
        ),
      ),
      onTap: onTap,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    );
  }
}
