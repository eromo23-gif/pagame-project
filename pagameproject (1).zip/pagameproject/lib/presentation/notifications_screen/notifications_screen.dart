import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/app_state.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _entranceController;
  final AppState _appState = AppState();

  final List<Map<String, dynamic>> _notifications = [
    {
      'icon': Icons.analytics_outlined,
      'iconColor': const Color(0xFFE91E8F),
      'iconBg': const Color(0xFFFFF0F7),
      'title': 'Your pay gap analysis is ready',
      'message': 'View your personalized pay gap report and negotiation tips.',
      'time': '2 hours ago',
      'unread': true,
    },
    {
      'icon': Icons.people_outline_rounded,
      'iconColor': const Color(0xFF123C33),
      'iconBg': const Color(0xFFE8F5F0),
      'title': 'New coach match: Dr. Maria Santos',
      'message': 'Based on your assessment, Dr. Santos is a 94% match for you.',
      'time': '1 day ago',
      'unread': true,
    },
    {
      'icon': Icons.map_outlined,
      'iconColor': const Color(0xFF7B2D8B),
      'iconBg': const Color(0xFFF3E8F9),
      'title': 'Career Journey Milestone',
      'message':
          "Complete 'Build Skills' to unlock your next career milestone.",
      'time': '3 days ago',
      'unread': false,
    },
    {
      'icon': Icons.emoji_events_outlined,
      'iconColor': const Color(0xFFE65100),
      'iconBg': const Color(0xFFFFF3E0),
      'title': "You've earned a badge: Pay Equity Advocate",
      'message': 'Congratulations! You completed your first pay gap analysis.',
      'time': '5 days ago',
      'unread': false,
    },
    {
      'icon': Icons.star_outline_rounded,
      'iconColor': const Color(0xFF1565C0),
      'iconBg': const Color(0xFFE8F0FE),
      'title': 'Her Promotion Club: New content available',
      'message': 'New resources have been added to your club library.',
      'time': '1 week ago',
      'unread': false,
    },
  ];

  @override
  void initState() {
    super.initState();
    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _entranceController.forward();
    });
    _appState.addListener(_onStateChanged);
  }

  void _onStateChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _entranceController.dispose();
    _appState.removeListener(_onStateChanged);
    super.dispose();
  }

  Widget _buildEntrance({required int index, required Widget child}) {
    final delay = (index * 0.08).clamp(0.0, 0.65);
    final end = (delay + 0.35).clamp(0.0, 1.0);
    final fade = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _entranceController,
        curve: Interval(delay, end, curve: Curves.easeOut),
      ),
    );
    final slide = Tween<Offset>(begin: const Offset(0, 0.1), end: Offset.zero)
        .animate(
          CurvedAnimation(
            parent: _entranceController,
            curve: Interval(delay, end, curve: Curves.easeOutCubic),
          ),
        );
    return FadeTransition(
      opacity: fade,
      child: SlideTransition(position: slide, child: child),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bottomPadding = MediaQuery.of(context).padding.bottom;
    final isDark = _appState.isDarkMode;
    final bgColor = isDark ? const Color(0xFF1A1A1A) : const Color(0xFFFAFAFA);
    final cardColor = isDark ? const Color(0xFF2D2D2D) : Colors.white;
    final borderColor = isDark
        ? const Color(0xFF4A4A4A)
        : const Color(0xFFE8D5DF);
    final titleColor = isDark
        ? const Color(0xFFE6E6E6)
        : const Color(0xFF1A1A1A);
    final subtitleColor = isDark
        ? const Color(0xFFAAAAAA)
        : const Color(0xFF757575);

    final unreadCount = _notifications.where((n) => n['unread'] == true).length;

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        backgroundColor: const Color(0xFF123C33),
        foregroundColor: Colors.white,
        elevation: 0,
        title: Row(
          children: [
            Text(
              'Notifications',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 17,
                fontWeight: FontWeight.w700,
                color: Colors.white,
              ),
            ),
            if (unreadCount > 0) ...[
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: const Color(0xFFE91E8F),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  '$unreadCount',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ],
        ),
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_rounded,
            color: Colors.white,
            size: 20,
          ),
          onPressed: () => Navigator.of(context).pop(),
        ),
        actions: [
          TextButton(
            onPressed: () {
              setState(() {
                for (final n in _notifications) {
                  n['unread'] = false;
                }
              });
            },
            child: Text(
              'Mark all read',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 13,
                color: Colors.white.withAlpha(200),
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.fromLTRB(20, 20, 20, bottomPadding + 40),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ...List.generate(_notifications.length, (i) {
              final notif = _notifications[i];
              return _buildEntrance(
                index: i,
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _NotificationCard(
                    notif: notif,
                    isDark: isDark,
                    cardColor: cardColor,
                    borderColor: borderColor,
                    titleColor: titleColor,
                    subtitleColor: subtitleColor,
                    onTap: () {
                      setState(() => notif['unread'] = false);
                    },
                  ),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}

class _NotificationCard extends StatelessWidget {
  final Map<String, dynamic> notif;
  final bool isDark;
  final Color cardColor;
  final Color borderColor;
  final Color titleColor;
  final Color subtitleColor;
  final VoidCallback onTap;

  const _NotificationCard({
    required this.notif,
    required this.isDark,
    required this.cardColor,
    required this.borderColor,
    required this.titleColor,
    required this.subtitleColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isUnread = notif['unread'] as bool;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: isUnread
              ? (isDark ? const Color(0xFF3A2A35) : const Color(0xFFFFF5FA))
              : cardColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isUnread
                ? const Color(0xFFE91E8F).withAlpha(60)
                : borderColor,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withAlpha(isDark ? 20 : 8),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: notif['iconBg'] as Color,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                notif['icon'] as IconData,
                color: notif['iconColor'] as Color,
                size: 22,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          notif['title'] as String,
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 14,
                            fontWeight: isUnread
                                ? FontWeight.w700
                                : FontWeight.w600,
                            color: titleColor,
                          ),
                        ),
                      ),
                      if (isUnread)
                        Container(
                          width: 8,
                          height: 8,
                          decoration: const BoxDecoration(
                            color: Color(0xFFE91E8F),
                            shape: BoxShape.circle,
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    notif['message'] as String,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 12,
                      color: subtitleColor,
                      height: 1.4,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    notif['time'] as String,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 11,
                      color: isDark
                          ? const Color(0xFF666666)
                          : const Color(0xFFBDBDBD),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
