import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';

import '../../core/app_state.dart';
import '../edit_profile_screen/edit_profile_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen>
    with TickerProviderStateMixin {
  late AnimationController _entranceController;
  late AnimationController _avatarController;
  late TabController _tabController;
  final AppState _appState = AppState();

  bool _isEditingBio = false;
  final TextEditingController _bioController = TextEditingController(
    text: 'Passionate about product strategy and pay equity | 5+ years in SaaS',
  );

  // Saved calculations list — mutable for delete
  final List<Map<String, String>> _calculations = [
    {
      'title': 'Software Engineer',
      'industry': 'Technology & Software',
      'salary': '\$75,000',
      'market': '\$92,000',
      'gap': '\$17,000',
      'gapPct': '18.5%',
      'date': 'June 20, 2026',
    },
    {
      'title': 'Product Analyst',
      'industry': 'Business & Finance',
      'salary': '\$68,500',
      'market': '\$80,000',
      'gap': '\$11,500',
      'gapPct': '14.4%',
      'date': 'June 14, 2026',
    },
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    _avatarController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _entranceController.forward();
      Future.delayed(const Duration(milliseconds: 200), () {
        if (mounted) _avatarController.forward();
      });
    });
    _appState.addListener(_onStateChanged);
  }

  void _onStateChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _entranceController.dispose();
    _avatarController.dispose();
    _tabController.dispose();
    _bioController.dispose();
    _appState.removeListener(_onStateChanged);
    super.dispose();
  }

  Widget _buildEntrance({required int index, required Widget child}) {
    final delay = (index * 0.07).clamp(0.0, 0.65);
    final end = (delay + 0.35).clamp(0.0, 1.0);
    final fade = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _entranceController,
        curve: Interval(delay, end, curve: Curves.easeOut),
      ),
    );
    final slide = Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero)
        .animate(
          CurvedAnimation(
            parent: _entranceController,
            curve: Interval(delay, end, curve: Curves.easeOutCubic),
          ),
        );
    return FadeTransition(
      opacity: fade,
      child: SlideTransition(position: slide, child: child),
    );
  }

  void _showToast(
    String message, {
    bool isSuccess = true,
    bool isError = false,
  }) {
    Color bg = isError
        ? const Color(0xFFFF3B30)
        : isSuccess
        ? const Color(0xFF34C759)
        : const Color(0xFF007AFF);
    IconData icon = isError
        ? Icons.cancel_rounded
        : isSuccess
        ? Icons.check_circle_rounded
        : Icons.info_rounded;

    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(icon, color: Colors.white, size: 20),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                message,
                style: GoogleFonts.plusJakartaSans(
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: bg,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 24),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  void _showSignOutDialog() {
    final isDark = _appState.isDarkMode;
    showDialog(
      context: context,
      barrierColor: Colors.black.withAlpha(128),
      builder: (ctx) => _AnimatedDialog(
        child: AlertDialog(
          backgroundColor: isDark ? const Color(0xFF2D2D2D) : Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          title: Text(
            'Sign Out?',
            style: GoogleFonts.plusJakartaSans(
              fontWeight: FontWeight.w700,
              fontSize: 18,
              color: isDark ? const Color(0xFFE6E6E6) : const Color(0xFF1A1A1A),
            ),
          ),
          content: Text(
            'Are you sure you want to sign out of your account?',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 14,
              color: isDark ? const Color(0xFFAAAAAA) : const Color(0xFF757575),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(),
              child: Text(
                'Cancel',
                style: GoogleFonts.plusJakartaSans(
                  fontWeight: FontWeight.w600,
                  color: isDark
                      ? const Color(0xFFAAAAAA)
                      : const Color(0xFF757575),
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(ctx).pop();
                context.go('/');
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFE91E8F),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: Text(
                'Sign Out',
                style: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _openEditProfile() async {
    final result = await Navigator.of(context).push<bool>(
      PageRouteBuilder(
        pageBuilder: (ctx, animation, secondaryAnimation) =>
            EditProfileScreen(initialBio: _bioController.text, onSaved: () {}),
        transitionDuration: const Duration(milliseconds: 320),
        transitionsBuilder: (ctx, animation, secondaryAnimation, child) {
          return SlideTransition(
            position:
                Tween<Offset>(
                  begin: const Offset(1.0, 0),
                  end: Offset.zero,
                ).animate(
                  CurvedAnimation(
                    parent: animation,
                    curve: Curves.easeOutCubic,
                  ),
                ),
            child: child,
          );
        },
      ),
    );
    if (result == true && mounted) {
      _showToast('Profile updated successfully!');
    }
  }

  void _showShareProfile() {
    _showToast('Profile link copied to clipboard!');
  }

  void _showMoreOptions() {
    final isDark = _appState.isDarkMode;
    showModalBottomSheet(
      context: context,
      backgroundColor: isDark ? const Color(0xFF2D2D2D) : Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: isDark
                    ? const Color(0xFF4A4A4A)
                    : const Color(0xFFE0E0E0),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 20),
            _MoreOptionTile(
              icon: Icons.qr_code_rounded,
              label: 'QR Code',
              isDark: isDark,
              onTap: () {
                Navigator.pop(ctx);
                _showToast('QR Code feature coming soon!', isSuccess: false);
              },
            ),
            _MoreOptionTile(
              icon: Icons.block_rounded,
              label: 'Block User',
              isDark: isDark,
              onTap: () => Navigator.pop(ctx),
            ),
            _MoreOptionTile(
              icon: Icons.report_outlined,
              label: 'Report',
              isDark: isDark,
              onTap: () => Navigator.pop(ctx),
            ),
          ],
        ),
      ),
    );
  }

  void _showDeleteCalcDialog(int index) {
    final calc = _calculations[index];
    final isDark = _appState.isDarkMode;
    showDialog(
      context: context,
      barrierColor: Colors.black.withAlpha(128),
      builder: (ctx) => _AnimatedDialog(
        child: AlertDialog(
          backgroundColor: isDark ? const Color(0xFF2D2D2D) : Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          title: Text(
            'Delete Calculation?',
            style: GoogleFonts.plusJakartaSans(
              fontWeight: FontWeight.w700,
              fontSize: 18,
              color: isDark ? const Color(0xFFE6E6E6) : const Color(0xFF1A1A1A),
            ),
          ),
          content: Text(
            'Are you sure you want to delete this saved calculation for ${calc['title']}?',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 14,
              color: isDark ? const Color(0xFFAAAAAA) : const Color(0xFF757575),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(),
              child: Text(
                'Cancel',
                style: GoogleFonts.plusJakartaSans(
                  fontWeight: FontWeight.w600,
                  color: isDark
                      ? const Color(0xFFAAAAAA)
                      : const Color(0xFF757575),
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(ctx).pop();
                setState(() => _calculations.removeAt(index));
                HapticFeedback.mediumImpact();
                _showToast(
                  'Calculation deleted successfully',
                  isError: false,
                  isSuccess: true,
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFF3B30),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: Text(
                'Delete',
                style: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showCalculationDetail(int index) {
    final calc = _calculations[index];
    final isDark = _appState.isDarkMode;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: isDark ? const Color(0xFF2D2D2D) : Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.75,
        maxChildSize: 0.92,
        builder: (_, scrollController) => SingleChildScrollView(
          controller: scrollController,
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: isDark
                        ? const Color(0xFF4A4A4A)
                        : const Color(0xFFE0E0E0),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFF0F7),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Icon(
                      Icons.calculate_outlined,
                      color: Color(0xFFE91E8F),
                      size: 24,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          calc['title'] ?? 'Unknown Title',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            color: isDark
                                ? const Color(0xFFE6E6E6)
                                : const Color(0xFF1A1A1A),
                          ),
                        ),
                        Text(
                          calc['industry'] ?? '',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 13,
                            color: isDark
                                ? const Color(0xFFAAAAAA)
                                : const Color(0xFF757575),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              _DetailRow(
                label: 'Current Salary',
                value: calc['salary'] ?? 'N/A',
                isDark: isDark,
                valueColor: const Color(0xFF123C33),
              ),
              _DetailRow(
                label: 'Expected Market Salary',
                value: calc['market'] ?? 'N/A',
                isDark: isDark,
                valueColor: const Color(0xFF123C33),
              ),
              _DetailRow(
                label: 'Pay Gap',
                value: calc['gap'] ?? 'N/A',
                isDark: isDark,
                valueColor: const Color(0xFFE91E8F),
              ),
              _DetailRow(
                label: 'Pay Gap %',
                value: calc['gapPct'] ?? 'N/A',
                isDark: isDark,
                valueColor: const Color(0xFFE91E8F),
              ),
              _DetailRow(
                label: 'Date',
                value: calc['date'] ?? 'N/A',
                isDark: isDark,
              ),
              const SizedBox(height: 24),
              Text(
                'Salary Comparison',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: isDark
                      ? const Color(0xFFE6E6E6)
                      : const Color(0xFF1A1A1A),
                ),
              ),
              const SizedBox(height: 12),
              _SalaryBarChart(
                yourSalary:
                    double.tryParse(
                      (calc['salary'] ?? '').replaceAll(RegExp(r'[^\d.]'), ''),
                    ) ??
                    75000,
                marketSalary:
                    double.tryParse(
                      (calc['market'] ?? '').replaceAll(RegExp(r'[^\d.]'), ''),
                    ) ??
                    90000,
                isDark: isDark,
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () {
                    Navigator.pop(ctx);
                    _showDeleteCalcDialog(index);
                  },
                  icon: const Icon(
                    Icons.delete_outline_rounded,
                    color: Color(0xFFFF3B30),
                    size: 18,
                  ),
                  label: Text(
                    'Delete',
                    style: GoogleFonts.plusJakartaSans(
                      color: const Color(0xFFFF3B30),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: Color(0xFFFF3B30)),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showCoachDetail(Map<String, dynamic> coach) {
    final isDark = _appState.isDarkMode;
    final color = coach['color'] as Color;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: isDark ? const Color(0xFF2D2D2D) : Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.75,
        maxChildSize: 0.92,
        builder: (_, scrollController) => SingleChildScrollView(
          controller: scrollController,
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: isDark
                        ? const Color(0xFF4A4A4A)
                        : const Color(0xFFE0E0E0),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Center(
                child: Column(
                  children: [
                    Container(
                      width: 80,
                      height: 80,
                      decoration: BoxDecoration(
                        color: color.withAlpha(40),
                        shape: BoxShape.circle,
                        border: Border.all(color: color, width: 2.5),
                      ),
                      child: Center(
                        child: Text(
                          coach['initial'] as String,
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 28,
                            fontWeight: FontWeight.w700,
                            color: color,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      coach['name'] as String,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                        color: isDark
                            ? const Color(0xFFE6E6E6)
                            : const Color(0xFF1A1A1A),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      coach['title'] as String,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 14,
                        color: isDark
                            ? const Color(0xFFAAAAAA)
                            : const Color(0xFF757575),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(
                        5,
                        (i) => Icon(
                          i < (coach['rating'] as int)
                              ? Icons.star_rounded
                              : Icons.star_outline_rounded,
                          color: const Color(0xFFE91E8F),
                          size: 20,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: isDark
                      ? const Color(0xFF3A3A3A)
                      : const Color(0xFFFAFAFA),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Specialty',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: isDark
                            ? const Color(0xFF888888)
                            : const Color(0xFF9E9E9E),
                        letterSpacing: 0.8,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      coach['specialty'] as String,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        color: isDark
                            ? const Color(0xFFE6E6E6)
                            : const Color(0xFF1A1A1A),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Bio',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: isDark
                            ? const Color(0xFF888888)
                            : const Color(0xFF9E9E9E),
                        letterSpacing: 0.8,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      coach['bio'] as String,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 14,
                        color: isDark
                            ? const Color(0xFFCCCCCC)
                            : const Color(0xFF555555),
                        height: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () {
                        Navigator.pop(ctx);
                        _showToast('Message sent to ${coach['name']}!');
                      },
                      icon: const Icon(Icons.message_outlined, size: 18),
                      label: Text(
                        'Message',
                        style: GoogleFonts.plusJakartaSans(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFE91E8F),
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () {
                        Navigator.pop(ctx);
                        _showToast(
                          'Calendar feature coming soon!',
                          isSuccess: false,
                        );
                      },
                      icon: const Icon(
                        Icons.calendar_today_outlined,
                        size: 18,
                        color: Color(0xFF123C33),
                      ),
                      label: Text(
                        'Calendar',
                        style: GoogleFonts.plusJakartaSans(
                          fontWeight: FontWeight.w600,
                          color: const Color(0xFF123C33),
                        ),
                      ),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: Color(0xFF123C33)),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: TextButton(
                  onPressed: () {
                    Navigator.pop(ctx);
                    _showToast('Connection removed.', isError: true);
                  },
                  child: Text(
                    'Remove Connection',
                    style: GoogleFonts.plusJakartaSans(
                      color: const Color(0xFFFF3B30),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bottomPadding = MediaQuery.of(context).padding.bottom;
    final isDark = _appState.isDarkMode;
    final bgColor = isDark ? const Color(0xFF1A1A1A) : const Color(0xFFFAFAFA);
    final cardColor = isDark ? const Color(0xFF2D2D2D) : Colors.white;
    final borderColor = isDark
        ? const Color(0xFF4A4A4A)
        : const Color(0xFFE8D5DF);
    final titleColor = isDark
        ? const Color(0xFFE6E6E6)
        : const Color(0xFF1A1A1A);
    final subtitleColor = isDark
        ? const Color(0xFFAAAAAA)
        : const Color(0xFF757575);

    return Scaffold(
      backgroundColor: bgColor,
      body: NestedScrollView(
        physics: const BouncingScrollPhysics(),
        headerSliverBuilder: (context, innerBoxIsScrolled) => [
          SliverToBoxAdapter(
            child: _buildEntrance(
              index: 0,
              child: _ProfileHeader(
                isDark: isDark,
                cardColor: cardColor,
                titleColor: titleColor,
                subtitleColor: subtitleColor,
                bioController: _bioController,
                isEditingBio: _isEditingBio,
                avatarController: _avatarController,
                onEditBio: () => setState(() => _isEditingBio = true),
                onSaveBio: () => setState(() => _isEditingBio = false),
                onEditProfile: _openEditProfile,
                onShareProfile: _showShareProfile,
                onMore: _showMoreOptions,
                onSettings: () => context.push('/settings'),
                onNotifications: () => context.push('/notifications'),
              ),
            ),
          ),
          SliverAppBar(
            pinned: true,
            floating: false,
            snap: false,
            automaticallyImplyLeading: false,
            toolbarHeight: 52,
            elevation: 0,
            backgroundColor: isDark ? const Color(0xFF2D2D2D) : Colors.white,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                color: isDark ? const Color(0xFF2D2D2D) : Colors.white,
                child: TabBar(
                  controller: _tabController,
                  isScrollable: true,
                  tabAlignment: TabAlignment.start,
                  indicatorColor: const Color(0xFFE91E8F),
                  indicatorWeight: 3,
                  labelColor: const Color(0xFFE91E8F),
                  unselectedLabelColor: isDark
                      ? const Color(0xFF888888)
                      : const Color(0xFF9E9E9E),
                  labelStyle: GoogleFonts.plusJakartaSans(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  ),
                  unselectedLabelStyle: GoogleFonts.plusJakartaSans(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  tabs: const [
                    Tab(text: 'Overview'),
                    Tab(text: 'Career Tools'),
                    Tab(text: 'Saved Results'),
                    Tab(text: 'Coaches'),
                  ],
                ),
              ),
            ),
          ),
        ],
        body: TabBarView(
          controller: _tabController,
          children: [
            // Overview tab
            _OverviewTab(
              isDark: isDark,
              cardColor: cardColor,
              borderColor: borderColor,
              titleColor: titleColor,
              subtitleColor: subtitleColor,
              bottomPadding: bottomPadding,
              onSignOut: _showSignOutDialog,
              onSettings: () => context.push('/settings'),
              onHelp: () => context.push('/help-support'),
              onNotifications: () => context.push('/notifications'),
              buildEntrance: _buildEntrance,
            ),
            // Career Tools tab
            _CareerToolsTab(
              isDark: isDark,
              cardColor: cardColor,
              borderColor: borderColor,
              titleColor: titleColor,
              subtitleColor: subtitleColor,
              bottomPadding: bottomPadding,
              buildEntrance: _buildEntrance,
            ),
            // Saved Results tab
            _SavedResultsTab(
              isDark: isDark,
              cardColor: cardColor,
              borderColor: borderColor,
              titleColor: titleColor,
              subtitleColor: subtitleColor,
              bottomPadding: bottomPadding,
              calculations: _calculations,
              onCalcTap: _showCalculationDetail,
              onCalcDelete: _showDeleteCalcDialog,
              buildEntrance: _buildEntrance,
            ),
            // Coaches tab
            _CoachesTab(
              isDark: isDark,
              cardColor: cardColor,
              borderColor: borderColor,
              titleColor: titleColor,
              subtitleColor: subtitleColor,
              bottomPadding: bottomPadding,
              onCoachTap: _showCoachDetail,
              buildEntrance: _buildEntrance,
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Animated Dialog Wrapper ──────────────────────────────────────────────────

class _AnimatedDialog extends StatefulWidget {
  final Widget child;
  const _AnimatedDialog({required this.child});

  @override
  State<_AnimatedDialog> createState() => _AnimatedDialogState();
}

class _AnimatedDialogState extends State<_AnimatedDialog>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;
  late Animation<double> _fade;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 220),
    );
    _scale = Tween<double>(
      begin: 0.9,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutBack));
    _fade = Tween<double>(
      begin: 0,
      end: 1,
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
    _ctrl.forward();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fade,
      child: ScaleTransition(scale: _scale, child: widget.child),
    );
  }
}

// ─── Profile Header ───────────────────────────────────────────────────────────

class _ProfileHeader extends StatelessWidget {
  final bool isDark;
  final Color cardColor;
  final Color titleColor;
  final Color subtitleColor;
  final TextEditingController bioController;
  final bool isEditingBio;
  final AnimationController avatarController;
  final VoidCallback onEditBio;
  final VoidCallback onSaveBio;
  final VoidCallback onEditProfile;
  final VoidCallback onShareProfile;
  final VoidCallback onMore;
  final VoidCallback onSettings;
  final VoidCallback onNotifications;

  const _ProfileHeader({
    required this.isDark,
    required this.cardColor,
    required this.titleColor,
    required this.subtitleColor,
    required this.bioController,
    required this.isEditingBio,
    required this.avatarController,
    required this.onEditBio,
    required this.onSaveBio,
    required this.onEditProfile,
    required this.onShareProfile,
    required this.onMore,
    required this.onSettings,
    required this.onNotifications,
  });

  @override
  Widget build(BuildContext context) {
    final avatarScale = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: avatarController, curve: Curves.elasticOut),
    );
    final coverFade = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: avatarController,
        curve: const Interval(0, 0.6, curve: Curves.easeOut),
      ),
    );

    return Column(
      children: [
        // Cover photo + avatar stack
        Stack(
          clipBehavior: Clip.none,
          alignment: Alignment.bottomCenter,
          children: [
            // Cover photo (120px)
            FadeTransition(
              opacity: coverFade,
              child: Container(
                height: 120,
                width: double.infinity,
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Color(0xFFE91E8F),
                      Color(0xFF7B1FA2),
                      Color(0xFF123C33),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: SafeArea(
                  bottom: false,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 8,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'My Profile',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                          ),
                        ),
                        Row(
                          children: [
                            _IconBtn(
                              icon: Icons.notifications_outlined,
                              onTap: onNotifications,
                            ),
                            const SizedBox(width: 4),
                            _IconBtn(
                              icon: Icons.settings_outlined,
                              onTap: onSettings,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            // Edit Cover button
            Positioned(
              bottom: 10,
              right: 14,
              child: GestureDetector(
                onTap: () {},
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 5,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.black.withAlpha(100),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.camera_alt_outlined,
                        color: Colors.white,
                        size: 13,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        'Edit Cover',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            // Avatar — positioned so it overlaps cover by ~40px and is fully visible
            Positioned(
              bottom: -54,
              child: ScaleTransition(
                scale: avatarScale,
                child: Stack(
                  children: [
                    Container(
                      width: 100,
                      height: 100,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: isDark
                              ? const Color(0xFF2D2D2D)
                              : Colors.white,
                          width: 4,
                        ),
                        gradient: const LinearGradient(
                          colors: [Color(0xFFE91E8F), Color(0xFFB5157A)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFFE91E8F).withAlpha(80),
                            blurRadius: 20,
                            offset: const Offset(0, 8),
                          ),
                        ],
                      ),
                      child: const Center(
                        child: Text(
                          'M',
                          style: TextStyle(
                            fontSize: 38,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: 2,
                      right: 2,
                      child: Container(
                        width: 30,
                        height: 30,
                        decoration: BoxDecoration(
                          color: const Color(0xFF123C33),
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: isDark
                                ? const Color(0xFF2D2D2D)
                                : Colors.white,
                            width: 2,
                          ),
                        ),
                        child: const Icon(
                          Icons.camera_alt_rounded,
                          size: 14,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        // Profile info below cover — top padding accounts for avatar overlap
        Container(
          color: isDark ? const Color(0xFF2D2D2D) : Colors.white,
          padding: const EdgeInsets.fromLTRB(20, 64, 20, 20),
          child: Column(
            children: [
              // Name + verified badge
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Maria Rodriguez',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                      color: titleColor,
                    ),
                  ),
                  const SizedBox(width: 6),
                  Container(
                    width: 22,
                    height: 22,
                    decoration: const BoxDecoration(
                      color: Color(0xFFE91E8F),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.check_rounded,
                      color: Colors.white,
                      size: 14,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                'Senior Product Manager · TechCorp Inc.',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 14,
                  color: subtitleColor,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 12),
              // Bio
              isEditingBio
                  ? Column(
                      children: [
                        TextField(
                          controller: bioController,
                          maxLines: 2,
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 13,
                            color: titleColor,
                          ),
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: const BorderSide(
                                color: Color(0xFFE91E8F),
                                width: 2,
                              ),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: const BorderSide(
                                color: Color(0xFFE91E8F),
                                width: 2,
                              ),
                            ),
                            contentPadding: const EdgeInsets.all(12),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Align(
                          alignment: Alignment.centerRight,
                          child: TextButton(
                            onPressed: onSaveBio,
                            child: Text(
                              'Save Bio',
                              style: GoogleFonts.plusJakartaSans(
                                color: const Color(0xFFE91E8F),
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                      ],
                    )
                  : GestureDetector(
                      onTap: onEditBio,
                      child: Text(
                        bioController.text,
                        textAlign: TextAlign.center,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 13,
                          color: subtitleColor,
                          height: 1.5,
                        ),
                      ),
                    ),
              const SizedBox(height: 16),
              // Action buttons
              Row(
                children: [
                  Expanded(
                    child: _ActionButton(
                      label: 'Edit Profile',
                      isPrimary: true,
                      onTap: onEditProfile,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _ActionButton(
                      label: 'Share Profile',
                      isPrimary: false,
                      onTap: onShareProfile,
                    ),
                  ),
                  const SizedBox(width: 8),
                  _MoreBtn(onTap: onMore, isDark: isDark),
                ],
              ),
              const SizedBox(height: 20),
              // Stats row
              Container(
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(
                  color: isDark
                      ? const Color(0xFF3A3A3A)
                      : const Color(0xFFFAFAFA),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: isDark
                        ? const Color(0xFF4A4A4A)
                        : const Color(0xFFE8D5DF),
                  ),
                ),
                child: Row(
                  children: [
                    _StatItem(
                      value: '78',
                      label: 'Career Score',
                      isDark: isDark,
                    ),
                    _StatDivider(isDark: isDark),
                    _StatItem(value: '12', label: 'Wins', isDark: isDark),
                    _StatDivider(isDark: isDark),
                    _StatItem(value: '8', label: 'Connections', isDark: isDark),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              // Club badge
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF0F7),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: const Color(0xFFE91E8F).withAlpha(77),
                  ),
                ),
                child: Text(
                  '✦ Her Promotion Club Member',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: const Color(0xFFE91E8F),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ─── Overview Tab ─────────────────────────────────────────────────────────────

class _OverviewTab extends StatelessWidget {
  final bool isDark;
  final Color cardColor;
  final Color borderColor;
  final Color titleColor;
  final Color subtitleColor;
  final double bottomPadding;
  final VoidCallback onSignOut;
  final VoidCallback onSettings;
  final VoidCallback onHelp;
  final VoidCallback onNotifications;
  final Widget Function({required int index, required Widget child})
  buildEntrance;

  const _OverviewTab({
    required this.isDark,
    required this.cardColor,
    required this.borderColor,
    required this.titleColor,
    required this.subtitleColor,
    required this.bottomPadding,
    required this.onSignOut,
    required this.onSettings,
    required this.onHelp,
    required this.onNotifications,
    required this.buildEntrance,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: EdgeInsets.fromLTRB(20, 20, 20, bottomPadding + 100),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          buildEntrance(
            index: 1,
            child: _SectionLabel(title: 'Account', isDark: isDark),
          ),
          const SizedBox(height: 8),
          buildEntrance(
            index: 2,
            child: _MenuGroup(
              isDark: isDark,
              cardColor: cardColor,
              borderColor: borderColor,
              items: [
                _MenuItem(
                  icon: Icons.notifications_outlined,
                  label: 'Notifications',
                  iconColor: const Color(0xFFE91E8F),
                  iconBg: const Color(0xFFFFF0F7),
                  isDark: isDark,
                  onTap: onNotifications,
                ),
                _MenuItem(
                  icon: Icons.settings_outlined,
                  label: 'Settings',
                  iconColor: const Color(0xFF123C33),
                  iconBg: const Color(0xFFE8F5F0),
                  isDark: isDark,
                  onTap: onSettings,
                ),
                _MenuItem(
                  icon: Icons.help_outline_rounded,
                  label: 'Help & Support',
                  iconColor: const Color(0xFF757575),
                  iconBg: const Color(0xFFF5F5F5),
                  isDark: isDark,
                  onTap: onHelp,
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          buildEntrance(
            index: 3,
            child: _MenuGroup(
              isDark: isDark,
              cardColor: cardColor,
              borderColor: borderColor,
              items: [
                _MenuItem(
                  icon: Icons.logout_rounded,
                  label: 'Sign Out',
                  iconColor: const Color(0xFFFF3B30),
                  iconBg: const Color(0xFFFEF2F2),
                  labelColor: const Color(0xFFFF3B30),
                  showArrow: false,
                  isDark: isDark,
                  onTap: onSignOut,
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          Center(
            child: Text(
              'Págame Project v1.0.0',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 12,
                color: isDark
                    ? const Color(0xFF666666)
                    : const Color(0xFFBDBDBD),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Career Tools Tab ─────────────────────────────────────────────────────────

class _CareerToolsTab extends StatelessWidget {
  final bool isDark;
  final Color cardColor;
  final Color borderColor;
  final Color titleColor;
  final Color subtitleColor;
  final double bottomPadding;
  final Widget Function({required int index, required Widget child})
  buildEntrance;

  const _CareerToolsTab({
    required this.isDark,
    required this.cardColor,
    required this.borderColor,
    required this.titleColor,
    required this.subtitleColor,
    required this.bottomPadding,
    required this.buildEntrance,
  });

  static const List<Map<String, dynamic>> _tools = [
    {
      'icon': Icons.psychology_outlined,
      'title': 'RITA AI Chat',
      'desc': 'Your personal career AI assistant',
      'color': Color(0xFFE91E8F),
      'bg': Color(0xFFFFF0F7),
      'route': '/rita-ai',
    },
    {
      'icon': Icons.calculate_outlined,
      'title': 'Gender Pay Calculator',
      'desc': 'Analyze your pay gap',
      'color': Color(0xFF123C33),
      'bg': Color(0xFFE8F5F0),
      'route': '/gender-pay-calculator',
    },
    {
      'icon': Icons.map_outlined,
      'title': 'Career Journey Map',
      'desc': 'Track your career milestones',
      'color': Color(0xFF7B2D8B),
      'bg': Color(0xFFF3E8F9),
      'route': '/career-journey-map',
    },
    {
      'icon': Icons.people_outline_rounded,
      'title': 'Career Coach Matching',
      'desc': 'Find your perfect coach',
      'color': Color(0xFF1565C0),
      'bg': Color(0xFFE8F0FE),
      'route': '/career-coach-matching',
    },
    {
      'icon': Icons.star_outline_rounded,
      'title': 'Her Promotion Club',
      'desc': 'Exclusive career community',
      'color': Color(0xFFE65100),
      'bg': Color(0xFFFFF3E0),
      'route': '/her-promotion-club',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: EdgeInsets.fromLTRB(20, 20, 20, bottomPadding + 100),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          buildEntrance(
            index: 0,
            child: Text(
              'YOUR CAREER TOOLS',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: isDark
                    ? const Color(0xFF888888)
                    : const Color(0xFF9E9E9E),
                letterSpacing: 1.0,
              ),
            ),
          ),
          const SizedBox(height: 12),
          ...List.generate(_tools.length, (i) {
            final tool = _tools[i];
            return buildEntrance(
              index: i + 1,
              child: Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: _ToolCard(
                  tool: tool,
                  isDark: isDark,
                  cardColor: cardColor,
                  borderColor: borderColor,
                  titleColor: titleColor,
                  subtitleColor: subtitleColor,
                  onTap: () => context.push(tool['route'] as String),
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}

// ─── Saved Results Tab ────────────────────────────────────────────────────────

class _SavedResultsTab extends StatelessWidget {
  final bool isDark;
  final Color cardColor;
  final Color borderColor;
  final Color titleColor;
  final Color subtitleColor;
  final double bottomPadding;
  final List<Map<String, String>> calculations;
  final void Function(int index) onCalcTap;
  final void Function(int index) onCalcDelete;
  final Widget Function({required int index, required Widget child})
  buildEntrance;

  const _SavedResultsTab({
    required this.isDark,
    required this.cardColor,
    required this.borderColor,
    required this.titleColor,
    required this.subtitleColor,
    required this.bottomPadding,
    required this.calculations,
    required this.onCalcTap,
    required this.onCalcDelete,
    required this.buildEntrance,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: EdgeInsets.fromLTRB(20, 20, 20, bottomPadding + 100),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          buildEntrance(
            index: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'PAY CALCULATIONS',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: isDark
                        ? const Color(0xFF888888)
                        : const Color(0xFF9E9E9E),
                    letterSpacing: 1.0,
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFF0F7),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    '${calculations.length} saved',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: const Color(0xFFE91E8F),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          if (calculations.isEmpty)
            buildEntrance(
              index: 1,
              child: _EmptyState(
                icon: Icons.calculate_outlined,
                title: 'No saved results yet',
                message: 'Start by using the Pay Calculator or taking a quiz!',
                isDark: isDark,
              ),
            )
          else
            ...List.generate(calculations.length, (i) {
              final calc = calculations[i];
              return buildEntrance(
                index: i + 1,
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _SwipeableCalcCard(
                    calc: calc,
                    isDark: isDark,
                    cardColor: cardColor,
                    borderColor: borderColor,
                    titleColor: titleColor,
                    subtitleColor: subtitleColor,
                    onTap: () => onCalcTap(i),
                    onDelete: () => onCalcDelete(i),
                  ),
                ),
              );
            }),
          const SizedBox(height: 20),
          buildEntrance(
            index: calculations.length + 2,
            child: Text(
              'QUIZ RESULTS',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: isDark
                    ? const Color(0xFF888888)
                    : const Color(0xFF9E9E9E),
                letterSpacing: 1.0,
              ),
            ),
          ),
          const SizedBox(height: 12),
          buildEntrance(
            index: calculations.length + 3,
            child: _EmptyState(
              icon: Icons.quiz_outlined,
              title: 'No quiz results yet',
              message:
                  'Take the Career Assessment to get personalized coach recommendations!',
              isDark: isDark,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Coaches Tab ──────────────────────────────────────────────────────────────

class _CoachesTab extends StatelessWidget {
  final bool isDark;
  final Color cardColor;
  final Color borderColor;
  final Color titleColor;
  final Color subtitleColor;
  final double bottomPadding;
  final void Function(Map<String, dynamic>) onCoachTap;
  final Widget Function({required int index, required Widget child})
  buildEntrance;

  const _CoachesTab({
    required this.isDark,
    required this.cardColor,
    required this.borderColor,
    required this.titleColor,
    required this.subtitleColor,
    required this.bottomPadding,
    required this.onCoachTap,
    required this.buildEntrance,
  });

  static const List<Map<String, dynamic>> _coaches = [
    {
      'name': 'Dr. Maria Santos',
      'title': 'Executive Career Coach',
      'specialty': 'Pay Equity & Salary Negotiation',
      'bio':
          'Dr. Santos has 15+ years helping women in tech negotiate their worth. She specializes in pay equity advocacy and executive presence.',
      'date': 'Connected June 18, 2026',
      'initial': 'M',
      'color': Color(0xFFE91E8F),
      'rating': 5,
    },
    {
      'name': 'Priya Nair',
      'title': 'Leadership & Growth Coach',
      'specialty': 'Leadership Development',
      'bio':
          'Priya coaches high-potential women into leadership roles. Her clients have achieved an average 40% salary increase within 12 months.',
      'date': 'Connected June 16, 2026',
      'initial': 'P',
      'color': Color(0xFF123C33),
      'rating': 5,
    },
    {
      'name': 'Tamara Williams',
      'title': 'Career Transition Specialist',
      'specialty': 'Career Pivots & Transitions',
      'bio':
          'Tamara helps professionals navigate career transitions with confidence. She has guided 200+ women into their dream roles.',
      'date': 'Connected June 12, 2026',
      'initial': 'T',
      'color': Color(0xFF7B2D8B),
      'rating': 4,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: EdgeInsets.fromLTRB(20, 20, 20, bottomPadding + 100),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          buildEntrance(
            index: 0,
            child: Text(
              'CONNECTED COACHES',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: isDark
                    ? const Color(0xFF888888)
                    : const Color(0xFF9E9E9E),
                letterSpacing: 1.0,
              ),
            ),
          ),
          const SizedBox(height: 12),
          if (_coaches.isEmpty)
            buildEntrance(
              index: 1,
              child: _EmptyState(
                icon: Icons.people_outline_rounded,
                title: 'No coach connections yet',
                message:
                    "You haven't connected with any coaches yet. Explore our coach matching feature!",
                isDark: isDark,
              ),
            )
          else
            ...List.generate(_coaches.length, (i) {
              final coach = _coaches[i];
              return buildEntrance(
                index: i + 1,
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _CoachCard(
                    coach: coach,
                    isDark: isDark,
                    cardColor: cardColor,
                    borderColor: borderColor,
                    titleColor: titleColor,
                    subtitleColor: subtitleColor,
                    onTap: () => onCoachTap(coach),
                  ),
                ),
              );
            }),
        ],
      ),
    );
  }
}

// ─── Swipeable Calculation Card ───────────────────────────────────────────────

class _SwipeableCalcCard extends StatefulWidget {
  final Map<String, String> calc;
  final bool isDark;
  final Color cardColor;
  final Color borderColor;
  final Color titleColor;
  final Color subtitleColor;
  final VoidCallback onTap;
  final VoidCallback onDelete;

  const _SwipeableCalcCard({
    required this.calc,
    required this.isDark,
    required this.cardColor,
    required this.borderColor,
    required this.titleColor,
    required this.subtitleColor,
    required this.onTap,
    required this.onDelete,
  });

  @override
  State<_SwipeableCalcCard> createState() => _SwipeableCalcCardState();
}

class _SwipeableCalcCardState extends State<_SwipeableCalcCard> {
  bool _showMenu = false;

  @override
  Widget build(BuildContext context) {
    return Dismissible(
      key: ValueKey(widget.calc['title'] ?? ''),
      direction: DismissDirection.endToStart,
      confirmDismiss: (_) async {
        widget.onDelete();
        return false;
      },
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        decoration: BoxDecoration(
          color: const Color(0xFFFF3B30),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.delete_rounded, color: Colors.white, size: 24),
            const SizedBox(height: 4),
            Text(
              'Delete',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
      child: GestureDetector(
        onTap: widget.onTap,
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: widget.cardColor,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: widget.borderColor),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withAlpha(widget.isDark ? 20 : 8),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF0F7),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Icon(
                  Icons.calculate_outlined,
                  color: Color(0xFFE91E8F),
                  size: 24,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.calc['title'] ?? 'Unknown Title',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: widget.titleColor,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        Text(
                          widget.calc['salary'] ?? 'N/A',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: const Color(0xFF123C33),
                          ),
                        ),
                        const SizedBox(width: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 6,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFFF0F7),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            '${widget.calc['gapPct']} gap',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              color: const Color(0xFFE91E8F),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      widget.calc['date'] ?? '',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 11,
                        color: widget.subtitleColor,
                      ),
                    ),
                  ],
                ),
              ),
              // ⋯ menu button
              GestureDetector(
                onTap: () {
                  setState(() => _showMenu = !_showMenu);
                  _showCalcMenu(context);
                },
                child: Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: widget.isDark
                        ? const Color(0xFF3A3A3A)
                        : const Color(0xFFF5F5F5),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    Icons.more_horiz_rounded,
                    size: 18,
                    color: widget.isDark
                        ? const Color(0xFFAAAAAA)
                        : const Color(0xFF757575),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showCalcMenu(BuildContext context) {
    final isDark = widget.isDark;
    showModalBottomSheet(
      context: context,
      backgroundColor: isDark ? const Color(0xFF2D2D2D) : Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: isDark
                    ? const Color(0xFF4A4A4A)
                    : const Color(0xFFE0E0E0),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 16),
            ListTile(
              leading: const Icon(
                Icons.visibility_outlined,
                color: Color(0xFF123C33),
              ),
              title: Text(
                'View Details',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 15,
                  fontWeight: FontWeight.w500,
                  color: isDark
                      ? const Color(0xFFE6E6E6)
                      : const Color(0xFF1A1A1A),
                ),
              ),
              onTap: () {
                Navigator.pop(ctx);
                widget.onTap();
              },
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            ListTile(
              leading: const Icon(
                Icons.delete_outline_rounded,
                color: Color(0xFFFF3B30),
              ),
              title: Text(
                'Delete',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 15,
                  fontWeight: FontWeight.w500,
                  color: const Color(0xFFFF3B30),
                ),
              ),
              onTap: () {
                Navigator.pop(ctx);
                widget.onDelete();
              },
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Reusable Widgets ─────────────────────────────────────────────────────────

class _IconBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _IconBtn({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          color: Colors.black.withAlpha(60),
          shape: BoxShape.circle,
        ),
        child: Icon(icon, color: Colors.white, size: 20),
      ),
    );
  }
}

class _ActionButton extends StatefulWidget {
  final String label;
  final bool isPrimary;
  final VoidCallback onTap;
  const _ActionButton({
    required this.label,
    required this.isPrimary,
    required this.onTap,
  });

  @override
  State<_ActionButton> createState() => _ActionButtonState();
}

class _ActionButtonState extends State<_ActionButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _scaleController;
  late Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();
    _scaleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 100),
    );
    _scaleAnim = Tween<double>(begin: 1.0, end: 0.94).animate(
      CurvedAnimation(parent: _scaleController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _scaleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _scaleController.forward(),
      onTapUp: (_) {
        _scaleController.reverse();
        widget.onTap();
      },
      onTapCancel: () => _scaleController.reverse(),
      child: ScaleTransition(
        scale: _scaleAnim,
        child: Container(
          height: 40,
          decoration: BoxDecoration(
            color: widget.isPrimary
                ? const Color(0xFFE91E8F)
                : Colors.transparent,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: widget.isPrimary
                  ? const Color(0xFFE91E8F)
                  : const Color(0xFF123C33),
              width: 1.5,
            ),
          ),
          child: Center(
            child: Text(
              widget.label,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: widget.isPrimary
                    ? Colors.white
                    : const Color(0xFF123C33),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _MoreBtn extends StatelessWidget {
  final VoidCallback onTap;
  final bool isDark;
  const _MoreBtn({required this.onTap, required this.isDark});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          color: isDark ? const Color(0xFF3A3A3A) : const Color(0xFFF5F5F5),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: isDark ? const Color(0xFF4A4A4A) : const Color(0xFFE0E0E0),
          ),
        ),
        child: Icon(
          Icons.more_horiz_rounded,
          color: isDark ? const Color(0xFFAAAAAA) : const Color(0xFF757575),
          size: 20,
        ),
      ),
    );
  }
}

class _StatItem extends StatelessWidget {
  final String value;
  final String label;
  final bool isDark;
  const _StatItem({
    required this.value,
    required this.label,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        children: [
          Text(
            value,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 20,
              fontWeight: FontWeight.w800,
              color: const Color(0xFFE91E8F),
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 11,
              fontWeight: FontWeight.w500,
              color: isDark ? const Color(0xFF888888) : const Color(0xFF9E9E9E),
            ),
          ),
        ],
      ),
    );
  }
}

class _StatDivider extends StatelessWidget {
  final bool isDark;
  const _StatDivider({required this.isDark});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 1,
      height: 32,
      color: isDark ? const Color(0xFF4A4A4A) : const Color(0xFFE8D5DF),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String title;
  final bool isDark;
  const _SectionLabel({required this.title, required this.isDark});

  @override
  Widget build(BuildContext context) {
    return Text(
      title.toUpperCase(),
      style: GoogleFonts.plusJakartaSans(
        fontSize: 11,
        fontWeight: FontWeight.w700,
        color: isDark ? const Color(0xFF888888) : const Color(0xFF9E9E9E),
        letterSpacing: 1.0,
      ),
    );
  }
}

class _MenuGroup extends StatelessWidget {
  final List<_MenuItem> items;
  final bool isDark;
  final Color cardColor;
  final Color borderColor;

  const _MenuGroup({
    required this.items,
    required this.isDark,
    required this.cardColor,
    required this.borderColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(isDark ? 20 : 8),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: List.generate(items.length, (i) {
          final item = items[i];
          final isLast = i == items.length - 1;
          return Column(
            children: [
              item,
              if (!isLast)
                Divider(
                  height: 1,
                  thickness: 1,
                  color: isDark
                      ? const Color(0xFF3A3A3A)
                      : const Color(0xFFF5F0F3),
                  indent: 58,
                ),
            ],
          );
        }),
      ),
    );
  }
}

class _MenuItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color iconColor;
  final Color iconBg;
  final Color? labelColor;
  final bool showArrow;
  final bool isDark;
  final VoidCallback onTap;

  const _MenuItem({
    required this.icon,
    required this.label,
    required this.iconColor,
    required this.iconBg,
    required this.isDark,
    this.labelColor,
    this.showArrow = true,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: iconBg,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: iconColor, size: 18),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                label,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 15,
                  fontWeight: FontWeight.w500,
                  color:
                      labelColor ??
                      (isDark
                          ? const Color(0xFFE6E6E6)
                          : const Color(0xFF1A1A1A)),
                ),
              ),
            ),
            if (showArrow)
              Icon(
                Icons.chevron_right_rounded,
                size: 20,
                color: isDark
                    ? const Color(0xFF666666)
                    : const Color(0xFFBDBDBD),
              ),
          ],
        ),
      ),
    );
  }
}

class _ToolCard extends StatefulWidget {
  final Map<String, dynamic> tool;
  final bool isDark;
  final Color cardColor;
  final Color borderColor;
  final Color titleColor;
  final Color subtitleColor;
  final VoidCallback onTap;

  const _ToolCard({
    required this.tool,
    required this.isDark,
    required this.cardColor,
    required this.borderColor,
    required this.titleColor,
    required this.subtitleColor,
    required this.onTap,
  });

  @override
  State<_ToolCard> createState() => _ToolCardState();
}

class _ToolCardState extends State<_ToolCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _scaleController;
  late Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();
    _scaleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 100),
    );
    _scaleAnim = Tween<double>(begin: 1.0, end: 0.97).animate(
      CurvedAnimation(parent: _scaleController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _scaleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final tool = widget.tool;
    return GestureDetector(
      onTapDown: (_) => _scaleController.forward(),
      onTapUp: (_) {
        _scaleController.reverse();
        widget.onTap();
      },
      onTapCancel: () => _scaleController.reverse(),
      child: ScaleTransition(
        scale: _scaleAnim,
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: widget.cardColor,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: widget.borderColor),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withAlpha(widget.isDark ? 20 : 8),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: tool['bg'] as Color,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(
                  tool['icon'] as IconData,
                  color: tool['color'] as Color,
                  size: 24,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      tool['title'] as String,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: widget.titleColor,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      tool['desc'] as String,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 12,
                        color: widget.subtitleColor,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.arrow_forward_ios_rounded,
                size: 16,
                color: widget.isDark
                    ? const Color(0xFF666666)
                    : const Color(0xFFBDBDBD),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CoachCard extends StatelessWidget {
  final Map<String, dynamic> coach;
  final bool isDark;
  final Color cardColor;
  final Color borderColor;
  final Color titleColor;
  final Color subtitleColor;
  final VoidCallback onTap;

  const _CoachCard({
    required this.coach,
    required this.isDark,
    required this.cardColor,
    required this.borderColor,
    required this.titleColor,
    required this.subtitleColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final color = coach['color'] as Color;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: borderColor),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withAlpha(isDark ? 20 : 8),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: color.withAlpha(40),
                shape: BoxShape.circle,
                border: Border.all(color: color.withAlpha(80), width: 1.5),
              ),
              child: Center(
                child: Text(
                  coach['initial'] as String,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: color,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    coach['name'] as String,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: titleColor,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    coach['title'] as String,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 12,
                      color: subtitleColor,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: List.generate(
                      5,
                      (i) => Icon(
                        i < (coach['rating'] as int)
                            ? Icons.star_rounded
                            : Icons.star_outline_rounded,
                        color: const Color(0xFFE91E8F),
                        size: 14,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const Icon(
              Icons.chevron_right_rounded,
              size: 20,
              color: Color(0xFFBDBDBD),
            ),
          ],
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String message;
  final bool isDark;

  const _EmptyState({
    required this.icon,
    required this.title,
    required this.message,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(32),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF2D2D2D) : Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isDark ? const Color(0xFF4A4A4A) : const Color(0xFFE8D5DF),
        ),
      ),
      child: Column(
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: const BoxDecoration(
              color: Color(0xFFFFF0F7),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: const Color(0xFFE91E8F), size: 30),
          ),
          const SizedBox(height: 16),
          Text(
            title,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: isDark ? const Color(0xFFE6E6E6) : const Color(0xFF1A1A1A),
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 8),
          Text(
            message,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 13,
              color: isDark ? const Color(0xFFAAAAAA) : const Color(0xFF757575),
              height: 1.5,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final String label;
  final String value;
  final bool isDark;
  final Color? valueColor;

  const _DetailRow({
    required this.label,
    required this.value,
    required this.isDark,
    this.valueColor,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 13,
              color: isDark ? const Color(0xFFAAAAAA) : const Color(0xFF757575),
            ),
          ),
          Text(
            value,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color:
                  valueColor ??
                  (isDark ? const Color(0xFFE6E6E6) : const Color(0xFF1A1A1A)),
            ),
          ),
        ],
      ),
    );
  }
}

class _SalaryBarChart extends StatelessWidget {
  final double yourSalary;
  final double marketSalary;
  final bool isDark;

  const _SalaryBarChart({
    required this.yourSalary,
    required this.marketSalary,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    final maxVal = marketSalary > yourSalary ? marketSalary : yourSalary;
    final yourRatio = yourSalary / maxVal;
    final marketRatio = marketSalary / maxVal;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF3A3A3A) : const Color(0xFFFAFAFA),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        children: [
          _Bar(
            label: 'Your Salary',
            value: '\$${yourSalary.toStringAsFixed(0)}',
            ratio: yourRatio,
            color: const Color(0xFF123C33),
            isDark: isDark,
          ),
          const SizedBox(height: 12),
          _Bar(
            label: 'Market Salary',
            value: '\$${marketSalary.toStringAsFixed(0)}',
            ratio: marketRatio,
            color: const Color(0xFFE91E8F),
            isDark: isDark,
          ),
        ],
      ),
    );
  }
}

class _Bar extends StatelessWidget {
  final String label;
  final String value;
  final double ratio;
  final Color color;
  final bool isDark;

  const _Bar({
    required this.label,
    required this.value,
    required this.ratio,
    required this.color,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              label,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 12,
                color: isDark
                    ? const Color(0xFFAAAAAA)
                    : const Color(0xFF757575),
              ),
            ),
            Text(
              value,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: color,
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        LayoutBuilder(
          builder: (context, constraints) {
            return Stack(
              children: [
                Container(
                  height: 10,
                  width: constraints.maxWidth,
                  decoration: BoxDecoration(
                    color: isDark
                        ? const Color(0xFF4A4A4A)
                        : const Color(0xFFE8D5DF),
                    borderRadius: BorderRadius.circular(5),
                  ),
                ),
                Container(
                  height: 10,
                  width: constraints.maxWidth * ratio,
                  decoration: BoxDecoration(
                    color: color,
                    borderRadius: BorderRadius.circular(5),
                  ),
                ),
              ],
            );
          },
        ),
      ],
    );
  }
}

class _MoreOptionTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isDark;
  final VoidCallback onTap;

  const _MoreOptionTile({
    required this.icon,
    required this.label,
    required this.isDark,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(
        icon,
        color: isDark ? const Color(0xFFE6E6E6) : const Color(0xFF1A1A1A),
      ),
      title: Text(
        label,
        style: GoogleFonts.plusJakartaSans(
          fontSize: 15,
          color: isDark ? const Color(0xFFE6E6E6) : const Color(0xFF1A1A1A),
        ),
      ),
      onTap: onTap,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    );
  }
}
