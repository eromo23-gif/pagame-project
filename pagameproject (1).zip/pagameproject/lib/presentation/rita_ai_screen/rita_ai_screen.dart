import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';

import '../../core/app_state.dart';

// ─── Data Models ────────────────────────────────────────────────────────────

class _Personality {
  final String id;
  final String name;
  final String tagline;
  final IconData icon;
  final Color color;
  final Color bgColor;
  final String intro;
  final List<String> prompts;
  final String placeholderResponse;

  const _Personality({
    required this.id,
    required this.name,
    required this.tagline,
    required this.icon,
    required this.color,
    required this.bgColor,
    required this.intro,
    required this.prompts,
    required this.placeholderResponse,
  });
}

const List<_Personality> _personalities = [
  _Personality(
    id: 'career_bestfriend',
    name: 'Career Best Friend',
    tagline: 'Your supportive sounding board',
    icon: Icons.favorite_rounded,
    color: Color(0xFFE91E8F),
    bgColor: Color(0xFFFFF0F7),
    intro:
        'Hey! I\'m your Career Best Friend 💕 Think of me as that friend who always has your back — honest, warm, and totally in your corner. What\'s on your mind today?',
    prompts: [
      'I feel stuck in my career — what should I do?',
      'How do I deal with a difficult coworker?',
      'I\'m scared to ask for a raise. Help!',
    ],
    placeholderResponse:
        'I hear you, and honestly? You\'re doing better than you think. Let\'s break this down together — one step at a time. You\'ve got this! 💪',
  ),
  _Personality(
    id: 'executive_coach',
    name: 'Executive Coach',
    tagline: 'Strategic leadership guidance',
    icon: Icons.business_center_rounded,
    color: Color(0xFF123C33),
    bgColor: Color(0xFFE8F5F0),
    intro:
        'Welcome. I\'m your Executive Coach — here to help you think strategically, lead with confidence, and make high-impact decisions. What challenge are you navigating?',
    prompts: [
      'How do I build executive presence?',
      'I want to transition into leadership — where do I start?',
      'How do I manage up effectively?',
    ],
    placeholderResponse:
        'That\'s a strategic question worth unpacking carefully. The most effective leaders I\'ve worked with approach this by first clarifying their core value proposition. Let\'s map out your next move.',
  ),
  _Personality(
    id: 'motivator',
    name: 'Motivator',
    tagline: 'Fuel your ambition daily',
    icon: Icons.bolt_rounded,
    color: Color(0xFFFF6B35),
    bgColor: Color(0xFFFFF3EE),
    intro:
        'Let\'s GO! ⚡ I\'m your Motivator — here to light a fire under your ambitions and keep you moving forward. No more playing small. What goal are we crushing today?',
    prompts: [
      'I\'ve been procrastinating on a big goal. Push me!',
      'How do I stay motivated when things get hard?',
      'I need a confidence boost before a big meeting.',
    ],
    placeholderResponse:
        'YES! That energy right there — that\'s exactly what you need to channel. You didn\'t come this far to only come this far. Here\'s what I want you to do RIGHT NOW: take one bold action today. What will it be? ⚡',
  ),
  _Personality(
    id: 'salary_strategist',
    name: 'Salary Strategist',
    tagline: 'Maximize your earning power',
    icon: Icons.trending_up_rounded,
    color: Color(0xFF7B2D8B),
    bgColor: Color(0xFFF5E8FF),
    intro:
        'Hi! I\'m your Salary Strategist 💰 I specialize in helping women close the pay gap and negotiate what they\'re truly worth. Let\'s talk numbers — what\'s your situation?',
    prompts: [
      'How do I research my market salary?',
      'What\'s the best way to negotiate a raise?',
      'I got a job offer — how do I counter?',
    ],
    placeholderResponse:
        'Great question — and you\'re right to think strategically about this. Based on typical market data, women who negotiate proactively earn 7–15% more over their careers. Here\'s a framework to approach your next conversation with confidence.',
  ),
  _Personality(
    id: 'interview_mentor',
    name: 'Interview Mentor',
    tagline: 'Land the role you deserve',
    icon: Icons.record_voice_over_rounded,
    color: Color(0xFF1565C0),
    bgColor: Color(0xFFE8F0FF),
    intro:
        'Hello! I\'m your Interview Mentor 🎯 I\'ll help you walk into any interview room prepared, polished, and powerful. What are we preparing for today?',
    prompts: [
      'How do I answer "Tell me about yourself"?',
      'I have a tough interview tomorrow — help me prep!',
      'What questions should I ask the interviewer?',
    ],
    placeholderResponse:
        'Perfect — let\'s make sure you\'re fully prepared. The key to a great interview is telling a compelling story that connects your experience to what they need. Let me walk you through a proven structure that works every time.',
  ),
];

// ─── Message Model ───────────────────────────────────────────────────────────

class _Message {
  final String text;
  final bool isUser;
  _Message({required this.text, required this.isUser});
}

// ─── Main Screen ─────────────────────────────────────────────────────────────

class RitaAiScreen extends StatefulWidget {
  const RitaAiScreen({super.key});

  @override
  State<RitaAiScreen> createState() => _RitaAiScreenState();
}

class _RitaAiScreenState extends State<RitaAiScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _entranceController;
  _Personality? _activePersonality;
  Map<String, dynamic>? _payGapContext;
  String? _payGapInitialMessage;

  @override
  void initState() {
    super.initState();
    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    // Check for pay gap context from calculator
    final ctx = AppState.instance.payGapContext;
    if (ctx != null) {
      _payGapContext = ctx;
      _payGapInitialMessage = _buildPayGapMessage(ctx);
      AppState.instance.clearPayGapContext();
      // Auto-open Salary Strategist
      WidgetsBinding.instance.addPostFrameCallback((_) {
        final strategist = _personalities.firstWhere(
          (p) => p.id == 'salary_strategist',
        );
        setState(() => _activePersonality = strategist);
      });
    } else {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _entranceController.forward();
      });
    }
  }

  String _buildPayGapMessage(Map<String, dynamic> ctx) {
    final industry = ctx['industry'] ?? '';
    final jobTitle = ctx['jobTitle'] ?? '';
    final experience = ctx['experience'] ?? '';
    final education = ctx['education'] ?? '';
    final state = ctx['state'] ?? '';
    final currentSalary = ctx['currentSalary'] ?? 0;
    final estimatedMarket = ctx['estimatedMarketSalary'] ?? 0;
    final payGap = ctx['payGap'] ?? 0;

    final gapStr = payGap > 0
        ? 'I\'m earning \$${_fmt(payGap)} below the estimated market rate'
        : 'I\'m earning at or above the estimated market rate';

    return 'Hi Rita! I just used the Pay Gap Calculator and here are my results:\n\n'
        '• Industry: $industry\n'
        '• Job Title: $jobTitle\n'
        '• Experience: $experience\n'
        '• Education: $education\n'
        '• State: $state\n'
        '• Current Salary: \$${_fmt(currentSalary)}\n'
        '• Estimated Market Salary: \$${_fmt(estimatedMarket)}\n\n'
        '$gapStr. Can you help me understand what this means and what I should do next?';
  }

  String _fmt(dynamic value) {
    final n = (value is int) ? value : (value as num).toInt();
    final s = n.abs().toString();
    final buffer = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buffer.write(',');
      buffer.write(s[i]);
    }
    return buffer.toString();
  }

  @override
  void dispose() {
    _entranceController.dispose();
    super.dispose();
  }

  Widget _buildEntrance({required int index, required Widget child}) {
    final delay = (index * 0.1).clamp(0.0, 0.7);
    final end = (delay + 0.4).clamp(0.0, 1.0);
    final fade = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _entranceController,
        curve: Interval(delay, end, curve: Curves.easeOut),
      ),
    );
    final slide = Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero)
        .animate(
          CurvedAnimation(
            parent: _entranceController,
            curve: Interval(delay, end, curve: Curves.easeOutCubic),
          ),
        );
    return FadeTransition(
      opacity: fade,
      child: SlideTransition(position: slide, child: child),
    );
  }

  void _openPersonality(_Personality p) {
    setState(() => _activePersonality = p);
  }

  void _closePersonality() {
    setState(() {
      _activePersonality = null;
      _payGapContext = null;
      _payGapInitialMessage = null;
    });
    _entranceController.forward(from: 0);
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF1A1A1A) : const Color(0xFFFAFAFA);

    return Scaffold(
      backgroundColor: bgColor,
      body: AnimatedSwitcher(
        duration: const Duration(milliseconds: 300),
        transitionBuilder: (child, animation) {
          return FadeTransition(opacity: animation, child: child);
        },
        child: _activePersonality != null
            ? _ConversationView(
                key: ValueKey(_activePersonality!.id),
                personality: _activePersonality!,
                isDark: isDark,
                onBack: _closePersonality,
                onEnd: _closePersonality,
                initialUserMessage: _payGapInitialMessage,
              )
            : _PersonalityListView(
                key: const ValueKey('personality_list'),
                isDark: isDark,
                buildEntrance: _buildEntrance,
                onPersonalityTap: _openPersonality,
                onNavigate: (route) => context.push(route),
              ),
      ),
    );
  }
}

// ─── Personality List View ────────────────────────────────────────────────────

class _PersonalityListView extends StatelessWidget {
  final bool isDark;
  final Widget Function({required int index, required Widget child})
  buildEntrance;
  final void Function(_Personality) onPersonalityTap;
  final void Function(String) onNavigate;

  const _PersonalityListView({
    super.key,
    required this.isDark,
    required this.buildEntrance,
    required this.onPersonalityTap,
    required this.onNavigate,
  });

  @override
  Widget build(BuildContext context) {
    final bottomPadding = MediaQuery.of(context).padding.bottom;
    final titleColor = isDark
        ? const Color(0xFFE6E6E6)
        : const Color(0xFF123C33);
    final subtitleColor = isDark
        ? const Color(0xFFAAAAAA)
        : const Color(0xFF9E9E9E);

    return CustomScrollView(
      physics: const BouncingScrollPhysics(),
      slivers: [
        SliverAppBar(
          expandedHeight: 160,
          pinned: true,
          elevation: 0,
          scrolledUnderElevation: 0,
          automaticallyImplyLeading: false,
          flexibleSpace: FlexibleSpaceBar(
            background: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF123C33), Color(0xFF1A5C48)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: SafeArea(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: const Color(0xFFE91E8F).withAlpha(51),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                color: const Color(0xFFE91E8F).withAlpha(102),
                              ),
                            ),
                            child: Text(
                              'AI-Powered',
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                color: const Color(0xFFFFB3D9),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'RITA AI',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 28,
                          fontWeight: FontWeight.w800,
                          color: Colors.white,
                          letterSpacing: -0.5,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Where Human Intelligence Meets AI to Advance Women\'s Careers.',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 13,
                          fontWeight: FontWeight.w400,
                          color: Colors.white.withAlpha(204),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          backgroundColor: const Color(0xFF123C33),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Intro card
                buildEntrance(
                  index: 0,
                  child: Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: isDark
                          ? const Color(0xFF3A2030)
                          : const Color(0xFFFFF0F7),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: const Color(0xFFE91E8F).withAlpha(38),
                      ),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: const Color(0xFFE91E8F).withAlpha(31),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(
                            Icons.auto_awesome_rounded,
                            color: Color(0xFFE91E8F),
                            size: 20,
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Text(
                            'RITA AI combines generative AI with human expertise to deliver personalized career coaching, pay transparency tools, and growth pathways — all designed for women.',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 13,
                              fontWeight: FontWeight.w400,
                              color: isDark
                                  ? const Color(0xFFCCCCCC)
                                  : const Color(0xFF123C33),
                              height: 1.5,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 28),

                // ── Agent Rita Section ──────────────────────────────────────
                buildEntrance(
                  index: 1,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 36,
                            height: 36,
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [Color(0xFFE91E8F), Color(0xFF7B2D8B)],
                              ),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: const Icon(
                              Icons.smart_toy_rounded,
                              color: Colors.white,
                              size: 18,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Agent Rita',
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w700,
                                  color: titleColor,
                                ),
                              ),
                              Text(
                                'Choose a coaching personality to begin',
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 12,
                                  color: subtitleColor,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // Personality cards
                ...List.generate(_personalities.length, (i) {
                  final p = _personalities[i];
                  return buildEntrance(
                    index: i + 2,
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: _PersonalityCard(
                        personality: p,
                        isDark: isDark,
                        onTap: () => onPersonalityTap(p),
                      ),
                    ),
                  );
                }),

                const SizedBox(height: 28),

                // ── Career Tools Section ────────────────────────────────────
                buildEntrance(
                  index: 8,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Career Tools',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          color: titleColor,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Explore our AI-powered tools built for your growth',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 13,
                          color: subtitleColor,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                buildEntrance(
                  index: 9,
                  child: _ToolCard(
                    icon: Icons.calculate_outlined,
                    iconColor: const Color(0xFFE91E8F),
                    iconBg: const Color(0xFFFFF0F7),
                    title: 'Gender Pay Calculator',
                    description:
                        'Estimate potential pay gaps and gain transparency to negotiate effectively.',
                    isDark: isDark,
                    onTap: () => onNavigate('/gender-pay-calculator'),
                  ),
                ),
                const SizedBox(height: 12),
                buildEntrance(
                  index: 10,
                  child: _ToolCard(
                    icon: Icons.people_alt_outlined,
                    iconColor: const Color(0xFF123C33),
                    iconBg: const Color(0xFFE8F5F0),
                    title: 'Career Coach Matching',
                    description:
                        'AI-powered matching with qualified human career coaches for 1:1 sessions.',
                    isDark: isDark,
                    onTap: () => onNavigate('/career-coach-matching'),
                  ),
                ),
                const SizedBox(height: 12),
                buildEntrance(
                  index: 11,
                  child: _ToolCard(
                    icon: Icons.map_outlined,
                    iconColor: const Color(0xFFE91E8F),
                    iconBg: const Color(0xFFFFF0F7),
                    title: 'Career Journey Map',
                    description:
                        'Visualize your career path step by step with key milestones and goals.',
                    isDark: isDark,
                    onTap: () => onNavigate('/career-journey-map'),
                  ),
                ),
                const SizedBox(height: 32),

                // Why Use RITA AI
                buildEntrance(
                  index: 12,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: const Color(0xFF123C33),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFF123C33).withAlpha(60),
                          blurRadius: 20,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Why Use RITA AI?',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 17,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(height: 16),
                        ...[
                          (
                            '✦',
                            'Personalized support tailored to your career goals',
                          ),
                          ('✦', 'Career growth insights powered by real data'),
                          (
                            '✦',
                            'Pay transparency awareness and negotiation tools',
                          ),
                          (
                            '✦',
                            'Human + AI career guidance for holistic support',
                          ),
                        ].map(
                          (item) => Padding(
                            padding: const EdgeInsets.only(bottom: 12),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  item.$1,
                                  style: const TextStyle(
                                    fontSize: 12,
                                    color: Color(0xFFE91E8F),
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                    item.$2,
                                    style: GoogleFonts.plusJakartaSans(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w400,
                                      color: Colors.white.withAlpha(217),
                                      height: 1.4,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: bottomPadding + 90),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

// ─── Personality Card ─────────────────────────────────────────────────────────

class _PersonalityCard extends StatefulWidget {
  final _Personality personality;
  final bool isDark;
  final VoidCallback onTap;

  const _PersonalityCard({
    required this.personality,
    required this.isDark,
    required this.onTap,
  });

  @override
  State<_PersonalityCard> createState() => _PersonalityCardState();
}

class _PersonalityCardState extends State<_PersonalityCard> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final p = widget.personality;
    final cardColor = widget.isDark ? const Color(0xFF2D2D2D) : Colors.white;
    final borderColor = widget.isDark
        ? const Color(0xFF4A4A4A)
        : p.color.withAlpha(40);

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: borderColor, width: 1.5),
            boxShadow: [
              BoxShadow(
                color: p.color.withAlpha(widget.isDark ? 15 : 12),
                blurRadius: 16,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: widget.isDark ? p.color.withAlpha(40) : p.bgColor,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(p.icon, color: p.color, size: 26),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      p.name,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: widget.isDark
                            ? const Color(0xFFE6E6E6)
                            : const Color(0xFF1A1A1A),
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      p.tagline,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 12,
                        color: widget.isDark
                            ? const Color(0xFFAAAAAA)
                            : const Color(0xFF757575),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 7,
                ),
                decoration: BoxDecoration(
                  color: p.color,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  'Chat',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Conversation View ────────────────────────────────────────────────────────

class _ConversationView extends StatefulWidget {
  final _Personality personality;
  final bool isDark;
  final VoidCallback onBack;
  final VoidCallback onEnd;
  final String? initialUserMessage;

  const _ConversationView({
    super.key,
    required this.personality,
    required this.isDark,
    required this.onBack,
    required this.onEnd,
    this.initialUserMessage,
  });

  @override
  State<_ConversationView> createState() => _ConversationViewState();
}

class _ConversationViewState extends State<_ConversationView> {
  final TextEditingController _inputController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final List<_Message> _messages = [];
  bool _isTyping = false;

  @override
  void initState() {
    super.initState();
    // Add intro message
    _messages.add(_Message(text: widget.personality.intro, isUser: false));
    // If coming from Pay Gap Calculator, auto-send the context message
    if (widget.initialUserMessage != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _sendMessage(widget.initialUserMessage!);
      });
    }
  }

  @override
  void dispose() {
    _inputController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _sendMessage(String text) {
    final trimmed = text.trim();
    if (trimmed.isEmpty) return;

    setState(() {
      _messages.add(_Message(text: trimmed, isUser: true));
      _isTyping = true;
    });
    _inputController.clear();
    _scrollToBottom();

    // Simulate a short delay then show placeholder response
    Future.delayed(const Duration(milliseconds: 900), () {
      if (!mounted) return;
      setState(() {
        _isTyping = false;
        _messages.add(
          _Message(text: widget.personality.placeholderResponse, isUser: false),
        );
      });
      _scrollToBottom();
    });
  }

  void _showEndDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        backgroundColor: widget.isDark ? const Color(0xFF2D2D2D) : Colors.white,
        title: Text(
          'End Conversation?',
          style: GoogleFonts.plusJakartaSans(
            fontWeight: FontWeight.w700,
            color: widget.isDark ? Colors.white : const Color(0xFF1A1A1A),
          ),
        ),
        content: Text(
          'Your conversation with ${widget.personality.name} will end. You can start a new one anytime.',
          style: GoogleFonts.plusJakartaSans(
            fontSize: 13,
            color: widget.isDark
                ? const Color(0xFFAAAAAA)
                : const Color(0xFF757575),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(
              'Cancel',
              style: GoogleFonts.plusJakartaSans(
                color: widget.isDark
                    ? const Color(0xFFAAAAAA)
                    : const Color(0xFF757575),
              ),
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              widget.onEnd();
            },
            child: Text(
              'End',
              style: GoogleFonts.plusJakartaSans(
                color: const Color(0xFFE91E8F),
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.personality;
    final isDark = widget.isDark;
    final bgColor = isDark ? const Color(0xFF1A1A1A) : const Color(0xFFFAFAFA);
    final bottomPadding = MediaQuery.of(context).padding.bottom;

    return Column(
      children: [
        // ── Header ──────────────────────────────────────────────────────────
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                p.color.withAlpha(isDark ? 200 : 230),
                p.color.withAlpha(isDark ? 160 : 190),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: SafeArea(
            bottom: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
              child: Column(
                children: [
                  Row(
                    children: [
                      GestureDetector(
                        onTap: widget.onBack,
                        child: Container(
                          width: 36,
                          height: 36,
                          decoration: BoxDecoration(
                            color: Colors.white.withAlpha(40),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Icon(
                            Icons.arrow_back_ios_new_rounded,
                            color: Colors.white,
                            size: 16,
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: Colors.white.withAlpha(40),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(p.icon, color: Colors.white, size: 20),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              p.name,
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                                color: Colors.white,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                            Text(
                              p.tagline,
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 11,
                                color: Colors.white.withAlpha(200),
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      GestureDetector(
                        onTap: _showEndDialog,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 7,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white.withAlpha(40),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: Colors.white.withAlpha(80),
                            ),
                          ),
                          child: Text(
                            'End',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),

        // ── Suggested Prompts ────────────────────────────────────────────────
        Container(
          color: isDark ? const Color(0xFF242424) : Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: SizedBox(
            height: 36,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: p.prompts.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, i) {
                return GestureDetector(
                  onTap: () => _sendMessage(p.prompts[i]),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: isDark ? p.color.withAlpha(40) : p.bgColor,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: p.color.withAlpha(60)),
                    ),
                    child: Text(
                      p.prompts[i],
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                        color: isDark ? p.color.withAlpha(220) : p.color,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                );
              },
            ),
          ),
        ),

        // ── Transcript ───────────────────────────────────────────────────────
        Expanded(
          child: Container(
            color: bgColor,
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
              itemCount: _messages.length + (_isTyping ? 1 : 0),
              itemBuilder: (context, index) {
                if (_isTyping && index == _messages.length) {
                  return _TypingBubble(color: p.color, isDark: isDark);
                }
                final msg = _messages[index];
                return _MessageBubble(
                  message: msg,
                  personality: p,
                  isDark: isDark,
                );
              },
            ),
          ),
        ),

        // ── Input Bar ────────────────────────────────────────────────────────
        Container(
          color: isDark ? const Color(0xFF242424) : Colors.white,
          padding: EdgeInsets.fromLTRB(16, 12, 16, 12 + bottomPadding),
          child: Row(
            children: [
              // Visual mic button (no functionality)
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: isDark ? p.color.withAlpha(40) : p.bgColor,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: p.color.withAlpha(60)),
                ),
                child: Icon(Icons.mic_rounded, color: p.color, size: 22),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: isDark
                        ? const Color(0xFF2D2D2D)
                        : const Color(0xFFF5F5F5),
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(
                      color: isDark
                          ? const Color(0xFF4A4A4A)
                          : const Color(0xFFE0E0E0),
                    ),
                  ),
                  child: TextField(
                    controller: _inputController,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 14,
                      color: isDark ? Colors.white : const Color(0xFF1A1A1A),
                    ),
                    decoration: InputDecoration(
                      hintText: 'Type a message...',
                      hintStyle: GoogleFonts.plusJakartaSans(
                        fontSize: 14,
                        color: isDark
                            ? const Color(0xFF888888)
                            : const Color(0xFFAAAAAA),
                      ),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                    ),
                    onSubmitted: _sendMessage,
                    textInputAction: TextInputAction.send,
                    maxLines: 3,
                    minLines: 1,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              GestureDetector(
                onTap: () => _sendMessage(_inputController.text),
                child: Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: p.color,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: const Icon(
                    Icons.send_rounded,
                    color: Colors.white,
                    size: 20,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ─── Message Bubble ───────────────────────────────────────────────────────────

class _MessageBubble extends StatelessWidget {
  final _Message message;
  final _Personality personality;
  final bool isDark;

  const _MessageBubble({
    required this.message,
    required this.personality,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    final isUser = message.isUser;
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        mainAxisAlignment: isUser
            ? MainAxisAlignment.end
            : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!isUser) ...[
            Container(
              width: 30,
              height: 30,
              decoration: BoxDecoration(
                color: isDark
                    ? personality.color.withAlpha(40)
                    : personality.bgColor,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(personality.icon, color: personality.color, size: 15),
            ),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: isUser
                    ? personality.color
                    : (isDark ? const Color(0xFF2D2D2D) : Colors.white),
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(16),
                  topRight: const Radius.circular(16),
                  bottomLeft: Radius.circular(isUser ? 16 : 4),
                  bottomRight: Radius.circular(isUser ? 4 : 16),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withAlpha(isDark ? 20 : 8),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Text(
                message.text,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 14,
                  color: isUser
                      ? Colors.white
                      : (isDark
                            ? const Color(0xFFE6E6E6)
                            : const Color(0xFF1A1A1A)),
                  height: 1.45,
                ),
              ),
            ),
          ),
          if (isUser) const SizedBox(width: 8),
        ],
      ),
    );
  }
}

// ─── Typing Bubble ────────────────────────────────────────────────────────────

class _TypingBubble extends StatefulWidget {
  final Color color;
  final bool isDark;

  const _TypingBubble({required this.color, required this.isDark});

  @override
  State<_TypingBubble> createState() => _TypingBubbleState();
}

class _TypingBubbleState extends State<_TypingBubble>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: widget.isDark ? const Color(0xFF2D2D2D) : Colors.white,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(16),
                topRight: Radius.circular(16),
                bottomLeft: Radius.circular(4),
                bottomRight: Radius.circular(16),
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withAlpha(widget.isDark ? 20 : 8),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: AnimatedBuilder(
              animation: _controller,
              builder: (context, _) {
                return Row(
                  mainAxisSize: MainAxisSize.min,
                  children: List.generate(3, (i) {
                    final offset = ((_controller.value * 3) - i).clamp(
                      0.0,
                      1.0,
                    );
                    final bounce = (offset < 0.5 ? offset : 1.0 - offset) * 2;
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 2),
                      child: Transform.translate(
                        offset: Offset(0, -4 * bounce),
                        child: Container(
                          width: 7,
                          height: 7,
                          decoration: BoxDecoration(
                            color: widget.color.withAlpha(180),
                            shape: BoxShape.circle,
                          ),
                        ),
                      ),
                    );
                  }),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Tool Card ────────────────────────────────────────────────────────────────

class _ToolCard extends StatefulWidget {
  final IconData icon;
  final Color iconColor;
  final Color iconBg;
  final String title;
  final String description;
  final bool isDark;
  final VoidCallback onTap;

  const _ToolCard({
    required this.icon,
    required this.iconColor,
    required this.iconBg,
    required this.title,
    required this.description,
    required this.isDark,
    required this.onTap,
  });

  @override
  State<_ToolCard> createState() => _ToolCardState();
}

class _ToolCardState extends State<_ToolCard> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final cardColor = widget.isDark ? const Color(0xFF2D2D2D) : Colors.white;
    final borderColor = widget.isDark
        ? const Color(0xFF4A4A4A)
        : const Color(0xFFE8D5DF);
    final titleColor = widget.isDark
        ? const Color(0xFFE6E6E6)
        : const Color(0xFF1A1A1A);
    final descColor = widget.isDark
        ? const Color(0xFFAAAAAA)
        : const Color(0xFF757575);

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: borderColor),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withAlpha(widget.isDark ? 20 : 10),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: widget.iconBg,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(widget.icon, color: widget.iconColor, size: 24),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.title,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: titleColor,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      widget.description,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 12,
                        fontWeight: FontWeight.w400,
                        color: descColor,
                        height: 1.4,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF0F7),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.arrow_forward_ios_rounded,
                  size: 14,
                  color: Color(0xFFE91E8F),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
