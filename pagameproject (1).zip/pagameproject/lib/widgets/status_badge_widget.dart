import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

enum BadgeStatus { active, pending, completed, warning, info }

class StatusBadgeWidget extends StatelessWidget {
  final String label;
  final BadgeStatus status;

  const StatusBadgeWidget({
    super.key,
    required this.label,
    required this.status,
  });

  Color get _backgroundColor {
    switch (status) {
      case BadgeStatus.active:
        return const Color(0xFFE91E8F).withAlpha(31);
      case BadgeStatus.pending:
        return const Color(0xFFB45309).withAlpha(31);
      case BadgeStatus.completed:
        return const Color(0xFF2D7A4F).withAlpha(31);
      case BadgeStatus.warning:
        return const Color(0xFFB91C1C).withAlpha(26);
      case BadgeStatus.info:
        return const Color(0xFF123C33).withAlpha(26);
    }
  }

  Color get _textColor {
    switch (status) {
      case BadgeStatus.active:
        return const Color(0xFFE91E8F);
      case BadgeStatus.pending:
        return const Color(0xFFB45309);
      case BadgeStatus.completed:
        return const Color(0xFF2D7A4F);
      case BadgeStatus.warning:
        return const Color(0xFFB91C1C);
      case BadgeStatus.info:
        return const Color(0xFF123C33);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: _backgroundColor,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        label,
        style: GoogleFonts.plusJakartaSans(
          fontSize: 11,
          fontWeight: FontWeight.w600,
          color: _textColor,
          letterSpacing: 0.2,
        ),
      ),
    );
  }
}
