import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import './app_navigation.dart';
import '../core/app_state.dart';

class AppScaffold extends StatefulWidget {
  final StatefulNavigationShell navigationShell;

  const AppScaffold({required this.navigationShell, super.key});

  @override
  State<AppScaffold> createState() => _AppScaffoldState();
}

class _AppScaffoldState extends State<AppScaffold> {
  final AppState _appState = AppState();

  @override
  void initState() {
    super.initState();
    _appState.addListener(_onStateChanged);
  }

  void _onStateChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _appState.removeListener(_onStateChanged);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = _appState.isDarkMode;
    return Scaffold(
      extendBody: true,
      backgroundColor: isDark
          ? const Color(0xFF1A1A1A)
          : const Color(0xFFFAFAFA),
      body: widget.navigationShell,
      bottomNavigationBar: AppNavigation(
        navigationShell: widget.navigationShell,
      ),
    );
  }
}
