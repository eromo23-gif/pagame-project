import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';

// V2 — Floating Pill Bottom Navigation
// Detached pill bar floats above content with shadow and rounded corners

class _TabSpec {
  final IconData idleIcon;
  final IconData activeIcon;
  final String label;
  final int? branchIndex; // null = stub tab

  const _TabSpec({
    required this.idleIcon,
    required this.activeIcon,
    required this.label,
    required this.branchIndex,
  });
}

class AppNavigation extends StatefulWidget {
  final StatefulNavigationShell navigationShell;

  const AppNavigation({required this.navigationShell, super.key});

  @override
  State<AppNavigation> createState() => _AppNavigationState();
}

class _AppNavigationState extends State<AppNavigation>
    with SingleTickerProviderStateMixin {
  // TODO: Replace with [Riverpod/Bloc] for production
  int _selectedVisualIndex = 0;

  late AnimationController _animController;

  static const List<_TabSpec> _tabs = [
    _TabSpec(
      idleIcon: Icons.home_outlined,
      activeIcon: Icons.home_rounded,
      label: 'Home',
      branchIndex: 0,
    ),
    _TabSpec(
      idleIcon: Icons.auto_awesome_outlined,
      activeIcon: Icons.auto_awesome_rounded,
      label: 'Tools',
      branchIndex: 1,
    ),
    _TabSpec(
      idleIcon: Icons.people_outline_rounded,
      activeIcon: Icons.people_rounded,
      label: 'Club',
      branchIndex: 2,
    ),
    _TabSpec(
      idleIcon: Icons.person_outline_rounded,
      activeIcon: Icons.person_rounded,
      label: 'Profile',
      branchIndex: 3,
    ),
  ];

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 250),
    );
    _selectedVisualIndex = widget.navigationShell.currentIndex;
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  void _onTabTapped(int visualIndex) {
    final tab = _tabs[visualIndex];

    // Stub tab — silently ignore
    if (tab.branchIndex == null) return;

    setState(() {
      _selectedVisualIndex = visualIndex;
    });

    widget.navigationShell.goBranch(
      tab.branchIndex!,
      initialLocation: tab.branchIndex == widget.navigationShell.currentIndex,
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final bottomPadding = MediaQuery.of(context).padding.bottom;

    return Padding(
      padding: EdgeInsets.fromLTRB(20, 0, 20, bottomPadding + 12),
      child: Container(
        height: 64,
        decoration: BoxDecoration(
          color: const Color(0xFF123C33),
          borderRadius: BorderRadius.circular(32),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF123C33).withAlpha(89),
              blurRadius: 24,
              offset: const Offset(0, 8),
              spreadRadius: 0,
            ),
            BoxShadow(
              color: Colors.black.withAlpha(20),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: List.generate(_tabs.length, (i) {
            final tab = _tabs[i];
            final isActive = _selectedVisualIndex == i;
            final isStub = tab.branchIndex == null;

            return Expanded(
              child: GestureDetector(
                onTap: () => _onTabTapped(i),
                behavior: HitTestBehavior.opaque,
                child: Opacity(
                  opacity: isStub ? 0.4 : 1.0,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    curve: Curves.easeOutCubic,
                    margin: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: isActive
                          ? const Color(0xFFE91E8F).withAlpha(46)
                          : Colors.transparent,
                      borderRadius: BorderRadius.circular(26),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        AnimatedSwitcher(
                          duration: const Duration(milliseconds: 200),
                          child: Icon(
                            isActive ? tab.activeIcon : tab.idleIcon,
                            key: ValueKey(isActive),
                            size: 22,
                            color: isActive
                                ? const Color(0xFFE91E8F)
                                : Colors.white.withAlpha(179),
                          ),
                        ),
                        const SizedBox(height: 2),
                        AnimatedDefaultTextStyle(
                          duration: const Duration(milliseconds: 200),
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 10,
                            fontWeight: isActive
                                ? FontWeight.w600
                                : FontWeight.w400,
                            color: isActive
                                ? const Color(0xFFE91E8F)
                                : Colors.white.withAlpha(179),
                          ),
                          child: Text(tab.label),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          }),
        ),
      ),
    );
  }
}
