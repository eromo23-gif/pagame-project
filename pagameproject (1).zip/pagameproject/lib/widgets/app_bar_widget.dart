// V4 — Gradient AppBar
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppBarWidget extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final bool showLogo;
  final List<Widget>? actions;
  final bool showBack;
  final VoidCallback? onBack;
  final bool centerTitle;

  const AppBarWidget({
    super.key,
    required this.title,
    this.showLogo = false,
    this.actions,
    this.showBack = false,
    this.onBack,
    this.centerTitle = false,
  });

  @override
  Size get preferredSize => const Size.fromHeight(60);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF123C33), Color(0xFF1A5C48)],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: SizedBox(
          height: 60,
          child: Row(
            children: [
              if (showBack)
                IconButton(
                  onPressed: onBack ?? () => Navigator.of(context).pop(),
                  icon: const Icon(
                    Icons.arrow_back_ios_new_rounded,
                    color: Colors.white,
                    size: 20,
                  ),
                )
              else
                const SizedBox(width: 16),
              if (showLogo)
                Image.asset(
                  'assets/images/PagameProjectLogo-1782228044535.jpg',
                  height: 36,
                  fit: BoxFit.contain,
                )
              else if (!centerTitle)
                Expanded(
                  child: Text(
                    title,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                ),
              if (centerTitle)
                Expanded(
                  child: Center(
                    child: Text(
                      title,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              if (actions != null) ...actions!,
              if (actions == null) const SizedBox(width: 16),
            ],
          ),
        ),
      ),
    );
  }
}
